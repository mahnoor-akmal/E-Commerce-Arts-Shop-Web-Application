<?php
/**
 * Shop Page - Product Listing with Search, Filter & Pagination
 * Accessible to ALL visitors (registered or not)
 */
require_once 'config/config.php';

$db = getDB();

// ── Get filter/search params ──────────────────────────────
$search     = trim($_GET['search']   ?? '');
$categoryId = (int)($_GET['category'] ?? 0);
$minPrice   = (float)($_GET['min_price'] ?? 0);
$maxPrice   = (float)($_GET['max_price'] ?? 999999);
$sortBy     = $_GET['sort'] ?? 'newest';
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 12;

// ── Build query ───────────────────────────────────────────
$where  = ["p.is_active = 1"];
// NOTE: Do NOT add stock_quantity check here — show all active products including out-of-stock
$params = [];

if ($search !== '') {
    $searchTerm = '%' . $search . '%';
    $where[] = "(p.product_name LIKE ? OR p.product_code LIKE ? OR c.category_name LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

if ($categoryId > 0) {
    $where[]  = "p.category_id = ?";
    $params[] = $categoryId;
}
if ($minPrice > 0) {
    $where[]  = "p.price >= ?";
    $params[] = $minPrice;
}
if ($maxPrice < 999999) {
    $where[]  = "p.price <= ?";
    $params[] = $maxPrice;
}

$whereSQL = implode(' AND ', $where);

// Sort order
$orderSQL = match ($sortBy) {
    'price_asc'  => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    'name_asc'   => 'p.product_name ASC',
    'oldest'     => 'p.created_at ASC',
    default      => 'p.created_at DESC',
};

// Count total for pagination
// NOTE: JOIN is required here too because $whereSQL may reference c.category_name
$countStmt = $db->prepare("
    SELECT COUNT(*)
    FROM products p
    JOIN product_categories c ON p.category_id = c.category_id
    WHERE $whereSQL");
$countStmt->execute($params);
$totalProducts = (int)$countStmt->fetchColumn();
$totalPages    = ceil($totalProducts / $perPage);
$offset        = ($page - 1) * $perPage;

// Fetch products
$stmt = $db->prepare("
    SELECT p.*, c.category_name, c.category_code
    FROM products p
    JOIN product_categories c ON p.category_id = c.category_id
    WHERE $whereSQL
    ORDER BY $orderSQL
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$products = $stmt->fetchAll();

// Fetch all categories for filter sidebar
$categories = $db->query("
    SELECT c.*, COUNT(p.product_id) AS cnt
    FROM product_categories c
    LEFT JOIN products p ON p.category_id = c.category_id AND p.is_active = 1
    WHERE c.is_active = 1
    GROUP BY c.category_id
    ORDER BY c.category_name
")->fetchAll();

// Resolve the selected category name BEFORE the $cat variable gets overwritten by foreach
$selectedCategory = null;
if ($categoryId > 0) {
    foreach ($categories as $c) {
        if ($c['category_id'] == $categoryId) {
            $selectedCategory = $c;
            break;
        }
    }
}

$catEmoji = ['GA'=>'🎁','GC'=>'💌','DL'=>'🧸','ST'=>'📁','HB'=>'👜','WT'=>'👛','BP'=>'💄','AR'=>'🎨'];

// Build page URL helper
function pageUrl(int $p): string {
    $q = $_GET;
    $q['page'] = $p;
    return 'shop.php?' . http_build_query($q);
}

$pageTitle = 'Shop';
include 'includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">

    <!-- Breadcrumb -->
    <div style="font-size:.85rem;color:var(--muted);margin-bottom:20px;">
      <a href="index.php">Home</a> › Shop
      <?php if ($selectedCategory) echo ' › ' . clean($selectedCategory['category_name']); ?>
    </div>

    <div style="display:grid;grid-template-columns:250px 1fr;gap:30px;align-items:start;">

      <!-- ─── Sidebar Filters ─────────────────────────── -->
      <aside class="card" style="padding:24px;position:sticky;top:80px;">
        <h3 style="font-size:1rem;margin-bottom:16px;">🔍 Search & Filter</h3>
        <form method="GET" action="shop.php">
          <div class="form-group">
            <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?= clean($search) ?>">
          </div>

          <div class="form-group">
            <label class="form-label">Category</label>
            <select name="category" class="form-control">
              <option value="0">All Categories</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['category_id'] ?>" <?= $categoryId==$cat['category_id']?'selected':'' ?>>
                  <?= $catEmoji[$cat['category_code']]??'🎁' ?> <?= clean($cat['category_name']) ?> (<?= $cat['cnt'] ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Price Range</label>
            <div class="form-row" style="gap:8px;">
              <input type="number" name="min_price" class="form-control" placeholder="Min Rs." ...>
<input type="number" name="max_price" class="form-control" placeholder="Max Rs." ...>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Sort By</label>
            <select name="sort" class="form-control">
              <option value="newest"    <?= $sortBy==='newest'?'selected':'' ?>>Newest First</option>
              <option value="oldest"    <?= $sortBy==='oldest'?'selected':'' ?>>Oldest First</option>
              <option value="price_asc" <?= $sortBy==='price_asc'?'selected':'' ?>>Price: Low to High</option>
              <option value="price_desc"<?= $sortBy==='price_desc'?'selected':'' ?>>Price: High to Low</option>
              <option value="name_asc"  <?= $sortBy==='name_asc'?'selected':'' ?>>Name A–Z</option>
            </select>
          </div>

          <button type="submit" class="btn btn-primary btn-block">Apply Filters</button>
          <a href="shop.php" class="btn btn-outline btn-block mt-1" style="border-radius:var(--radius);">Clear All</a>
        </form>

        <!-- Quick category links -->
        <div class="divider"></div>
        <h4 style="font-size:.9rem;margin-bottom:12px;">Browse Categories</h4>
        <?php foreach ($categories as $cat): ?>
          <a href="shop.php?category=<?= $cat['category_id'] ?>"
             style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;
                    color:var(--text);font-size:.88rem;transition:.2s;<?= $categoryId==$cat['category_id']?'background:var(--bg2);color:var(--primary);font-weight:600;':'' ?>"
             onmouseover="this.style.background='var(--bg2)'"
             onmouseout="this.style.background='<?= $categoryId==$cat['category_id']?'var(--bg2)':'transparent' ?>'">
            <?= $catEmoji[$cat['category_code']]??'🎁' ?>
            <span><?= clean($cat['category_name']) ?></span>
            <span style="margin-left:auto;color:var(--muted);font-size:.78rem;"><?= $cat['cnt'] ?></span>
          </a>
        <?php endforeach; ?>
      </aside>

      <!-- ─── Product Grid ──────────────────────────────── -->
      <main>
        <div class="flex justify-between" style="align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
          <div>
            <h2 style="font-size:1.4rem;">
                   <?= $selectedCategory ? clean($selectedCategory['category_name']) : 'All Products' ?>
            </h2>
            <p style="font-size:.85rem;color:var(--muted);">
              Showing <?= min(($page-1)*$perPage+1,$totalProducts) ?>–<?= min($page*$perPage,$totalProducts) ?> of <?= $totalProducts ?> products
              <?= $search ? " for <strong>" . clean($search) . "</strong>" : '' ?>
            </p>
          </div>
        </div>

        <?php if (empty($products)): ?>
          <div class="empty-state">
            <div class="icon">🔍</div>
            <h3>No products found</h3>
            <p>Try adjusting your search or filters.</p>
            <a href="shop.php" class="btn btn-primary mt-3">Browse All Products</a>
          </div>
        <?php else: ?>
          <div class="products-grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));">
            <?php foreach ($products as $p): ?>
              <div class="product-card">
                <a href="product.php?id=<?= $p['product_id'] ?>">
                  <div class="product-card-img">
                    <?php if ($p['image_path']): ?>
                      <img src="<?= UPLOADS_URL . clean($p['image_path']) ?>" alt="<?= clean($p['product_name']) ?>">
                    <?php else: ?>
                      <?= $catEmoji[$p['category_code']] ?? '🎁' ?>
                    <?php endif; ?>
                  </div>
                </a>
                <div class="product-card-body">
                  <div class="code">ID: <?= $p['product_code'] ?></div>
                  <h3><a href="product.php?id=<?= $p['product_id'] ?>" style="color:var(--dark);"><?= clean($p['product_name']) ?></a></h3>
                  <div style="font-size:.78rem;color:var(--muted);margin-bottom:8px;"><?= clean($p['category_name']) ?></div>
                  <?php if ($p['has_warranty']): ?>
                    <div class="warranty">✓ <?= $p['warranty_months'] ?>-Month Warranty</div>
                  <?php endif; ?>
                  <?php if ($p['stock_quantity'] == 0): ?>
                    <div class="stock-out">✗ Out of Stock</div>
                  <?php elseif ($p['stock_quantity'] <= 5): ?>
                    <div class="stock-low">⚠ Only <?= $p['stock_quantity'] ?> left</div>
                  <?php endif; ?>
                  <div class="price"><?= formatCurrency($p['price']) ?></div>
                  <div style="display:flex;gap:8px;">
                    <a href="product.php?id=<?= $p['product_id'] ?>" class="btn btn-outline btn-sm" style="flex:1;justify-content:center;border-radius:8px;">Details</a>
                    <?php if ($p['stock_quantity'] > 0): ?>
                      <?php if (isCustomerLoggedIn()): ?>
                        <a href="cart-action.php?action=add&product_id=<?= $p['product_id'] ?>&redirect=shop"
                           class="btn btn-primary btn-sm" style="flex:1;justify-content:center;border-radius:8px;">Add to Cart</a>
                      <?php else: ?>
                        <a href="customer/login.php" class="btn btn-primary btn-sm" style="flex:1;justify-content:center;border-radius:8px;">Login to Buy</a>
                      <?php endif; ?>
                    <?php else: ?>
                      <button class="btn btn-sm" style="flex:1;background:#eee;color:#999;cursor:not-allowed;border-radius:8px;">Sold Out</button>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Pagination -->
          <?php if ($totalPages > 1): ?>
            <div class="pagination">
              <?php if ($page > 1): ?><a href="<?= pageUrl($page-1) ?>">← Prev</a><?php endif; ?>
              <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                <?php if ($i == $page): ?>
                  <span class="current"><?= $i ?></span>
                <?php else: ?>
                  <a href="<?= pageUrl($i) ?>"><?= $i ?></a>
                <?php endif; ?>
              <?php endfor; ?>
              <?php if ($page < $totalPages): ?><a href="<?= pageUrl($page+1) ?>">Next →</a><?php endif; ?>
            </div>
          <?php endif; ?>
        <?php endif; ?>
      </main>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
