<?php
/**
 * Cart Action Handler
 * Handles: add, update, remove cart operations
 * Requires customer login for all actions
 */
require_once 'config/config.php';
requireCustomer();

$db         = getDB();
$action     = $_GET['action']     ?? $_POST['action']     ?? '';
$productId  = (int)($_GET['product_id'] ?? $_POST['product_id'] ?? 0);
$quantity   = max(1, (int)($_GET['quantity'] ?? $_POST['quantity'] ?? 1));
$customerId = (int)$_SESSION['customer_id'];

// Determine redirect target
$redirectParam = $_GET['redirect'] ?? $_POST['redirect'] ?? 'shop';
$redirectMap = [
    'shop'    => SITE_URL . '/shop.php',
    'index'   => SITE_URL . '/index.php',
    'cart'    => SITE_URL . '/cart.php',
    'product' => SITE_URL . '/product.php?id=' . $productId,
];
$redirectTo = $redirectMap[$redirectParam] ?? SITE_URL . '/cart.php';

switch ($action) {

    case 'add':
        if (!$productId) { setFlash('error', 'Invalid product.'); break; }
        // Check product exists and has stock
        $p = $db->prepare("SELECT product_id, stock_quantity, product_name FROM products WHERE product_id = ? AND is_active = 1");
        $p->execute([$productId]);
        $product = $p->fetch();
        if (!$product) { setFlash('error', 'Product not found.'); break; }
        if ($product['stock_quantity'] < $quantity) {
            setFlash('error', 'Not enough stock available.');
            break;
        }
        // Insert or update cart item
        $stmt = $db->prepare("
            INSERT INTO cart (customer_id, product_id, quantity)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
        ");
        $stmt->execute([$customerId, $productId, $quantity]);
        setFlash('success', '✓ "' . $product['product_name'] . '" added to cart!');
        break;

    case 'update':
        if (!$productId) { setFlash('error', 'Invalid product.'); break; }
        if ($quantity < 1) { $quantity = 1; }
        // Check stock
        $p = $db->prepare("SELECT stock_quantity FROM products WHERE product_id = ?");
        $p->execute([$productId]);
        $stock = (int)$p->fetchColumn();
        if ($quantity > $stock) { $quantity = $stock; setFlash('warning', 'Quantity adjusted to available stock.'); }
        $db->prepare("UPDATE cart SET quantity = ? WHERE customer_id = ? AND product_id = ?")
           ->execute([$quantity, $customerId, $productId]);
        $redirectTo = SITE_URL . '/cart.php';
        break;

    case 'remove':
        if (!$productId) { setFlash('error', 'Invalid product.'); break; }
        $db->prepare("DELETE FROM cart WHERE customer_id = ? AND product_id = ?")
           ->execute([$customerId, $productId]);
        setFlash('success', 'Item removed from cart.');
        $redirectTo = SITE_URL . '/cart.php';
        break;

    case 'clear':
        $db->prepare("DELETE FROM cart WHERE customer_id = ?")->execute([$customerId]);
        setFlash('success', 'Cart cleared.');
        $redirectTo = SITE_URL . '/cart.php';
        break;

    default:
        setFlash('error', 'Invalid action.');
}

redirect($redirectTo);
