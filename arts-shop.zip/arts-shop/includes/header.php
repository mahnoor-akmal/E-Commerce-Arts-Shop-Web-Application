<?php
/**
 * Public-facing header include
 * Renders navbar with dynamic cart count and auth state
 */
$cartCount = getCartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? clean($pageTitle) . ' — ' : '' ?><?= SITE_NAME ?></title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
  <?php if (isset($extraCSS)) echo $extraCSS; ?>
</head>
<body>

<nav class="navbar">
  <div class="navbar-inner">
    <a href="<?= SITE_URL ?>/index.php" class="navbar-brand">Arts <span>Shop</span></a>
    <ul class="navbar-nav">
      <li><a href="<?= SITE_URL ?>/index.php">Home</a></li>
      <li><a href="<?= SITE_URL ?>/shop.php">Shop</a></li>
      <li><a href="<?= SITE_URL ?>/faqs.php">FAQs</a></li>
      <li><a href="<?= SITE_URL ?>/feedback.php">Feedback</a></li>
      <?php if (isCustomerLoggedIn()): ?>
        <li>
          <a href="<?= SITE_URL ?>/cart.php" class="cart-badge">
            🛒 Cart <span class="count"><?= $cartCount ?></span>
          </a>
        </li>
        <li><a href="<?= SITE_URL ?>/customer/my-orders.php">My Orders</a></li>
        <li><a href="<?= SITE_URL ?>/customer/profile.php">My Account</a></li>
        <li><a href="<?= SITE_URL ?>/customer/logout.php" class="btn-nav">Logout</a></li>
      <?php else: ?>
        <li><a href="<?= SITE_URL ?>/customer/login.php">Login</a></li>
        <li><a href="<?= SITE_URL ?>/customer/register.php" class="btn-nav">Register</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<?php
// Display flash message if any
$flash = getFlash();
if ($flash): ?>
<div class="container mt-2">
  <div class="alert alert-<?= $flash['type'] === 'error' ? 'error' : ($flash['type'] === 'success' ? 'success' : ($flash['type'] === 'warning' ? 'warning' : 'info')) ?>">
    <?= clean($flash['message']) ?>
  </div>
</div>
<?php endif; ?>
