<?php /** Footer include for public pages */ ?>
<footer class="footer">
  <div class="footer-grid">
    <div>
      <h4>Arts Shop</h4>
      <p style="font-size:.88rem;line-height:1.7;">Your one-stop destination for gift articles, greeting cards, dolls, stationery, handbags, and more — delivered right to your doorstep.</p>
    </div>
    <div>
      <h4>Quick Links</h4>
      <ul>
        <li><a href="<?= SITE_URL ?>/shop.php">Browse Products</a></li>
        <li><a href="<?= SITE_URL ?>/faqs.php">FAQs</a></li>
        <li><a href="<?= SITE_URL ?>/feedback.php">Feedback</a></li>
        <li><a href="<?= SITE_URL ?>/customer/register.php">Register</a></li>
      </ul>
    </div>
    <div>
      <h4>Customer Care</h4>
      <ul>
        <li><a href="<?= SITE_URL ?>/faqs.php#returns">Returns & Replacements</a></li>
        <li><a href="<?= SITE_URL ?>/faqs.php#payments">Payment Info</a></li>
        <li><a href="<?= SITE_URL ?>/faqs.php#shipping">Shipping Policy</a></li>
        <li><a href="<?= SITE_URL ?>/feedback.php">Contact Us</a></li>
      </ul>
    </div>
    <div>
      <h4>Business Hours</h4>
      <p style="font-size:.88rem;line-height:1.9;">Mon – Sat: 9:00 AM – 7:00 PM<br>Sun: 10:00 AM – 5:00 PM<br><br>📞 +92 3000000000<br>✉️ support@artsshop.com</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved. &nbsp;|&nbsp;
       <a href="<?= SITE_URL ?>/admin/login.php" style="color:rgba(255,255,255,.4);font-size:.78rem;">Admin</a> &nbsp;|&nbsp;
       <a href="<?= SITE_URL ?>/employee/login.php" style="color:rgba(255,255,255,.4);font-size:.78rem;">Employee</a>
    </p>
  </div>
</footer>
<?php if (isset($extraJS)) echo $extraJS; ?>
</body>
</html>
