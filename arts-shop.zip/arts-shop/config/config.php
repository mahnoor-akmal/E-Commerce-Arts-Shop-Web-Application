<?php
/**
 * Global Application Configuration & Helper Functions
 * Arts Online Shopping Cart System
 */

define('SITE_NAME', 'Arts Shop');
define('SITE_URL',  'http://localhost/arts-shop');
define('UPLOADS_PATH', dirname(__DIR__) . '/uploads/products/');
define('UPLOADS_URL',  SITE_URL . '/uploads/products/');

// Delivery types
define('DELIVERY_STANDARD', 1);  // Standard Post
define('DELIVERY_EXPRESS',  2);  // Express Delivery
define('DELIVERY_VPP',      3);  // VPP - Value Payable Post (COD)

// Shipping charges per delivery type
define('SHIPPING_STANDARD', 50.00);
define('SHIPPING_EXPRESS',  150.00);
define('SHIPPING_VPP',      30.00);

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

// ─── Auth Helpers ───────────────────────────────────────────

function isAdminLoggedIn(): bool     { return isset($_SESSION['admin_id']); }
function isEmployeeLoggedIn(): bool  { return isset($_SESSION['employee_id']); }
function isCustomerLoggedIn(): bool  { return isset($_SESSION['customer_id']); }

function requireAdmin(): void {
    if (!isAdminLoggedIn()) {
        setFlash('error', 'Please login as Admin to continue.');
        redirect(SITE_URL . '/admin/login.php');
    }
}
function requireEmployee(): void {
    if (!isEmployeeLoggedIn()) {
        setFlash('error', 'Please login as Employee to continue.');
        redirect(SITE_URL . '/employee/login.php');
    }
}
function requireCustomer(): void {
    if (!isCustomerLoggedIn()) {
        setFlash('error', 'Please login to continue.');
        redirect(SITE_URL . '/customer/login.php');
    }
}

// ─── Flash Messages ──────────────────────────────────────────

function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ─── Utility Helpers ─────────────────────────────────────────

function redirect(string $url): void { header("Location: $url"); exit; }

function clean(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

function formatCurrency(float $amount): string {
    return 'Rs. ' . number_format($amount, 2);
}

function formatDate(string $datetime): string {
    return date('d M Y, h:i A', strtotime($datetime));
}

/**
 * Generate 16-digit order number
 * Format: D (1-digit delivery type) + PPPPPPP (7-digit product code) + OOOOOOOO (8-digit order ID)
 */
function generateOrderNumber(int $deliveryType, string $primaryProductCode, int $orderId): string {
    $d = (string)$deliveryType;                        // 1 digit
    $p = str_pad(substr($primaryProductCode, 0, 7), 7, '0'); // 7 digits
    $o = str_pad((string)$orderId, 8, '0', STR_PAD_LEFT);   // 8 digits
    return $d . $p . $o; // total = 16 digits
}

/**
 * Get delivery type label
 */
function getDeliveryLabel(int $type): string {
    return match($type) {
        1 => 'Standard Post',
        2 => 'Express Delivery',
        3 => 'VPP (Pay on Delivery)',
        default => 'Unknown'
    };
}

/**
 * Get shipping charge for delivery type
 */
function getShippingCharge(int $type): float {
    return match($type) {
        1 => SHIPPING_STANDARD,
        2 => SHIPPING_EXPRESS,
        3 => SHIPPING_VPP,
        default => 0.00
    };
}

/**
 * Get status badge HTML
 */
function statusBadge(string $status): string {
    $map = [
        'placed'           => 'badge-placed',
        'payment_cleared'  => 'badge-payment',
        'dispatched'       => 'badge-dispatched',
        'delivered'        => 'badge-delivered',
        'cancelled'        => 'badge-cancelled',
        'return_requested' => 'badge-return',
        'replaced'         => 'badge-replaced',
        'returned'         => 'badge-returned',
        'pending'          => 'badge-pending',
        'cleared'          => 'badge-cleared',
        'failed'           => 'badge-failed',
        'in_transit'       => 'badge-transit',
    ];
    $cls = $map[$status] ?? 'badge-default';
    $label = ucwords(str_replace('_', ' ', $status));
    return "<span class=\"badge $cls\">$label</span>";
}

/**
 * Get cart item count for logged-in customer
 */
function getCartCount(): int {
    if (!isCustomerLoggedIn()) return 0;
    $db = getDB();
    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE customer_id = ?");
    $stmt->execute([$_SESSION['customer_id']]);
    return (int)$stmt->fetchColumn();
}
