<?php
/**
 * Feedback Page
 * Any visitor can submit feedback. Logged-in customers auto-fill name/email.
 */
require_once 'config/config.php';

$db     = getDB();
$errors = [];
$data   = [];

// Pre-fill for logged-in customers
if (isCustomerLoggedIn()) {
    $cust = $db->prepare("SELECT full_name, email FROM customers WHERE customer_id = ?");
    $cust->execute([$_SESSION['customer_id']]);
    $cust = $cust->fetch();
    $data = ['name' => $cust['full_name'], 'email' => $cust['email']];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name'    => trim($_POST['name']    ?? ''),
        'email'   => trim($_POST['email']   ?? ''),
        'subject' => trim($_POST['subject'] ?? ''),
        'message' => trim($_POST['message'] ?? ''),
        'rating'  => (int)($_POST['rating'] ?? 0),
    ];

    if (strlen($data['name']) < 2)             $errors['name']    = 'Please enter your name.';
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email.';
    if (strlen($data['message']) < 10)         $errors['message'] = 'Message must be at least 10 characters.';
    if ($data['rating'] < 1 || $data['rating'] > 5) $errors['rating'] = 'Please select a rating.';

    if (empty($errors)) {
        $custId = isCustomerLoggedIn() ? $_SESSION['customer_id'] : null;
        $db->prepare("
            INSERT INTO feedbacks (customer_id, name, email, subject, message, rating)
            VALUES (?,?,?,?,?,?)
        ")->execute([$custId, $data['name'], $data['email'], $data['subject'], $data['message'], $data['rating']]);

        setFlash('success', '🙏 Thank you for your feedback! We really appreciate it.');
        redirect(SITE_URL . '/feedback.php');
    }
}

$pageTitle = 'Feedback';
include 'includes/header.php';
?>

<div style="padding:50px 0 80px;">
  <div class="container-sm">

    <!-- Header -->
    <div style="text-align:center;margin-bottom:40px;">
      <div style="font-size:3rem;margin-bottom:12px;">💬</div>
      <h1 style="font-size:2rem;margin-bottom:8px;">Share Your Feedback</h1>
      <p style="color:var(--muted);">We'd love to hear about your experience with Arts Shop.</p>
    </div>

    <div class="card">
      <div class="card-body">
        <form method="POST">

          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Your Name *</label>
              <input type="text" name="name" class="form-control" value="<?= clean($data['name'] ?? '') ?>"
                     placeholder="Full name" required <?= isCustomerLoggedIn() ? 'readonly style="background:var(--bg2)"' : '' ?>>
              <?php if (!empty($errors['name'])): ?><div class="form-error"><?= $errors['name'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Email Address *</label>
              <input type="email" name="email" class="form-control" value="<?= clean($data['email'] ?? '') ?>"
                     placeholder="your@email.com" required <?= isCustomerLoggedIn() ? 'readonly style="background:var(--bg2)"' : '' ?>>
              <?php if (!empty($errors['email'])): ?><div class="form-error"><?= $errors['email'] ?></div><?php endif; ?>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Subject</label>
            <input type="text" name="subject" class="form-control" value="<?= clean($data['subject'] ?? '') ?>"
                   placeholder="What is your feedback about?">
          </div>

          <!-- Star Rating -->
          <div class="form-group">
            <label class="form-label">Overall Rating *</label>
            <div style="display:flex;gap:8px;margin-top:8px;">
              <?php for ($i = 1; $i <= 5; $i++): ?>
                <label style="cursor:pointer;font-size:2rem;transition:.2s;" title="<?= $i ?> star<?= $i>1?'s':'' ?>">
                  <input type="radio" name="rating" value="<?= $i ?>" style="display:none;"
                         <?= ($data['rating'] ?? 0) == $i ? 'checked' : '' ?>>
                  <span class="star" data-val="<?= $i ?>" onclick="setRating(<?= $i ?>)">⭐</span>
                </label>
              <?php endfor; ?>
              <span id="rating-text" style="font-size:.88rem;color:var(--muted);align-self:center;margin-left:8px;">
                <?= ($data['rating'] ?? 0) ? ['','Poor','Fair','Good','Very Good','Excellent'][($data['rating'] ?? 0)] : 'Click to rate' ?>
              </span>
            </div>
            <?php if (!empty($errors['rating'])): ?><div class="form-error"><?= $errors['rating'] ?></div><?php endif; ?>
          </div>

          <div class="form-group">
            <label class="form-label">Your Message *</label>
            <textarea name="message" class="form-control" rows="5"
                      placeholder="Tell us about your experience — what went well, what could be improved..." required><?= clean($data['message'] ?? '') ?></textarea>
            <?php if (!empty($errors['message'])): ?><div class="form-error"><?= $errors['message'] ?></div><?php endif; ?>
          </div>

          <button type="submit" class="btn btn-primary btn-block btn-lg">Submit Feedback</button>
        </form>
      </div>
    </div>

    <!-- Other Contact Info -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:30px;">
      <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">📞</div>
        <h4 style="font-size:.95rem;margin-bottom:4px;">Call Us</h4>
        <p style="color:var(--muted);font-size:.85rem;">+91 9000000000<br>Mon-Sat, 9AM–7PM</p>
      </div>
      <div style="background:var(--white);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">✉️</div>
        <h4 style="font-size:.95rem;margin-bottom:4px;">Email Us</h4>
        <p style="color:var(--muted);font-size:.85rem;">support@artsshop.com<br>We reply within 24 hrs</p>
      </div>
    </div>
  </div>
</div>

<script>
var labels = ['','Poor','Fair','Good','Very Good','Excellent'];
function setRating(val) {
    document.querySelectorAll('input[name="rating"]').forEach(function(r) {
        r.checked = (parseInt(r.value) === val);
    });
    document.getElementById('rating-text').textContent = labels[val];
    // Highlight stars
    document.querySelectorAll('.star').forEach(function(s) {
        s.style.filter = parseInt(s.dataset.val) <= val ? 'none' : 'grayscale(1) opacity(.4)';
    });
}
// Init highlight for pre-selected rating
(function() {
    var checked = document.querySelector('input[name="rating"]:checked');
    if (checked) setRating(parseInt(checked.value));
})();
</script>

<?php include 'includes/footer.php'; ?>
