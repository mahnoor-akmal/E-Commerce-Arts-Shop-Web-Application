<?php
/**
 * Homepage - Arts Online Shopping Cart
 * Shows hero banner, featured products, categories overview
 */
require_once 'config/config.php';

$db = getDB();

// Fetch featured products (latest 8 active products with stock)
$featured = $db->query("
    SELECT p.*, c.category_name
    FROM products p
    JOIN product_categories c ON p.category_id = c.category_id
    WHERE p.is_active = 1 AND p.stock_quantity > 0
    ORDER BY p.created_at DESC
    LIMIT 8
")->fetchAll();

// Fetch categories with product count
$categories = $db->query("
    SELECT c.*, COUNT(p.product_id) AS product_count
    FROM product_categories c
    LEFT JOIN products p ON p.category_id = c.category_id AND p.is_active = 1
    WHERE c.is_active = 1
    GROUP BY c.category_id
    ORDER BY c.category_name
")->fetchAll();

// Category emoji map for display
$catEmoji = ['GA'=>'🎁','GC'=>'💌','DL'=>'🧸','ST'=>'📁','HB'=>'👜','WT'=>'👛','BP'=>'💄','AR'=>'🎨'];

$pageTitle = 'Home';
include 'includes/header.php';
?>

<!-- ─── Hero Section ─────────────────────────────────── -->
<section class="hero">
  <div class="container" style="position:relative; z-index:1;">
    <h1>Gift Someone Special Today</h1>
    <p>Discover our collection of gift articles, greeting cards, dolls, handbags, stationery and more — delivered to your doorstep.</p>
    <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap;">
      <a href="shop.php" class="btn btn-accent btn-lg">🛍 Browse Products</a>
      <?php if (!isCustomerLoggedIn()): ?>
        <a href="customer/register.php" class="btn btn-outline btn-lg" style="border-color:rgba(255,255,255,.5);color:#fff;">Register Free</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ─── Categories ───────────────────────────────────── -->
<section style="padding:60px 0 20px;">
  <div class="container">
    <h2 class="section-title text-center">Shop by Category</h2>
    <p class="section-sub text-center">Find exactly what you're looking for</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:16px;">
      <?php foreach ($categories as $cat): ?>
        <a href="shop.php?category=<?= $cat['category_id'] ?>"
           style="background:var(--white);border:1.5px solid var(--border);border-radius:12px;
                  padding:20px 10px;text-align:center;transition:all .2s;display:block;"
           onmouseover="this.style.borderColor='var(--primary)';this.style.transform='translateY(-3px)'"
           onmouseout="this.style.borderColor='var(--border)';this.style.transform='none'">
          <div style="font-size:2rem;margin-bottom:8px;"><?= $catEmoji[$cat['category_code']] ?? '🎀' ?></div>
          <div style="font-size:.82rem;font-weight:600;color:var(--dark);"><?= clean($cat['category_name']) ?></div>
          <div style="font-size:.72rem;color:var(--muted);margin-top:3px;"><?= $cat['product_count'] ?> items</div>
        </a>
      <?php endforeach; ?>
      <a href="shop.php" style="background:var(--primary);border-radius:12px;padding:20px 10px;text-align:center;display:block;">
        <div style="font-size:2rem;margin-bottom:8px;">🔍</div>
        <div style="font-size:.82rem;font-weight:600;color:#fff;">View All</div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.7);margin-top:3px;">All products</div>
      </a>
    </div>
  </div>
</section>

<!-- ─── Featured Products ─────────────────────────────── -->
<section style="padding:40px 0 60px;">
  <div class="container">
    <div class="flex justify-between" style="align-items:flex-end;margin-bottom:24px;">
      <div>
        <h2 class="section-title">Featured Products</h2>
        <p class="section-sub" style="margin-bottom:0;">Handpicked for you</p>
      </div>
      <a href="shop.php" class="btn btn-outline btn-sm">View All →</a>
    </div>

    <?php if (empty($featured)): ?>
      <div class="empty-state"><div class="icon">🛒</div><p>No products available yet.</p></div>
    <?php else: ?>
      <div class="products-grid">
        <?php foreach ($featured as $p): ?>
          <div class="product-card">
            <a href="product.php?id=<?= $p['product_id'] ?>">
              <div class="product-card-img">
                <?php if ($p['image_path'] && file_exists(UPLOADS_PATH . $p['image_path'])): ?>
                  <img src="<?= UPLOADS_URL . clean($p['image_path']) ?>" alt="<?= clean($p['product_name']) ?>">
                <?php else: ?>
                  <?= $catEmoji[substr($p['product_code'],0,2)] ?? '🎁' ?>
                <?php endif; ?>
              </div>
            </a>
            <div class="product-card-body">
              <div class="code">ID: <?= $p['product_code'] ?></div>
              <h3><a href="product.php?id=<?= $p['product_id'] ?>" style="color:var(--dark);"><?= clean($p['product_name']) ?></a></h3>
              <div style="font-size:.8rem;color:var(--muted);margin-bottom:8px;"><?= clean($p['category_name']) ?></div>
              <?php if ($p['has_warranty']): ?>
                <div class="warranty">✓ <?= $p['warranty_months'] ?> Month Warranty</div>
              <?php endif; ?>
              <?php if ($p['stock_quantity'] <= 5): ?>
                <div class="stock-low">⚠ Only <?= $p['stock_quantity'] ?> left!</div>
              <?php endif; ?>
              <div class="price"><?= formatCurrency($p['price']) ?></div>
              <div style="display:flex;gap:8px;">
                <a href="product.php?id=<?= $p['product_id'] ?>" class="btn btn-outline btn-sm" style="flex:1;justify-content:center;">Details</a>
                <?php if (isCustomerLoggedIn()): ?>
                  <a href="cart-action.php?action=add&product_id=<?= $p['product_id'] ?>&redirect=index"
                     class="btn btn-primary btn-sm" style="flex:1;justify-content:center;">Add to Cart</a>
                <?php else: ?>
                  <a href="customer/login.php" class="btn btn-primary btn-sm" style="flex:1;justify-content:center;">Login to Buy</a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<!-- ─── Why Choose Us ─────────────────────────────────── -->
<section style="background:var(--dark);padding:60px 20px;color:var(--white);">
  <div class="container">
    <h2 style="text-align:center;color:var(--accent);margin-bottom:40px;">Why Shop With Us?</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:30px;text-align:center;">
      <?php foreach ([
        ['🚚','Fast Delivery','Standard, Express & VPP delivery options for your convenience.'],
        ['💳','Secure Payments','Credit Card, Cheque and VPP payment modes supported.'],
        ['🔄','Easy Returns','Return or replace products within 7 days of delivery.'],
        ['📦','Order Tracking','Track every order with a unique 16-digit order number.'],
      ] as [$icon,$title,$desc]): ?>
        <div>
          <div style="font-size:2.4rem;margin-bottom:12px;"><?= $icon ?></div>
          <h4 style="color:var(--accent);margin-bottom:8px;font-size:1rem;"><?= $title ?></h4>
          <p style="font-size:.85rem;opacity:.75;line-height:1.6;"><?= $desc ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
