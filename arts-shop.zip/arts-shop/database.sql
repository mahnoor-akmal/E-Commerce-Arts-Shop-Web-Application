-- ============================================================
-- ARTS ONLINE SHOPPING CART - Complete Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS arts_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE arts_shop;

CREATE TABLE admins (
    admin_id      INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL,
    phone         VARCHAR(20),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE employees (
    employee_id   INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL,
    phone         VARCHAR(20),
    address       TEXT,
    designation   VARCHAR(100),
    is_active     TINYINT(1) DEFAULT 1,
    created_by    INT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(admin_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE customers (
    customer_id   INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL UNIQUE,
    phone         VARCHAR(20),
    address       TEXT,
    city          VARCHAR(100),
    state         VARCHAR(100),
    pincode       VARCHAR(10),
    is_active     TINYINT(1) DEFAULT 1,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE product_categories (
    category_id   INT AUTO_INCREMENT PRIMARY KEY,
    category_code CHAR(2) NOT NULL UNIQUE,
    category_name VARCHAR(100) NOT NULL,
    description   TEXT,
    is_active     TINYINT(1) DEFAULT 1,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- product_code = category_code (2 chars) + 5-digit number = 7 chars total
CREATE TABLE products (
    product_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_code    CHAR(7) NOT NULL UNIQUE,
    category_id     INT NOT NULL,
    product_name    VARCHAR(200) NOT NULL,
    description     TEXT,
    price           DECIMAL(10,2) NOT NULL,
    stock_quantity  INT DEFAULT 0,
    has_warranty    TINYINT(1) DEFAULT 0,
    warranty_months INT DEFAULT 0,
    image_path      VARCHAR(255),
    is_active       TINYINT(1) DEFAULT 1,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES product_categories(category_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE cart (
    cart_id       INT AUTO_INCREMENT PRIMARY KEY,
    customer_id   INT NOT NULL,
    product_id    INT NOT NULL,
    quantity      INT NOT NULL DEFAULT 1,
    added_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (customer_id, product_id)
) ENGINE=InnoDB;

-- order_number format: D(1) + ProductCode(7) + OrderSeq(8) = 16 digits
CREATE TABLE orders (
    order_id            INT AUTO_INCREMENT PRIMARY KEY,
    order_number        CHAR(16) NOT NULL UNIQUE,
    customer_id         INT NOT NULL,
    delivery_type       TINYINT NOT NULL COMMENT '1=Standard,2=Express,3=VPP',
    payment_type        ENUM('credit_card','cheque','vpp') NOT NULL,
    payment_status      ENUM('pending','cleared','failed') DEFAULT 'pending',
    order_status        ENUM('placed','payment_cleared','dispatched','delivered','cancelled','return_requested','replaced','returned') DEFAULT 'placed',
    subtotal            DECIMAL(10,2) NOT NULL,
    shipping_charge     DECIMAL(10,2) DEFAULT 0.00,
    total_amount        DECIMAL(10,2) NOT NULL,
    shipping_address    TEXT NOT NULL,
    shipping_city       VARCHAR(100),
    shipping_state      VARCHAR(100),
    shipping_pincode    VARCHAR(10),
    notes               TEXT,
    placed_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE order_items (
    item_id       INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    product_id    INT NOT NULL,
    product_code  CHAR(7) NOT NULL,
    product_name  VARCHAR(200) NOT NULL,
    unit_price    DECIMAL(10,2) NOT NULL,
    quantity      INT NOT NULL,
    subtotal      DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE payment_details (
    payment_id        INT AUTO_INCREMENT PRIMARY KEY,
    order_id          INT NOT NULL UNIQUE,
    payment_type      ENUM('credit_card','cheque','vpp') NOT NULL,
    card_holder_name  VARCHAR(100),
    card_number_last4 CHAR(4),
    card_expiry       CHAR(7),
    cheque_number     VARCHAR(50),
    bank_name         VARCHAR(100),
    cheque_date       DATE,
    amount            DECIMAL(10,2) NOT NULL,
    payment_date      TIMESTAMP NULL,
    cleared_at        TIMESTAMP NULL,
    remarks           TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE delivery_reports (
    delivery_id       INT AUTO_INCREMENT PRIMARY KEY,
    order_id          INT NOT NULL UNIQUE,
    employee_id       INT,
    dispatched_at     TIMESTAMP NULL,
    tracking_number   VARCHAR(100),
    courier_name      VARCHAR(100),
    estimated_delivery DATE,
    delivered_at      TIMESTAMP NULL,
    delivery_status   ENUM('pending','dispatched','in_transit','delivered','failed') DEFAULT 'pending',
    delivery_notes    TEXT,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE return_requests (
    return_id         INT AUTO_INCREMENT PRIMARY KEY,
    order_id          INT NOT NULL,
    customer_id       INT NOT NULL,
    request_type      ENUM('return','replace') NOT NULL,
    reason            TEXT NOT NULL,
    request_status    ENUM('requested','approved','rejected','processed') DEFAULT 'requested',
    requested_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at      TIMESTAMP NULL,
    admin_remarks     TEXT,
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE feedbacks (
    feedback_id   INT AUTO_INCREMENT PRIMARY KEY,
    customer_id   INT,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(100) NOT NULL,
    subject       VARCHAR(200),
    message       TEXT NOT NULL,
    rating        TINYINT CHECK (rating BETWEEN 1 AND 5),
    is_read       TINYINT(1) DEFAULT 0,
    submitted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE faqs (
    faq_id        INT AUTO_INCREMENT PRIMARY KEY,
    question      TEXT NOT NULL,
    answer        TEXT NOT NULL,
    category      VARCHAR(100) DEFAULT 'General',
    sort_order    INT DEFAULT 0,
    is_active     TINYINT(1) DEFAULT 1,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE stock_log (
    log_id        INT AUTO_INCREMENT PRIMARY KEY,
    product_id    INT NOT NULL,
    change_type   ENUM('restock','sale','return','adjustment') NOT NULL,
    quantity      INT NOT NULL,
    reference_id  INT,
    remarks       TEXT,
    logged_by     VARCHAR(50),
    logged_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(order_status);
CREATE INDEX idx_orders_date ON orders(placed_at);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_cart_customer ON cart(customer_id);

-- Default admin (password: admin123)
INSERT INTO admins (username, password_hash, full_name, email, phone) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Arts Shop Admin', 'admin@artsshop.com', '9000000000');

INSERT INTO product_categories (category_code, category_name, description) VALUES
('GA', 'Gift Articles',   'Decorative gift items and novelties'),
('GC', 'Greeting Cards',  'Cards for all occasions'),
('DL', 'Dolls',           'Soft toys and decorative dolls'),
('ST', 'Stationery',      'Files, folders, notebooks'),
('HB', 'Hand Bags',       'Ladies handbags and totes'),
('WT', 'Wallets',         'Men and women wallets'),
('BP', 'Beauty Products', 'Cosmetics and personal care'),
('AR', 'Art Supplies',    'Paints, brushes, canvases');

INSERT INTO products (product_code, category_id, product_name, description, price, stock_quantity, has_warranty, warranty_months) VALUES
('GA00001', 1, 'Crystal Decorative Elephant', 'Beautiful crystal elephant figurine, perfect as a gift', 599.00, 25, 0, 0),
('GA00002', 1, 'Wooden Photo Frame Set', 'Set of 3 handcrafted wooden photo frames', 349.00, 40, 0, 0),
('GA00003', 1, 'Scented Candle Gift Box', 'Premium scented candles in decorative box', 499.00, 30, 0, 0),
('GC00001', 2, 'Birthday Greeting Card Floral', 'Elegant floral birthday card with envelope', 49.00, 200, 0, 0),
('GC00002', 2, 'Anniversary Card Romantic', 'Luxury romantic anniversary card', 79.00, 150, 0, 0),
('GC00003', 2, 'Festival Greetings Pack 10pcs', 'Assorted festival greeting cards pack', 199.00, 80, 0, 0),
('DL00001', 3, 'Soft Plush Teddy Bear 30cm', 'Super soft brown teddy bear', 299.00, 60, 0, 0),
('DL00002', 3, 'Rag Doll Handmade', 'Handcrafted traditional rag doll', 449.00, 20, 0, 0),
('ST00001', 4, 'Premium A4 Files Pack 10pcs', 'Heavy-duty transparent A4 document files', 149.00, 100, 0, 0),
('ST00002', 4, 'Spiral Notebook A5 Set of 3', 'Ruled spiral notebooks for office', 199.00, 75, 0, 0),
('HB00001', 5, 'Ladies Tote Bag Tan Leather', 'Genuine leather tote bag with pockets', 1499.00, 15, 1, 12),
('HB00002', 5, 'Casual Canvas Shoulder Bag', 'Lightweight canvas bag', 699.00, 35, 0, 0),
('WT00001', 6, 'Mens Bifold Leather Wallet', 'Slim genuine leather wallet', 499.00, 50, 1, 6),
('WT00002', 6, 'Womens Zip-Around Wallet', 'Faux leather zip wallet', 349.00, 40, 0, 0),
('BP00001', 7, 'Rose Face Cream 50ml', 'Natural rose extract moisturising cream', 249.00, 60, 0, 0),
('BP00002', 7, 'Lip Care Gift Set', 'Set of 5 flavored lip balms', 299.00, 45, 0, 0),
('AR00001', 8, 'Watercolor Paint Set 24 Colors', 'Professional watercolor set with brush', 399.00, 30, 0, 0),
('AR00002', 8, 'Acrylic Canvas Pack', 'Pack of 5 stretched canvases', 549.00, 20, 0, 0);

INSERT INTO faqs (question, answer, category, sort_order) VALUES
('How do I place an order?', 'Register or log in, browse products, add to cart, and checkout.', 'Orders', 1),
('What payment methods are accepted?', 'Credit Card, Cheque/DD, and VPP (pay on delivery).', 'Payments', 2),
('When will my order be dispatched?', 'Credit Card and Cheque orders are dispatched after payment clearance. VPP orders are dispatched immediately.', 'Shipping', 3),
('Can I cancel my order?', 'Yes, you can cancel before dispatch from our premises.', 'Orders', 4),
('What is your return policy?', 'Return or replacement within 7 days of delivery.', 'Returns', 5),
('How do I track my order?', 'Login, go to My Orders and click your order number.', 'Orders', 6),
('Do products come with warranty?', 'Selected products include warranty shown on the product page.', 'Products', 7);

INSERT INTO stock_log (product_id, change_type, quantity, remarks, logged_by)
SELECT product_id, 'restock', stock_quantity, 'Initial stock', 'admin' FROM products;
