<?php
/**
 * Product Detail Page
 * Accessible to ALL visitors — login required only to add to cart
 */
require_once 'config/config.php';

$db = getDB();
$productId = (int)($_GET['id'] ?? 0);

if (!$productId) { redirect(SITE_URL . '/shop.php'); }

$stmt = $db->prepare("
    SELECT p.*, c.category_name, c.category_code
    FROM products p
    JOIN product_categories c ON p.category_id = c.category_id
    WHERE p.product_id = ? AND p.is_active = 1
");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    setFlash('error', 'Product not found.');
    redirect(SITE_URL . '/shop.php');
}

// Related products (same category, excluding this product)
$related = $db->prepare("
    SELECT p.*, c.category_code FROM products p
    JOIN product_categories c ON p.category_id = c.category_id
    WHERE p.category_id = ? AND p.product_id != ? AND p.is_active = 1 AND p.stock_quantity > 0
    LIMIT 4
");
$related->execute([$product['category_id'], $productId]);
$relatedProducts = $related->fetchAll();

$catEmoji = ['GA'=>'🎁','GC'=>'💌','DL'=>'🧸','ST'=>'📁','HB'=>'👜','WT'=>'👛','BP'=>'💄','AR'=>'🎨'];
$catIcon  = $catEmoji[$product['category_code']] ?? '🎁';

$pageTitle = clean($product['product_name']);
include 'includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">
    <!-- Breadcrumb -->
    <div style="font-size:.85rem;color:var(--muted);margin-bottom:24px;">
      <a href="index.php">Home</a> ›
      <a href="shop.php">Shop</a> ›
      <a href="shop.php?category=<?= $product['category_id'] ?>"><?= clean($product['category_name']) ?></a> ›
      <?= clean($product['product_name']) ?>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:start;">

      <!-- Product Image -->
      <div class="card" style="overflow:hidden;">
        <div style="height:380px;display:flex;align-items:center;justify-content:center;background:var(--bg2);font-size:5rem;">
          <?php if ($product['image_path']): ?>
            <img src="<?= UPLOADS_URL . clean($product['image_path']) ?>" alt="<?= clean($product['product_name']) ?>"
                 style="width:100%;height:100%;object-fit:cover;">
          <?php else: ?>
            <?= $catIcon ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Product Info -->
      <div>
        <div style="font-size:.82rem;color:var(--muted);margin-bottom:8px;">
          <?= clean($product['category_name']) ?> &nbsp;·&nbsp; <span style="font-family:monospace;">Product ID: <?= $product['product_code'] ?></span>
        </div>
        <h1 style="font-size:1.8rem;margin-bottom:14px;"><?= clean($product['product_name']) ?></h1>

        <div style="font-size:2rem;font-weight:700;color:var(--primary);margin-bottom:20px;">
          <?= formatCurrency($product['price']) ?>
        </div>

        <?php if ($product['description']): ?>
          <p style="color:var(--muted);line-height:1.7;margin-bottom:20px;"><?= nl2br(clean($product['description'])) ?></p>
        <?php endif; ?>

        <!-- Stock Status -->
        <div style="margin-bottom:20px;padding:12px 16px;background:var(--bg2);border-radius:var(--radius);border:1px solid var(--border);">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
            <?php if ($product['stock_quantity'] > 10): ?>
              <span style="color:var(--success);font-weight:600;">✓ In Stock</span>
            <?php elseif ($product['stock_quantity'] > 0): ?>
              <span style="color:var(--warning);font-weight:600;">⚠ Low Stock — Only <?= $product['stock_quantity'] ?> left</span>
            <?php else: ?>
              <span style="color:var(--danger);font-weight:600;">✗ Out of Stock</span>
            <?php endif; ?>
            <?php if ($product['has_warranty']): ?>
              <span style="background:var(--success);color:#fff;padding:3px 10px;border-radius:50px;font-size:.78rem;font-weight:600;">
                ✓ <?= $product['warranty_months'] ?>-Month Warranty
              </span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Quantity + Cart -->
        <?php if ($product['stock_quantity'] > 0): ?>
          <?php if (isCustomerLoggedIn()): ?>
            <form action="cart-action.php" method="GET" style="display:flex;gap:12px;margin-bottom:16px;align-items:center;">
              <input type="hidden" name="action" value="add">
              <input type="hidden" name="product_id" value="<?= $productId ?>">
              <input type="hidden" name="redirect" value="product">
              <div style="display:flex;align-items:center;border:1.5px solid var(--border);border-radius:var(--radius);overflow:hidden;">
                <button type="button" onclick="adjustQty(-1)" style="padding:10px 16px;background:var(--bg2);border:none;cursor:pointer;font-size:1.1rem;">−</button>
                <input type="number" name="quantity" id="qty-input" value="1" min="1" max="<?= $product['stock_quantity'] ?>"
                       style="width:60px;text-align:center;border:none;font-size:1rem;padding:10px 5px;outline:none;">
                <button type="button" onclick="adjustQty(1)" style="padding:10px 16px;background:var(--bg2);border:none;cursor:pointer;font-size:1.1rem;">+</button>
              </div>
              <button type="submit" class="btn btn-primary btn-lg" style="flex:1;">🛒 Add to Cart</button>
            </form>
          <?php else: ?>
            <div class="alert alert-info" style="margin-bottom:16px;">
              🔒 <a href="customer/login.php"><strong>Login</strong></a> or <a href="customer/register.php"><strong>Register</strong></a> to add this product to your cart and place an order.
            </div>
          <?php endif; ?>
        <?php else: ?>
          <button class="btn btn-lg btn-block" style="background:#eee;color:#999;cursor:not-allowed;margin-bottom:16px;" disabled>Out of Stock</button>
        <?php endif; ?>

        <!-- Product Meta -->
        <div style="border-top:1px solid var(--border);padding-top:16px;margin-top:8px;">
          <div style="display:grid;grid-template-columns:auto 1fr;gap:8px 16px;font-size:.88rem;">
            <span style="color:var(--muted);">Category:</span>
            <a href="shop.php?category=<?= $product['category_id'] ?>"><?= clean($product['category_name']) ?></a>
            <span style="color:var(--muted);">Product Code:</span>
            <span style="font-family:monospace;"><?= $product['product_code'] ?></span>
            <?php if ($product['has_warranty']): ?>
              <span style="color:var(--muted);">Warranty:</span>
              <span><?= $product['warranty_months'] ?> Months (Warranty card included)</span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Shipping Info -->
        <div style="margin-top:20px;padding:16px;background:var(--bg2);border-radius:var(--radius);font-size:.85rem;">
          <strong>🚚 Delivery Options:</strong>
          <div style="margin-top:8px;display:grid;gap:6px;">
            <div>📦 Standard Post — <?= formatCurrency(SHIPPING_STANDARD) ?></div>
            <div>⚡ Express Delivery — <?= formatCurrency(SHIPPING_EXPRESS) ?></div>
            <div>🏠 VPP (Pay on Delivery) — <?= formatCurrency(SHIPPING_VPP) ?> shipping</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Related Products -->
    <?php if (!empty($relatedProducts)): ?>
      <div style="margin-top:60px;">
        <h2 style="margin-bottom:20px;">Related Products</h2>
        <div class="products-grid">
          <?php foreach ($relatedProducts as $rp): ?>
            <div class="product-card">
              <a href="product.php?id=<?= $rp['product_id'] ?>">
                <div class="product-card-img"><?= $catEmoji[$rp['category_code']] ?? '🎁' ?></div>
              </a>
              <div class="product-card-body">
                <div class="code">ID: <?= $rp['product_code'] ?></div>
                <h3><a href="product.php?id=<?= $rp['product_id'] ?>" style="color:var(--dark);"><?= clean($rp['product_name']) ?></a></h3>
                <div class="price"><?= formatCurrency($rp['price']) ?></div>
                <a href="product.php?id=<?= $rp['product_id'] ?>" class="btn btn-outline btn-sm btn-block" style="border-radius:8px;">View Details</a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
function adjustQty(delta) {
    var inp = document.getElementById('qty-input');
    var val = parseInt(inp.value) + delta;
    var max = parseInt(inp.max);
    if (val < 1) val = 1;
    if (val > max) val = max;
    inp.value = val;
}
</script>

<?php include 'includes/footer.php'; ?>
