<?php
/**
 * Shopping Cart Page
 * Shows cart items, totals, and proceeds to checkout
 * Requires customer login
 */
require_once 'config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];

// Fetch cart items with product details
$stmt = $db->prepare("
    SELECT c.cart_id, c.quantity, c.added_at,
           p.product_id, p.product_code, p.product_name, p.price,
           p.stock_quantity, p.image_path,
           cat.category_code
    FROM cart c
    JOIN products p ON c.product_id = p.product_id
    JOIN product_categories cat ON p.category_id = cat.category_id
    WHERE c.customer_id = ?
    ORDER BY c.added_at DESC
");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();

// Calculate totals
$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$catEmoji = ['GA'=>'🎁','GC'=>'💌','DL'=>'🧸','ST'=>'📁','HB'=>'👜','WT'=>'👛','BP'=>'💄','AR'=>'🎨'];

$pageTitle = 'My Cart';
include 'includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">
    <!-- Breadcrumb -->
    <div style="font-size:.85rem;color:var(--muted);margin-bottom:24px;">
      <a href="index.php">Home</a> › <a href="shop.php">Shop</a> › My Cart
    </div>

    <h1 style="margin-bottom:24px;">🛒 My Shopping Cart</h1>

    <?php if (empty($cartItems)): ?>
      <div class="empty-state" style="padding:80px 20px;">
        <div class="icon">🛒</div>
        <h3>Your cart is empty</h3>
        <p>Browse our products and add items to your cart.</p>
        <a href="shop.php" class="btn btn-primary mt-3">Browse Products</a>
      </div>
    <?php else: ?>
      <div style="display:grid;grid-template-columns:1fr 340px;gap:30px;align-items:start;">

        <!-- Cart Items -->
        <div>
          <div class="card">
            <div class="card-header flex justify-between">
              <h3>Cart Items (<?= count($cartItems) ?>)</h3>
              <a href="cart-action.php?action=clear" class="btn btn-danger btn-sm"
                 onclick="return confirm('Clear entire cart?')">Clear Cart</a>
            </div>
            <div style="padding:0;">
              <?php foreach ($cartItems as $item):
                $itemTotal = $item['price'] * $item['quantity'];
                $outOfStock = $item['stock_quantity'] == 0;
                $overStock  = $item['quantity'] > $item['stock_quantity'];
              ?>
                <div style="display:grid;grid-template-columns:80px 1fr auto;gap:16px;padding:20px 24px;border-bottom:1px solid var(--border);align-items:center;">
                  <!-- Image / Icon -->
                  <div style="width:80px;height:80px;background:var(--bg2);border-radius:8px;
                              display:flex;align-items:center;justify-content:center;font-size:2rem;overflow:hidden;">
                    <?php if ($item['image_path']): ?>
                      <img src="<?= UPLOADS_URL . clean($item['image_path']) ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
                    <?php else: ?>
                      <?= $catEmoji[$item['category_code']] ?? '🎁' ?>
                    <?php endif; ?>
                  </div>

                  <!-- Details -->
                  <div>
                    <div style="font-size:.78rem;color:var(--muted);font-family:monospace;"><?= $item['product_code'] ?></div>
                    <h4 style="font-size:1rem;margin-bottom:4px;">
                      <a href="product.php?id=<?= $item['product_id'] ?>" style="color:var(--dark);"><?= clean($item['product_name']) ?></a>
                    </h4>
                    <div style="color:var(--primary);font-weight:600;"><?= formatCurrency($item['price']) ?> each</div>
                    <?php if ($outOfStock): ?>
                      <div style="color:var(--danger);font-size:.8rem;margin-top:4px;">⚠ Out of stock — please remove</div>
                    <?php elseif ($overStock): ?>
                      <div style="color:var(--warning);font-size:.8rem;margin-top:4px;">⚠ Only <?= $item['stock_quantity'] ?> available</div>
                    <?php endif; ?>
                    <!-- Quantity Update -->
                    <form action="cart-action.php" method="GET" style="display:flex;gap:8px;align-items:center;margin-top:10px;">
                      <input type="hidden" name="action" value="update">
                      <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                      <div style="display:flex;align-items:center;border:1.5px solid var(--border);border-radius:8px;overflow:hidden;">
                        <button type="button" onclick="adjQty(this,-1)" style="padding:6px 12px;background:var(--bg2);border:none;cursor:pointer;">−</button>
                        <input type="number" name="quantity" value="<?= $item['quantity'] ?>"
                               min="1" max="<?= $item['stock_quantity'] ?>"
                               style="width:50px;text-align:center;border:none;padding:6px 4px;outline:none;font-size:.9rem;">
                        <button type="button" onclick="adjQty(this,1)" style="padding:6px 12px;background:var(--bg2);border:none;cursor:pointer;">+</button>
                      </div>
                      <button type="submit" class="btn btn-outline btn-sm">Update</button>
                    </form>
                  </div>

                  <!-- Item Total + Remove -->
                  <div style="text-align:right;">
                    <div style="font-size:1.1rem;font-weight:700;color:var(--dark);margin-bottom:10px;"><?= formatCurrency($itemTotal) ?></div>
                    <a href="cart-action.php?action=remove&product_id=<?= $item['product_id'] ?>"
                       style="color:var(--danger);font-size:.82rem;"
                       onclick="return confirm('Remove this item?')">✕ Remove</a>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <div class="card-footer">
              <a href="shop.php" class="btn btn-outline btn-sm">← Continue Shopping</a>
            </div>
          </div>
        </div>

        <!-- Order Summary -->
        <div>
          <div class="card" style="position:sticky;top:80px;">
            <div class="card-header"><h3>Order Summary</h3></div>
            <div class="card-body">
              <!-- Item breakdown -->
              <?php foreach ($cartItems as $item): ?>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.88rem;">
                  <span style="color:var(--muted);"><?= clean(mb_substr($item['product_name'],0,28)) ?>... × <?= $item['quantity'] ?></span>
                  <span><?= formatCurrency($item['price'] * $item['quantity']) ?></span>
                </div>
              <?php endforeach; ?>

              <div class="divider"></div>

              <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
                <span>Subtotal</span>
                <strong><?= formatCurrency($subtotal) ?></strong>
              </div>
              <div style="display:flex;justify-content:space-between;margin-bottom:4px;font-size:.85rem;color:var(--muted);">
                <span>Shipping</span>
                <span>Calculated at checkout</span>
              </div>

              <div class="divider"></div>

              <div style="display:flex;justify-content:space-between;margin-bottom:20px;">
                <strong style="font-size:1.1rem;">Total</strong>
                <strong style="font-size:1.3rem;color:var(--primary);"><?= formatCurrency($subtotal) ?>+</strong>
              </div>

              <a href="<?= SITE_URL ?>/customer/checkout.php" class="btn btn-primary btn-block btn-lg">
                Proceed to Checkout →
              </a>

              <div style="margin-top:16px;font-size:.78rem;color:var(--muted);text-align:center;">
                🔒 Secure checkout &nbsp;·&nbsp; Multiple payment options available
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
// Adjust quantity in cart row without submitting form
function adjQty(btn, delta) {
    var row   = btn.closest('form');
    var input = row.querySelector('input[name="quantity"]');
    var max   = parseInt(input.max) || 99;
    var val   = parseInt(input.value) + delta;
    if (val < 1) val = 1;
    if (val > max) val = max;
    input.value = val;
}
</script>

<?php include 'includes/footer.php'; ?>
