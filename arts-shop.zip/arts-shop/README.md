# Arts Online Shopping Cart System

## Project Overview
A complete PHP/MySQL e-commerce system for "Arts" — a stationery and gift article shop.

## Setup Instructions

### 1. Database
```sql
mysql -u root -p < database.sql
```
Or import `database.sql` via phpMyAdmin.

### 2. Configuration
Edit `config/db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_mysql_user');
define('DB_PASS', 'your_mysql_password');
define('DB_NAME', 'arts_shop');
```
Edit `config/config.php`:
```php
define('SITE_URL', 'http://localhost/arts-shop');
```

### 3. File Permissions
```bash
chmod 755 uploads/products/
```

### 4. Web Server
Place project folder at: `htdocs/arts-shop/` (XAMPP) or `/var/www/html/arts-shop/` (Apache)

---

## Login Credentials

| Role     | URL                    | Username | Password  |
|----------|------------------------|----------|-----------|
| Admin    | /admin/login.php       | admin    | admin123  |
| Employee | /employee/login.php    | (created by admin) | |
| Customer | /customer/login.php    | (self-register)    | |

**Change admin password immediately after first login!**

---

## System Architecture

### Database (13 Tables)
- `admins` — Single dealer/admin account
- `employees` — Staff accounts (created by admin only)
- `customers` — Registered shoppers
- `product_categories` — 2-letter category codes (GA, GC, etc.)
- `products` — 7-digit product codes (CategoryCode + 5-digit number)
- `cart` — Shopping cart items
- `orders` — 16-digit order numbers (DeliveryType + ProductCode + OrderSeq)
- `order_items` — Line items per order
- `payment_details` — Credit card / cheque / VPP payment info
- `delivery_reports` — Dispatch and delivery tracking
- `return_requests` — Return/replace requests (7-day window)
- `feedbacks` — Customer feedback submissions
- `faqs` — FAQ entries managed by admin
- `stock_log` — Full stock change audit trail

### File Structure (45 files)
```
arts-shop/
├── index.php                    Homepage
├── shop.php                     Product listing (search/filter)
├── product.php                  Product detail
├── cart.php                     Shopping cart
├── cart-action.php              Cart CRUD handler
├── faqs.php                     Public FAQs
├── feedback.php                 Public feedback form
├── database.sql                 Complete DB schema + seed data
├── config/
│   ├── db.php                   PDO database connection
│   └── config.php               App config + helper functions
├── includes/
│   ├── header.php               Public navbar
│   └── footer.php               Public footer
├── assets/css/
│   └── style.css                Full UI stylesheet (terracotta theme)
├── uploads/products/            Product images directory
├── customer/
│   ├── register.php             Self-registration
│   ├── login.php                Customer login
│   ├── logout.php
│   ├── profile.php              Profile edit + password change
│   ├── checkout.php             Multi-step checkout
│   ├── my-orders.php            Order history
│   ├── order-detail.php         Order tracking & detail
│   └── return-request.php       7-day return/replace form
├── admin/
│   ├── login.php                Admin login
│   ├── dashboard.php            Stats + alerts dashboard
│   ├── products.php             Full product CRUD + image upload
│   ├── categories.php           Category management
│   ├── stock.php                Stock levels + restock + audit log
│   ├── orders.php               All orders with filters + actions
│   ├── order-detail.php         Full order view + admin actions
│   ├── employees.php            Employee account management
│   ├── customers.php            Customer directory
│   ├── returns.php              Return/replace request processing
│   ├── delivery.php             Delivery report overview
│   ├── feedbacks.php            Feedback inbox
│   └── faqs.php                 FAQ CRUD
└── employee/
    ├── login.php                Employee login
    ├── dashboard.php            Employee task dashboard
    ├── orders.php               Order dispatch + delivery updates
    ├── delivery.php             Delivery tracking view
    └── change-password.php      Password change (only allowed action)
```

---

## Business Rules Implemented
1. **7-digit Product ID**: Category code (2 chars) + sequential 5-digit number
2. **16-digit Order Number**: Delivery type (1) + Product code (7) + Order sequence (8)
3. **Payment Rules**:
   - Credit Card / Cheque → Payment must clear before dispatch
   - VPP → Dispatched immediately, customer pays on delivery
4. **Cancellation**: Only before dispatch
5. **Return/Replace**: Within 7 days of delivery only
6. **Guest browsing**: Anyone can view products without registration
7. **Ordering requires registration**: Login mandatory for cart/checkout
8. **Employee restrictions**: Can only change password + manage orders/delivery
9. **Admin exclusives**: Create employees, manage products/categories/stock/FAQs

---

## Technologies Used
- **Backend**: PHP 8.0+ with PDO (prepared statements)
- **Database**: MySQL 5.7+ / MariaDB
- **Frontend**: HTML5, CSS3 (custom), Vanilla JavaScript
- **Security**: password_hash/verify, htmlspecialchars, PDO prepared statements
- **Design**: Google Fonts (Playfair Display + DM Sans), custom CSS variables
