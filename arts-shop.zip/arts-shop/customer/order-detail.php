<?php
/**
 * Order Detail Page
 * Shows full order info, payment, delivery tracking
 * Allows: cancel (if not dispatched), return/replace (within 7 days of delivery)
 */
require_once '../config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];
$orderId    = (int)($_GET['order_id'] ?? 0);

if (!$orderId) redirect(SITE_URL . '/customer/my-orders.php');

// Fetch order (must belong to this customer)
$stmt = $db->prepare("SELECT * FROM orders WHERE order_id = ? AND customer_id = ?");
$stmt->execute([$orderId, $customerId]);
$order = $stmt->fetch();
if (!$order) { setFlash('error', 'Order not found.'); redirect(SITE_URL . '/customer/my-orders.php'); }

// Fetch order items
$items = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$items->execute([$orderId]);
$orderItems = $items->fetchAll();

// Fetch payment details
$payStmt = $db->prepare("SELECT * FROM payment_details WHERE order_id = ?");
$payStmt->execute([$orderId]);
$payment = $payStmt->fetch();

// Fetch delivery report
$delStmt = $db->prepare("SELECT dr.*, e.full_name AS emp_name FROM delivery_reports dr LEFT JOIN employees e ON dr.employee_id = e.employee_id WHERE dr.order_id = ?");
$delStmt->execute([$orderId]);
$delivery = $delStmt->fetch();

// Fetch existing return request
$retStmt = $db->prepare("SELECT * FROM return_requests WHERE order_id = ? AND customer_id = ?");
$retStmt->execute([$orderId, $customerId]);
$returnRequest = $retStmt->fetch();

// ── Handle Cancel ─────────────────────────────────────────
if ($_POST['action'] ?? '' === 'cancel') {
    if (in_array($order['order_status'], ['placed','payment_cleared'])) {
        // Restore stock for each item
        foreach ($orderItems as $item) {
            $db->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?")
               ->execute([$item['quantity'], $item['product_id']]);
            $db->prepare("INSERT INTO stock_log (product_id, change_type, quantity, reference_id, remarks, logged_by) VALUES (?, 'return', ?, ?, 'Order cancelled', 'customer')")
               ->execute([$item['product_id'], $item['quantity'], $orderId]);
        }
        $db->prepare("UPDATE orders SET order_status = 'cancelled' WHERE order_id = ?")
           ->execute([$orderId]);
        setFlash('success', 'Order cancelled successfully. Stock has been restored.');
        redirect(SITE_URL . '/customer/order-detail.php?order_id=' . $orderId);
    } else {
        setFlash('error', 'This order cannot be cancelled as it has already been dispatched.');
        redirect(SITE_URL . '/customer/order-detail.php?order_id=' . $orderId);
    }
}

// ── Handle Return/Replace Request ────────────────────────
if ($_POST['action'] ?? '' === 'return_request') {
    $type   = trim($_POST['request_type'] ?? '');
    $reason = trim($_POST['reason'] ?? '');

    // Check: must be delivered and within 7 days
    $canRequest = ($order['order_status'] === 'delivered' && !$returnRequest);
    $within7days = false;
    if ($delivery && $delivery['delivered_at']) {
        $deliveredTs = strtotime($delivery['delivered_at']);
        $within7days = (time() - $deliveredTs) <= (7 * 24 * 3600);
    }

    if ($canRequest && $within7days && in_array($type, ['return','replace']) && strlen($reason) >= 10) {
        $db->prepare("INSERT INTO return_requests (order_id, customer_id, request_type, reason) VALUES (?,?,?,?)")
           ->execute([$orderId, $customerId, $type, $reason]);
        $db->prepare("UPDATE orders SET order_status = 'return_requested' WHERE order_id = ?")
           ->execute([$orderId]);
        setFlash('success', 'Your ' . $type . ' request has been submitted. We will process it shortly.');
        redirect(SITE_URL . '/customer/order-detail.php?order_id=' . $orderId);
    } else {
        setFlash('error', 'Return/replace request cannot be submitted. Ensure it is within 7 days of delivery and provide a valid reason.');
        redirect(SITE_URL . '/customer/order-detail.php?order_id=' . $orderId);
    }
}

// Re-fetch updated order after actions
$stmt->execute([$orderId, $customerId]);
$order = $stmt->fetch();

// Check if cancel allowed (not yet dispatched)
$canCancel = in_array($order['order_status'], ['placed','payment_cleared']);

// Check if return/replace allowed (delivered, within 7 days, no existing request)
$canReturnReplace = false;
$deliveryDaysLeft = 0;
if ($order['order_status'] === 'delivered' && !$returnRequest && $delivery && $delivery['delivered_at']) {
    $elapsed         = time() - strtotime($delivery['delivered_at']);
    $deliveryDaysLeft = max(0, 7 - floor($elapsed / 86400));
    $canReturnReplace = ($elapsed <= 7 * 86400);
}

$pageTitle = 'Order #' . $order['order_number'];
include '../includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">

    <!-- Breadcrumb & Header -->
    <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
      <div>
        <div style="font-size:.85rem;color:var(--muted);margin-bottom:8px;">
          <a href="my-orders.php">My Orders</a> › Order Details
        </div>
        <h1 style="font-size:1.5rem;">Order <span class="order-num"><?= $order['order_number'] ?></span></h1>
        <p style="font-size:.85rem;color:var(--muted);">Placed on <?= formatDate($order['placed_at']) ?></p>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <?= statusBadge($order['order_status']) ?>
        <?= statusBadge($order['payment_status']) ?>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 340px;gap:24px;align-items:start;">

      <!-- ─── Left ──────────────────────────────────────── -->
      <div>

        <!-- Order Items -->
        <div class="card" style="margin-bottom:20px;">
          <div class="card-header"><h3>📦 Order Items</h3></div>
          <div style="padding:0;">
            <?php foreach ($orderItems as $item): ?>
              <div style="display:grid;grid-template-columns:1fr auto;gap:16px;padding:16px 20px;border-bottom:1px solid var(--border);">
                <div>
                  <div style="font-size:.78rem;font-family:monospace;color:var(--muted);"><?= $item['product_code'] ?></div>
                  <div style="font-weight:600;"><?= clean($item['product_name']) ?></div>
                  <div style="font-size:.85rem;color:var(--muted);margin-top:3px;">
                    <?= formatCurrency($item['unit_price']) ?> × <?= $item['quantity'] ?>
                  </div>
                </div>
                <div style="text-align:right;font-weight:700;color:var(--primary);">
                  <?= formatCurrency($item['subtotal']) ?>
                </div>
              </div>
            <?php endforeach; ?>
            <div style="padding:16px 20px;background:var(--bg2);">
              <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:.9rem;">
                <span>Subtotal</span><span><?= formatCurrency($order['subtotal']) ?></span>
              </div>
              <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:.9rem;">
                <span>Shipping (<?= getDeliveryLabel($order['delivery_type']) ?>)</span>
                <span><?= formatCurrency($order['shipping_charge']) ?></span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:1.1rem;font-weight:700;color:var(--primary);border-top:1px solid var(--border);padding-top:10px;margin-top:6px;">
                <span>Total</span><span><?= formatCurrency($order['total_amount']) ?></span>
              </div>
            </div>
          </div>
        </div>

        <!-- Delivery Tracking -->
        <div class="card" style="margin-bottom:20px;">
          <div class="card-header"><h3>🚚 Delivery Tracking</h3></div>
          <div class="card-body">
            <?php
            // Status timeline
            $timeline = ['placed' => '✅ Order Placed', 'payment_cleared' => '💳 Payment Cleared', 'dispatched' => '📦 Dispatched', 'delivered' => '🏠 Delivered'];
            $statusOrder = array_keys($timeline);
            $currentIdx  = array_search($order['order_status'], $statusOrder);
            ?>
            <div style="display:flex;justify-content:space-between;margin-bottom:24px;position:relative;">
              <div style="position:absolute;top:18px;left:5%;right:5%;height:3px;background:var(--border);z-index:0;"></div>
              <?php foreach ($timeline as $s => $label):
                $idx   = array_search($s, $statusOrder);
                $done  = ($currentIdx !== false && $idx <= $currentIdx && !in_array($order['order_status'],['cancelled']));
                $active= ($s === $order['order_status']);
              ?>
                <div style="text-align:center;flex:1;position:relative;z-index:1;">
                  <div style="width:36px;height:36px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;
                              background:<?= $done?'var(--primary)':'var(--border)' ?>;
                              font-size:<?= $done?'.95rem':'.7rem' ?>;margin-bottom:6px;
                              box-shadow:<?= $active?'0 0 0 4px rgba(192,113,75,.25)':'' ?>;">
                    <?= $done ? '✓' : '' ?>
                  </div>
                  <div style="font-size:.72rem;color:<?= $done?'var(--dark)':'var(--muted)' ?>;font-weight:<?= $active?'700':'400' ?>;"><?= $label ?></div>
                </div>
              <?php endforeach; ?>
            </div>

            <?php if ($order['order_status'] === 'cancelled'): ?>
              <div class="alert alert-error">This order has been cancelled.</div>
            <?php elseif ($delivery): ?>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:.88rem;">
                <?php if ($delivery['dispatched_at']): ?>
                  <div><span style="color:var(--muted);">Dispatched:</span><br><strong><?= formatDate($delivery['dispatched_at']) ?></strong></div>
                <?php endif; ?>
                <?php if ($delivery['tracking_number']): ?>
                  <div><span style="color:var(--muted);">Tracking No:</span><br><strong><?= clean($delivery['tracking_number']) ?></strong></div>
                <?php endif; ?>
                <?php if ($delivery['courier_name']): ?>
                  <div><span style="color:var(--muted);">Courier:</span><br><strong><?= clean($delivery['courier_name']) ?></strong></div>
                <?php endif; ?>
                <?php if ($delivery['estimated_delivery']): ?>
                  <div><span style="color:var(--muted);">Est. Delivery:</span><br><strong><?= date('d M Y', strtotime($delivery['estimated_delivery'])) ?></strong></div>
                <?php endif; ?>
                <?php if ($delivery['delivered_at']): ?>
                  <div><span style="color:var(--muted);">Delivered On:</span><br><strong style="color:var(--success);"><?= formatDate($delivery['delivered_at']) ?></strong></div>
                <?php endif; ?>
              </div>
            <?php else: ?>
              <p style="color:var(--muted);">Delivery details will be updated once the order is dispatched.</p>
            <?php endif; ?>
          </div>
        </div>

        <!-- Payment Details -->
        <div class="card" style="margin-bottom:20px;">
          <div class="card-header"><h3>💳 Payment Details</h3></div>
          <div class="card-body">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:.9rem;">
              <div><span style="color:var(--muted);">Payment Method:</span><br>
                <strong><?= ucwords(str_replace('_',' ',$order['payment_type'])) ?></strong>
              </div>
              <div><span style="color:var(--muted);">Payment Status:</span><br>
                <?= statusBadge($order['payment_status']) ?>
              </div>
              <?php if ($payment): ?>
                <?php if ($order['payment_type'] === 'credit_card' && $payment['card_number_last4']): ?>
                  <div><span style="color:var(--muted);">Card Holder:</span><br><strong><?= clean($payment['card_holder_name'] ?? '') ?></strong></div>
                  <div><span style="color:var(--muted);">Card (Last 4):</span><br><strong>**** **** **** <?= $payment['card_number_last4'] ?></strong></div>
                <?php elseif ($order['payment_type'] === 'cheque' && $payment['cheque_number']): ?>
                  <div><span style="color:var(--muted);">Cheque No:</span><br><strong><?= clean($payment['cheque_number']) ?></strong></div>
                  <div><span style="color:var(--muted);">Bank:</span><br><strong><?= clean($payment['bank_name'] ?? '') ?></strong></div>
                  <div><span style="color:var(--muted);">Cheque Date:</span><br><strong><?= $payment['cheque_date'] ? date('d M Y', strtotime($payment['cheque_date'])) : '—' ?></strong></div>
                <?php elseif ($order['payment_type'] === 'vpp'): ?>
                  <div><span style="color:var(--muted);">Payment:</span><br><strong>Pay on delivery at your doorstep</strong></div>
                <?php endif; ?>
                <?php if ($payment['cleared_at']): ?>
                  <div><span style="color:var(--muted);">Cleared On:</span><br><strong style="color:var(--success);"><?= formatDate($payment['cleared_at']) ?></strong></div>
                <?php endif; ?>
              <?php endif; ?>
              <div><span style="color:var(--muted);">Amount:</span><br><strong style="color:var(--primary);font-size:1.1rem;"><?= formatCurrency($order['total_amount']) ?></strong></div>
            </div>
            <?php if ($order['payment_type'] !== 'vpp' && $order['payment_status'] === 'pending'): ?>
              <div class="alert alert-warning" style="margin-top:16px;margin-bottom:0;">
                ⏳ Payment clearance pending. Order will be dispatched once payment is confirmed by admin.
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Return Request Status -->
        <?php if ($returnRequest): ?>
          <div class="card">
            <div class="card-header"><h3>🔄 Return / Replace Request</h3></div>
            <div class="card-body">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:.9rem;">
                <div><span style="color:var(--muted);">Request Type:</span><br><strong><?= ucfirst($returnRequest['request_type']) ?></strong></div>
                <div><span style="color:var(--muted);">Status:</span><br><?= statusBadge($returnRequest['request_status']) ?></div>
                <div><span style="color:var(--muted);">Requested On:</span><br><strong><?= formatDate($returnRequest['requested_at']) ?></strong></div>
                <?php if ($returnRequest['admin_remarks']): ?>
                  <div><span style="color:var(--muted);">Admin Remarks:</span><br><strong><?= clean($returnRequest['admin_remarks']) ?></strong></div>
                <?php endif; ?>
              </div>
              <div style="margin-top:12px;font-size:.88rem;background:var(--bg2);padding:12px;border-radius:8px;">
                <strong>Your reason:</strong> <?= clean($returnRequest['reason']) ?>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </div>

      <!-- ─── Right Sidebar ─────────────────────────── -->
      <div>
        <!-- Shipping Address -->
        <div class="card" style="margin-bottom:16px;">
          <div class="card-header"><h3 style="font-size:1rem;">📍 Shipping Address</h3></div>
          <div class="card-body" style="font-size:.9rem;line-height:1.8;">
            <?= nl2br(clean($order['shipping_address'])) ?><br>
            <?= clean($order['shipping_city']) ?>, <?= clean($order['shipping_state']) ?><br>
            PIN: <?= clean($order['shipping_pincode']) ?>
          </div>
        </div>

        <!-- Actions -->
        <div class="card">
          <div class="card-header"><h3 style="font-size:1rem;">⚙ Order Actions</h3></div>
          <div class="card-body">

            <!-- Cancel Order -->
            <?php if ($canCancel): ?>
              <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this order?');">
                <input type="hidden" name="action" value="cancel">
                <button type="submit" class="btn btn-danger btn-block">✕ Cancel Order</button>
              </form>
              <p style="font-size:.75rem;color:var(--muted);margin-top:8px;text-align:center;">You can cancel before the order is dispatched.</p>
            <?php endif; ?>

            <!-- Return / Replace -->
            <?php if ($canReturnReplace): ?>
              <div class="divider"></div>
              <p style="font-size:.85rem;margin-bottom:12px;"><strong>Return / Replace Window</strong><br>
                <span style="color:var(--warning);">⏳ <?= $deliveryDaysLeft ?> day<?= $deliveryDaysLeft!=1?'s':'' ?> left</span>
              </p>
              <form method="POST">
                <input type="hidden" name="action" value="return_request">
                <div class="form-group">
                  <label class="form-label" style="font-size:.82rem;">Request Type</label>
                  <select name="request_type" class="form-control" required>
                    <option value="">Select...</option>
                    <option value="return">Return (Get Refund)</option>
                    <option value="replace">Replace (Exchange Product)</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label" style="font-size:.82rem;">Reason (min 10 chars)</label>
                  <textarea name="reason" class="form-control" rows="3" placeholder="Describe the issue..." required minlength="10"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit Request</button>
              </form>
            <?php elseif ($order['order_status'] === 'delivered' && !$returnRequest): ?>
              <div class="alert alert-warning" style="font-size:.82rem;">Return/replace window (7 days) has expired.</div>
            <?php endif; ?>

            <?php if (!$canCancel && !$canReturnReplace && !$returnRequest && !in_array($order['order_status'],['cancelled','returned','replaced'])): ?>
              <p style="color:var(--muted);font-size:.85rem;text-align:center;">No actions available for this order's current status.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
