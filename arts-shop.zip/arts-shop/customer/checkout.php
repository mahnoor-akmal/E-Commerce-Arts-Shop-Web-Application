<?php
/**
 * Checkout Page
 * Handles: delivery address, delivery type, payment method
 * Generates unique 16-digit order number on placement
 * Business Rules:
 *   - Credit Card / Cheque: payment must clear before dispatch
 *   - VPP: dispatched immediately, payment at delivery
 */
require_once '../config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];

// Fetch cart items
$cartStmt = $db->prepare("
    SELECT c.quantity, p.product_id, p.product_code, p.product_name,
           p.price, p.stock_quantity
    FROM cart c
    JOIN products p ON c.product_id = p.product_id
    WHERE c.customer_id = ? AND p.is_active = 1
");
$cartStmt->execute([$customerId]);
$cartItems = $cartStmt->fetchAll();

// Redirect if cart empty
if (empty($cartItems)) {
    setFlash('warning', 'Your cart is empty. Add products before checking out.');
    redirect(SITE_URL . '/cart.php');
}

// Fetch customer info for pre-filling address
$customer = $db->prepare("SELECT * FROM customers WHERE customer_id = ?");
$customer->execute([$customerId]);
$customer = $customer->fetch();

// Calculate subtotal
$subtotal = 0;
foreach ($cartItems as $item) $subtotal += $item['price'] * $item['quantity'];

$errors = [];

// ── Handle Order Placement ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deliveryType  = (int)($_POST['delivery_type']  ?? 0);
    $paymentType   = trim($_POST['payment_type']    ?? '');
    $shippingAddr  = trim($_POST['shipping_address'] ?? '');
    $shippingCity  = trim($_POST['shipping_city']   ?? '');
    $shippingState = trim($_POST['shipping_state']  ?? '');
    $shippingPin   = trim($_POST['shipping_pincode'] ?? '');

    // Payment-specific fields
    $cardHolder   = trim($_POST['card_holder']  ?? '');
    $cardNumber   = trim($_POST['card_number']  ?? '');
    $cardExpiry   = trim($_POST['card_expiry']  ?? '');
    $chequeNumber = trim($_POST['cheque_number'] ?? '');
    $bankName     = trim($_POST['bank_name']    ?? '');
    $chequeDate   = trim($_POST['cheque_date']  ?? '');

    // Validation
    if (!in_array($deliveryType, [1,2,3]))        $errors['delivery_type'] = 'Select a delivery type.';
    if (!in_array($paymentType, ['credit_card','cheque','vpp'])) $errors['payment_type'] = 'Select a payment method.';
    if (strlen($shippingAddr) < 5)  $errors['shipping_address'] = 'Enter full shipping address.';
    if (strlen($shippingCity) < 2)  $errors['shipping_city']    = 'Enter city.';
    if (strlen($shippingState) < 2) $errors['shipping_state']   = 'Enter state.';
if (!preg_match('/^\d{5}$/', $shippingPin))  $errors['shipping_pincode'] = 'Enter valid 5-digit postal code.';
    if ($paymentType === 'credit_card') {
        if (strlen($cardHolder) < 3) $errors['card_holder'] = 'Enter cardholder name.';
        if (!preg_match('/^\d{16}$/', preg_replace('/\s+/','',$cardNumber))) $errors['card_number'] = 'Enter valid 16-digit card number.';
        if (!preg_match('/^\d{2}\/\d{4}$/', $cardExpiry)) $errors['card_expiry'] = 'Enter expiry as MM/YYYY.';
    } elseif ($paymentType === 'cheque') {
        if (strlen($chequeNumber) < 3) $errors['cheque_number'] = 'Enter cheque number.';
        if (strlen($bankName) < 2)     $errors['bank_name']     = 'Enter bank name.';
        if (!$chequeDate)              $errors['cheque_date']   = 'Enter cheque date.';
    }

    // Stock check
    foreach ($cartItems as $item) {
        if ($item['quantity'] > $item['stock_quantity']) {
            $errors['stock'] = 'Some items have insufficient stock. Please update your cart.';
            break;
        }
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();

            $shippingCharge = getShippingCharge($deliveryType);
            $totalAmount    = $subtotal + $shippingCharge;

            // Initial payment status: VPP = cleared (pay on delivery), others = pending
            $payStatus  = ($paymentType === 'vpp') ? 'cleared' : 'pending';
            $orderStatus = ($paymentType === 'vpp') ? 'payment_cleared' : 'placed';

            // Primary product code (from first cart item) for order number
            $primaryCode = $cartItems[0]['product_code'];

            // Insert order (order_number generated after we get the ID)
            $orderStmt = $db->prepare("
                INSERT INTO orders
                  (order_number, customer_id, delivery_type, payment_type, payment_status,
                   order_status, subtotal, shipping_charge, total_amount,
                   shipping_address, shipping_city, shipping_state, shipping_pincode)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            ");
            // Temporary order_number placeholder
            $orderStmt->execute([
                'TEMP000000000000', $customerId, $deliveryType, $paymentType, $payStatus,
                $orderStatus, $subtotal, $shippingCharge, $totalAmount,
                $shippingAddr, $shippingCity, $shippingState, $shippingPin
            ]);
            $orderId = (int)$db->lastInsertId();

            // Now generate real 16-digit order number and update
            $orderNumber = generateOrderNumber($deliveryType, $primaryCode, $orderId);
            $db->prepare("UPDATE orders SET order_number = ? WHERE order_id = ?")
               ->execute([$orderNumber, $orderId]);

            // Insert order items & deduct stock
            foreach ($cartItems as $item) {
                $db->prepare("
                    INSERT INTO order_items
                      (order_id, product_id, product_code, product_name, unit_price, quantity, subtotal)
                    VALUES (?,?,?,?,?,?,?)
                ")->execute([
                    $orderId, $item['product_id'], $item['product_code'],
                    $item['product_name'], $item['price'],
                    $item['quantity'], $item['price'] * $item['quantity']
                ]);

                // Deduct stock
                $db->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?")
                   ->execute([$item['quantity'], $item['product_id']]);

                // Log stock change
                $db->prepare("
                    INSERT INTO stock_log (product_id, change_type, quantity, reference_id, remarks, logged_by)
                    VALUES (?, 'sale', ?, ?, 'Order placed', 'system')
                ")->execute([$item['product_id'], -$item['quantity'], $orderId]);
            }

            // Insert payment details
            $payStmt = $db->prepare("
                INSERT INTO payment_details
                  (order_id, payment_type, card_holder_name, card_number_last4, card_expiry,
                   cheque_number, bank_name, cheque_date, amount, payment_date)
                VALUES (?,?,?,?,?,?,?,?,?,NOW())
            ");
            $payStmt->execute([
                $orderId, $paymentType,
                $cardHolder ?: null,
                $cardNumber ? substr(preg_replace('/\s+/','',$cardNumber), -4) : null,
                $cardExpiry ?: null,
                $chequeNumber ?: null,
                $bankName ?: null,
                $chequeDate ?: null,
                $totalAmount
            ]);

            // Create delivery report record
            $db->prepare("INSERT INTO delivery_reports (order_id) VALUES (?)")
               ->execute([$orderId]);

            // Clear cart
            $db->prepare("DELETE FROM cart WHERE customer_id = ?")
               ->execute([$customerId]);

            $db->commit();

            setFlash('success', '🎉 Order placed successfully! Order No: ' . $orderNumber);
            redirect(SITE_URL . '/customer/order-detail.php?order_id=' . $orderId);

        } catch (Exception $e) {
            $db->rollBack();
            error_log("Order placement error: " . $e->getMessage());
            $errors['general'] = 'Order placement failed. Please try again.';
        }
    }
}

$pageTitle = 'Checkout';
include '../includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">
    <div style="font-size:.85rem;color:var(--muted);margin-bottom:24px;">
      <a href="<?= SITE_URL ?>/index.php">Home</a> › <a href="<?= SITE_URL ?>/cart.php">Cart</a> › Checkout
    </div>
    <h1 style="margin-bottom:24px;">Checkout</h1>

    <?php if (isset($errors['general'])): ?>
      <div class="alert alert-error"><?= clean($errors['general']) ?></div>
    <?php endif; ?>
    <?php if (isset($errors['stock'])): ?>
      <div class="alert alert-warning"><?= $errors['stock'] ?> <a href="<?= SITE_URL ?>/cart.php">Go to Cart</a></div>
    <?php endif; ?>

    <form method="POST" action="" id="checkout-form">
      <div style="display:grid;grid-template-columns:1fr 360px;gap:30px;align-items:start;">

        <!-- ─── Left Column ─────────────────────────────── -->
        <div>
          <!-- Delivery Address -->
          <div class="card" style="margin-bottom:24px;">
            <div class="card-header"><h3>📍 Delivery Address</h3></div>
            <div class="card-body">
              <div class="form-group">
                <label class="form-label">Street Address *</label>
                <textarea name="shipping_address" class="form-control" rows="2" required><?= clean($customer['address'] ?? '') ?></textarea>
                <?php if (isset($errors['shipping_address'])): ?><div class="form-error"><?= $errors['shipping_address'] ?></div><?php endif; ?>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label class="form-label">City *</label>
                  <input type="text" name="shipping_city" class="form-control" value="<?= clean($customer['city'] ?? '') ?>" required>
                  <?php if (isset($errors['shipping_city'])): ?><div class="form-error"><?= $errors['shipping_city'] ?></div><?php endif; ?>
                </div>
                <div class="form-group">
                  <label class="form-label">State *</label>
                  <input type="text" name="shipping_state" class="form-control" value="<?= clean($customer['state'] ?? '') ?>" required>
                  <?php if (isset($errors['shipping_state'])): ?><div class="form-error"><?= $errors['shipping_state'] ?></div><?php endif; ?>
                </div>
              </div>
              <div class="form-group" style="max-width:200px;">
                <label class="form-label">PIN Code *</label>
                <input type="text" name="shipping_pincode" class="form-control" value="<?= clean($customer['pincode'] ?? '') ?>" maxlength="5" required>
                <?php if (isset($errors['shipping_pincode'])): ?><div class="form-error"><?= $errors['shipping_pincode'] ?></div><?php endif; ?>
              </div>
            </div>
          </div>

          <!-- Delivery Type -->
          <div class="card" style="margin-bottom:24px;">
            <div class="card-header"><h3>🚚 Delivery Type</h3></div>
            <div class="card-body">
              <?php if (isset($errors['delivery_type'])): ?><div class="form-error" style="margin-bottom:12px;"><?= $errors['delivery_type'] ?></div><?php endif; ?>
              <?php
              $deliveryOptions = [
                  1 => ['Standard Post', formatCurrency(SHIPPING_STANDARD), '3–7 business days', '📦'],
                  2 => ['Express Delivery', formatCurrency(SHIPPING_EXPRESS), '1–2 business days', '⚡'],
                  3 => ['VPP (Pay on Delivery)', formatCurrency(SHIPPING_VPP) . ' shipping', 'Pay cash at your door', '🏠'],
              ];
              foreach ($deliveryOptions as $val => [$label, $charge, $desc, $icon]): ?>
                <label style="display:flex;align-items:flex-start;gap:14px;padding:14px;border:2px solid var(--border);
                              border-radius:var(--radius);cursor:pointer;margin-bottom:10px;transition:.2s;"
                       onclick="highlightOption(this,'delivery')" id="del-opt-<?= $val ?>">
                  <input type="radio" name="delivery_type" value="<?= $val ?>" style="margin-top:3px;"
                         onchange="updateShipping(<?= $val ?>)" required>
                  <div style="flex:1;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                      <strong><?= $icon ?> <?= $label ?></strong>
                      <span style="color:var(--primary);font-weight:700;"><?= $charge ?></span>
                    </div>
                    <div style="font-size:.82rem;color:var(--muted);margin-top:3px;"><?= $desc ?></div>
                  </div>
                </label>
              <?php endforeach; ?>
            </div>
          </div>

          <!-- Payment Method -->
          <div class="card">
            <div class="card-header"><h3>💳 Payment Method</h3></div>
            <div class="card-body">
              <?php if (isset($errors['payment_type'])): ?><div class="form-error" style="margin-bottom:12px;"><?= $errors['payment_type'] ?></div><?php endif; ?>

              <!-- Credit Card -->
              <label style="display:flex;gap:14px;padding:14px;border:2px solid var(--border);border-radius:var(--radius);cursor:pointer;margin-bottom:10px;transition:.2s;"
                     onclick="highlightOption(this,'payment');showPayFields('credit_card')">
                <input type="radio" name="payment_type" value="credit_card" style="margin-top:3px;" onchange="showPayFields('credit_card')">
                <div>
                  <strong>💳 Credit / Debit Card</strong>
                  <div style="font-size:.82rem;color:var(--muted);margin-top:3px;">Payment clears first, then product is dispatched.</div>
                </div>
              </label>
              <!-- Credit Card Fields -->
              <div id="fields-credit_card" style="display:none;background:var(--bg2);padding:16px;border-radius:var(--radius);margin-bottom:10px;">
                <div class="form-group">
                  <label class="form-label">Cardholder Name</label>
                  <input type="text" name="card_holder" class="form-control" placeholder="Name on card">
                  <?php if (isset($errors['card_holder'])): ?><div class="form-error"><?= $errors['card_holder'] ?></div><?php endif; ?>
                </div>
                <div class="form-row">
                  <div class="form-group">
                    <label class="form-label">Card Number (16 digits)</label>
                    <input type="text" name="card_number" class="form-control" placeholder="XXXX XXXX XXXX XXXX" maxlength="19">
                    <?php if (isset($errors['card_number'])): ?><div class="form-error"><?= $errors['card_number'] ?></div><?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Expiry (MM/YYYY)</label>
                    <input type="text" name="card_expiry" class="form-control" placeholder="MM/YYYY" maxlength="7">
                    <?php if (isset($errors['card_expiry'])): ?><div class="form-error"><?= $errors['card_expiry'] ?></div><?php endif; ?>
                  </div>
                </div>
              </div>

              <!-- Cheque -->
              <label style="display:flex;gap:14px;padding:14px;border:2px solid var(--border);border-radius:var(--radius);cursor:pointer;margin-bottom:10px;transition:.2s;"
                     onclick="highlightOption(this,'payment');showPayFields('cheque')">
                <input type="radio" name="payment_type" value="cheque" style="margin-top:3px;" onchange="showPayFields('cheque')">
                <div>
                  <strong>🏦 Cheque / Demand Draft</strong>
                  <div style="font-size:.82rem;color:var(--muted);margin-top:3px;">Cheque clearance required before dispatch.</div>
                </div>
              </label>
              <!-- Cheque Fields -->
              <div id="fields-cheque" style="display:none;background:var(--bg2);padding:16px;border-radius:var(--radius);margin-bottom:10px;">
                <div class="form-row">
                  <div class="form-group">
                    <label class="form-label">Cheque Number</label>
                    <input type="text" name="cheque_number" class="form-control" placeholder="Cheque / DD number">
                    <?php if (isset($errors['cheque_number'])): ?><div class="form-error"><?= $errors['cheque_number'] ?></div><?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Bank Name</label>
                    <input type="text" name="bank_name" class="form-control" placeholder="Issuing bank name">
                    <?php if (isset($errors['bank_name'])): ?><div class="form-error"><?= $errors['bank_name'] ?></div><?php endif; ?>
                  </div>
                </div>
                <div class="form-group" style="max-width:200px;">
                  <label class="form-label">Cheque Date</label>
                  <input type="date" name="cheque_date" class="form-control">
                  <?php if (isset($errors['cheque_date'])): ?><div class="form-error"><?= $errors['cheque_date'] ?></div><?php endif; ?>
                </div>
              </div>

              <!-- VPP -->
              <label style="display:flex;gap:14px;padding:14px;border:2px solid var(--border);border-radius:var(--radius);cursor:pointer;margin-bottom:10px;transition:.2s;"
                     onclick="highlightOption(this,'payment');showPayFields('vpp')">
                <input type="radio" name="payment_type" value="vpp" style="margin-top:3px;" onchange="showPayFields('vpp')">
                <div>
                  <strong>🏠 VPP — Value Payable Post (Pay on Delivery)</strong>
                  <div style="font-size:.82rem;color:var(--muted);margin-top:3px;">Pay cash when the product arrives at your door. Order dispatched immediately.</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        <!-- ─── Right: Order Summary ──────────────────── -->
        <div style="position:sticky;top:80px;">
          <div class="card">
            <div class="card-header"><h3>Order Summary</h3></div>
            <div class="card-body" style="padding:20px;">
              <!-- Cart items -->
              <?php foreach ($cartItems as $item): ?>
                <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:.88rem;gap:8px;">
                  <span style="color:var(--dark);flex:1;"><?= clean(mb_substr($item['product_name'],0,30)) ?><?= strlen($item['product_name'])>30?'...':'' ?> ×<?= $item['quantity'] ?></span>
                  <span style="font-weight:600;white-space:nowrap;"><?= formatCurrency($item['price']*$item['quantity']) ?></span>
                </div>
              <?php endforeach; ?>

              <div class="divider"></div>

              <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem;">
                <span>Subtotal</span><span><?= formatCurrency($subtotal) ?></span>
              </div>
              <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:.9rem;">
                <span>Shipping</span>
                <span id="shipping-display" style="color:var(--muted);">Select delivery type</span>
              </div>

              <div class="divider"></div>

              <div style="display:flex;justify-content:space-between;margin-bottom:20px;">
                <strong>Total</strong>
                <strong id="total-display" style="font-size:1.2rem;color:var(--primary);"><?= formatCurrency($subtotal) ?></strong>
              </div>

              <button type="submit" class="btn btn-primary btn-block btn-lg" id="place-order-btn">
                🛍 Place Order
              </button>
              <p style="font-size:.75rem;color:var(--muted);text-align:center;margin-top:12px;">
                By placing order you agree to our terms. <br>Products dispatched as per payment clearance.
              </p>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var subtotal = <?= $subtotal ?>;
var shipping = { 1: <?= SHIPPING_STANDARD ?>, 2: <?= SHIPPING_EXPRESS ?>, 3: <?= SHIPPING_VPP ?> };

function updateShipping(type) {
    var s = shipping[type] || 0;
    document.getElementById('shipping-display').textContent = s > 0 ? 'Rs. ' + s.toFixed(2) : 'Free';
document.getElementById('total-display').textContent = 'Rs. ' + (subtotal + s).toFixed(2);
}

function showPayFields(type) {
    ['credit_card','cheque','vpp'].forEach(function(t) {
        var el = document.getElementById('fields-' + t);
        if (el) el.style.display = (t === type) ? 'block' : 'none';
    });
}

function highlightOption(label, group) {
    document.querySelectorAll('[onclick*="highlightOption"][onclick*="' + group + '"]').forEach(function(el) {
        el.style.borderColor = 'var(--border)';
        el.style.background  = '';
    });
    label.style.borderColor = 'var(--primary)';
    label.style.background  = 'rgba(192,113,75,.06)';
}

// Format card number input with spaces
document.addEventListener('input', function(e) {
    if (e.target.name === 'card_number') {
        var v = e.target.value.replace(/\D/g,'').substring(0,16);
        e.target.value = v.replace(/(.{4})/g,'$1 ').trim();
    }
    if (e.target.name === 'card_expiry') {
        var v = e.target.value.replace(/\D/g,'');
        if (v.length >= 2) v = v.substring(0,2) + '/' + v.substring(2,6);
        e.target.value = v;
    }
});
</script>

<?php include '../includes/footer.php'; ?>
