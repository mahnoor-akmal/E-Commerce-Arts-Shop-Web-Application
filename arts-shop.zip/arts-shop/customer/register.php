<?php
/**
 * Customer Registration Page
 * New customers can create an account to place orders
 */
require_once '../config/config.php';

// Redirect if already logged in
if (isCustomerLoggedIn()) redirect(SITE_URL . '/index.php');

$db     = getDB();
$errors = [];
$input  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize inputs
    $input = [
        'full_name' => trim($_POST['full_name'] ?? ''),
        'username'  => trim($_POST['username']  ?? ''),
        'email'     => trim($_POST['email']     ?? ''),
        'phone'     => trim($_POST['phone']     ?? ''),
        'address'   => trim($_POST['address']   ?? ''),
        'city'      => trim($_POST['city']      ?? ''),
        'state'     => trim($_POST['state']     ?? ''),
        'pincode'   => trim($_POST['pincode']   ?? ''),
        'password'  => $_POST['password']       ?? '',
        'confirm'   => $_POST['confirm']        ?? '',
    ];

    // Validation
    if (strlen($input['full_name']) < 3)  $errors['full_name'] = 'Full name must be at least 3 characters.';
    if (!preg_match('/^[a-zA-Z0-9_]{4,30}$/', $input['username'])) $errors['username'] = 'Username: 4-30 chars, letters/numbers/underscore only.';
    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL))        $errors['email']    = 'Enter a valid email address.';
    if (!preg_match('/^[0-9]{10}$/', $input['phone']))             $errors['phone']    = 'Enter a valid 10-digit phone number.';
    if (strlen($input['address']) < 5)  $errors['address']  = 'Please enter your full address.';
    if (strlen($input['city'])    < 2)  $errors['city']     = 'Enter your city.';
    if (strlen($input['state'])   < 2)  $errors['state']    = 'Enter your state.';
    if (!preg_match('/^[0-9]{6}$/', $input['pincode']))            $errors['pincode']  = 'Enter a valid 6-digit PIN code.';
    if (strlen($input['password']) < 6) $errors['password'] = 'Password must be at least 6 characters.';
    if ($input['password'] !== $input['confirm']) $errors['confirm'] = 'Passwords do not match.';

    // Check username and email uniqueness
    if (empty($errors['username'])) {
        $chk = $db->prepare("SELECT customer_id FROM customers WHERE username = ?");
        $chk->execute([$input['username']]);
        if ($chk->fetch()) $errors['username'] = 'This username is already taken.';
    }
    if (empty($errors['email'])) {
        $chk = $db->prepare("SELECT customer_id FROM customers WHERE email = ?");
        $chk->execute([$input['email']]);
        if ($chk->fetch()) $errors['email'] = 'An account with this email already exists.';
    }

    // Register customer
    if (empty($errors)) {
        $hash = password_hash($input['password'], PASSWORD_BCRYPT);
        $stmt = $db->prepare("
            INSERT INTO customers
              (username, password_hash, full_name, email, phone, address, city, state, pincode)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([
            $input['username'], $hash, $input['full_name'],
            $input['email'],    $input['phone'],
            $input['address'],  $input['city'],
            $input['state'],    $input['pincode'],
        ]);
        setFlash('success', '🎉 Account created successfully! Please log in.');
        redirect(SITE_URL . '/customer/login.php');
    }
}

$pageTitle = 'Register';
include '../includes/header.php';
?>

<div style="padding:40px 20px 60px;">
  <div class="container-md">
    <div class="card">
      <div class="card-header text-center">
        <h2>Create Your Account</h2>
        <p style="color:var(--muted);font-size:.88rem;margin-top:4px;">Join Arts Shop to start shopping online</p>
      </div>
      <div class="card-body">
        <?php if (!empty($errors)): ?>
          <div class="alert alert-error">Please fix the errors below and try again.</div>
        <?php endif; ?>

        <form method="POST" action="">
          <h4 style="font-size:1rem;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid var(--border);">Personal Information</h4>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Full Name *</label>
              <input type="text" name="full_name" class="form-control <?= isset($errors['full_name'])?'error-input':'' ?>"
                     value="<?= clean($input['full_name'] ?? '') ?>" placeholder="Your full name" required>
              <?php if (isset($errors['full_name'])): ?><div class="form-error"><?= $errors['full_name'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Username *</label>
              <input type="text" name="username" class="form-control"
                     value="<?= clean($input['username'] ?? '') ?>" placeholder="Choose a username" required>
              <?php if (isset($errors['username'])): ?><div class="form-error"><?= $errors['username'] ?></div><?php endif; ?>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Email Address *</label>
              <input type="email" name="email" class="form-control"
                     value="<?= clean($input['email'] ?? '') ?>" placeholder="your@email.com" required>
              <?php if (isset($errors['email'])): ?><div class="form-error"><?= $errors['email'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Phone Number *</label>
              <input type="text" name="phone" class="form-control"
                     value="<?= clean($input['phone'] ?? '') ?>" placeholder="10-digit mobile number" maxlength="10" required>
              <?php if (isset($errors['phone'])): ?><div class="form-error"><?= $errors['phone'] ?></div><?php endif; ?>
            </div>
          </div>

          <h4 style="font-size:1rem;margin:20px 0 16px;padding-bottom:8px;border-bottom:1px solid var(--border);">Delivery Address</h4>
          <div class="form-group">
            <label class="form-label">Street Address *</label>
            <textarea name="address" class="form-control" rows="2" placeholder="House no, Street, Area" required><?= clean($input['address'] ?? '') ?></textarea>
            <?php if (isset($errors['address'])): ?><div class="form-error"><?= $errors['address'] ?></div><?php endif; ?>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">City *</label>
              <input type="text" name="city" class="form-control" value="<?= clean($input['city'] ?? '') ?>" placeholder="City" required>
              <?php if (isset($errors['city'])): ?><div class="form-error"><?= $errors['city'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">State *</label>
              <input type="text" name="state" class="form-control" value="<?= clean($input['state'] ?? '') ?>" placeholder="State" required>
              <?php if (isset($errors['state'])): ?><div class="form-error"><?= $errors['state'] ?></div><?php endif; ?>
            </div>
          </div>
          <div class="form-group" style="max-width:200px;">
            <label class="form-label">PIN Code *</label>
            <input type="text" name="pincode" class="form-control" value="<?= clean($input['pincode'] ?? '') ?>" placeholder="6-digit PIN" maxlength="6" required>
            <?php if (isset($errors['pincode'])): ?><div class="form-error"><?= $errors['pincode'] ?></div><?php endif; ?>
          </div>

          <h4 style="font-size:1rem;margin:20px 0 16px;padding-bottom:8px;border-bottom:1px solid var(--border);">Set Password</h4>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Password *</label>
              <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
              <?php if (isset($errors['password'])): ?><div class="form-error"><?= $errors['password'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Confirm Password *</label>
              <input type="password" name="confirm" class="form-control" placeholder="Re-enter password" required>
              <?php if (isset($errors['confirm'])): ?><div class="form-error"><?= $errors['confirm'] ?></div><?php endif; ?>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top:8px;">Create Account →</button>
        </form>

        <p style="text-align:center;margin-top:20px;font-size:.9rem;color:var(--muted);">
          Already have an account? <a href="login.php">Login here</a>
        </p>
      </div>
    </div>
  </div>
</div>

<style>
.error-input { border-color: var(--danger) !important; }
</style>

<?php include '../includes/footer.php'; ?>
