<?php
/**
 * Customer Login Page
 */
require_once '../config/config.php';

if (isCustomerLoggedIn()) redirect(SITE_URL . '/index.php');

$db    = getDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        // Allow login with username OR email
        $stmt = $db->prepare("SELECT * FROM customers WHERE (username = ? OR email = ?) AND is_active = 1");
        $stmt->execute([$username, $username]);
        $customer = $stmt->fetch();

        if ($customer && password_verify($password, $customer['password_hash'])) {
            // Set session variables
            $_SESSION['customer_id']   = $customer['customer_id'];
            $_SESSION['customer_name'] = $customer['full_name'];
            $_SESSION['customer_user'] = $customer['username'];
            setFlash('success', 'Welcome back, ' . $customer['full_name'] . '!');
            // Redirect to originally requested page or home
            $redirect = $_SESSION['redirect_after_login'] ?? SITE_URL . '/index.php';
            unset($_SESSION['redirect_after_login']);
            redirect($redirect);
        } else {
            $error = 'Invalid username/email or password.';
        }
    } else {
        $error = 'Please enter your username and password.';
    }
}

$pageTitle = 'Customer Login';
include '../includes/header.php';
?>

<div style="padding:60px 20px;">
  <div class="container-sm">
    <div class="card">
      <div class="card-header text-center">
        <div style="font-size:2.5rem;margin-bottom:8px;">🛍️</div>
        <h2>Customer Login</h2>
        <p style="color:var(--muted);font-size:.88rem;margin-top:4px;">Sign in to your Arts Shop account</p>
      </div>
      <div class="card-body">
        <?php if ($error): ?>
          <div class="alert alert-error"><?= clean($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
          <div class="form-group">
            <label class="form-label">Username or Email</label>
            <input type="text" name="username" class="form-control" placeholder="Enter username or email" autofocus required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg">Login →</button>
        </form>

        <div class="divider"></div>
        <p style="text-align:center;font-size:.9rem;color:var(--muted);">
          Don't have an account? <a href="register.php"><strong>Register here</strong></a>
        </p>
        <p style="text-align:center;font-size:.82rem;margin-top:8px;">
          <a href="<?= SITE_URL ?>/admin/login.php" style="color:var(--muted);">Admin Login</a>
          &nbsp;·&nbsp;
          <a href="<?= SITE_URL ?>/employee/login.php" style="color:var(--muted);">Employee Login</a>
        </p>
      </div>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
