<?php
/**
 * Customer My Orders Page
 * Shows all orders placed by the logged-in customer
 * Supports filtering by status and date
 */
require_once '../config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];

// Filters
$filterStatus = trim($_GET['status'] ?? '');
$filterDate   = trim($_GET['date']   ?? '');
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 10;

$where  = ["o.customer_id = ?"];
$params = [$customerId];

if ($filterStatus) { $where[] = "o.order_status = ?"; $params[] = $filterStatus; }
if ($filterDate)   { $where[] = "DATE(o.placed_at) = ?"; $params[] = $filterDate; }

$whereSQL = implode(' AND ', $where);

// Count
$cnt = $db->prepare("SELECT COUNT(*) FROM orders o WHERE $whereSQL");
$cnt->execute($params);
$total      = (int)$cnt->fetchColumn();
$totalPages = ceil($total / $perPage);
$offset     = ($page - 1) * $perPage;

// Fetch orders with item count
$stmt = $db->prepare("
    SELECT o.*,
           (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.order_id) AS item_count,
           (SELECT dr.delivery_status FROM delivery_reports dr WHERE dr.order_id = o.order_id) AS delivery_status
    FROM orders o
    WHERE $whereSQL
    ORDER BY o.placed_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

$pageTitle = 'My Orders';
include '../includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
      <div>
        <h1>My Orders</h1>
        <p style="color:var(--muted);font-size:.88rem;">Track and manage your orders</p>
      </div>
      <a href="<?= SITE_URL ?>/shop.php" class="btn btn-outline">Continue Shopping</a>
    </div>

    <!-- Filters -->
    <div class="card" style="margin-bottom:24px;">
      <div class="card-body" style="padding:16px 20px;">
        <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
          <div class="form-group" style="margin:0;flex:1;min-width:150px;">
            <label class="form-label" style="font-size:.8rem;">Filter by Status</label>
            <select name="status" class="form-control">
              <option value="">All Statuses</option>
              <?php foreach (['placed','payment_cleared','dispatched','delivered','cancelled','return_requested','replaced','returned'] as $s): ?>
                <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin:0;flex:1;min-width:150px;">
            <label class="form-label" style="font-size:.8rem;">Filter by Date</label>
            <input type="date" name="date" class="form-control" value="<?= clean($filterDate) ?>">
          </div>
          <button type="submit" class="btn btn-primary btn-sm">Apply</button>
          <a href="my-orders.php" class="btn btn-outline btn-sm">Clear</a>
        </form>
      </div>
    </div>

    <?php if (empty($orders)): ?>
      <div class="empty-state">
        <div class="icon">📦</div>
        <h3>No orders found</h3>
        <p><?= $filterStatus || $filterDate ? 'No orders match your filters.' : 'You haven\'t placed any orders yet.' ?></p>
        <a href="<?= SITE_URL ?>/shop.php" class="btn btn-primary mt-3">Start Shopping</a>
      </div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Order Number</th>
              <th>Date</th>
              <th>Items</th>
              <th>Total</th>
              <th>Delivery</th>
              <th>Payment</th>
              <th>Order Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><span class="order-num"><?= $o['order_number'] ?></span></td>
                <td style="white-space:nowrap;font-size:.85rem;"><?= date('d M Y', strtotime($o['placed_at'])) ?></td>
                <td><?= $o['item_count'] ?> item<?= $o['item_count']!=1?'s':'' ?></td>
                <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
                <td style="font-size:.82rem;"><?= getDeliveryLabel($o['delivery_type']) ?></td>
                <td><?= statusBadge($o['payment_status']) ?></td>
                <td><?= statusBadge($o['order_status']) ?></td>
                <td>
                  <a href="order-detail.php?order_id=<?= $o['order_id'] ?>" class="btn btn-outline btn-sm">View</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination -->
      <?php if ($totalPages > 1): ?>
        <div class="pagination">
          <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>&status=<?= urlencode($filterStatus) ?>&date=<?= urlencode($filterDate) ?>">← Prev</a><?php endif; ?>
          <?php for ($i=1;$i<=$totalPages;$i++): ?>
            <?php if ($i==$page): ?><span class="current"><?= $i ?></span>
            <?php else: ?><a href="?page=<?= $i ?>&status=<?= urlencode($filterStatus) ?>&date=<?= urlencode($filterDate) ?>"><?= $i ?></a><?php endif; ?>
          <?php endfor; ?>
          <?php if ($page < $totalPages): ?><a href="?page=<?= $page+1 ?>&status=<?= urlencode($filterStatus) ?>&date=<?= urlencode($filterDate) ?>">Next →</a><?php endif; ?>
        </div>
      <?php endif; ?>
      <p style="text-align:center;font-size:.82rem;color:var(--muted);margin-top:12px;">Showing <?= count($orders) ?> of <?= $total ?> orders</p>
    <?php endif; ?>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
