<?php
/**
 * Customer Profile Page
 * Allows customer to update personal info and change password
 */
require_once '../config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];

// Fetch current customer data
$customer = $db->prepare("SELECT * FROM customers WHERE customer_id = ?");
$customer->execute([$customerId]);
$customer = $customer->fetch();

$errors  = [];
$pwErrors = [];
$tab     = $_GET['tab'] ?? 'profile';

// ── Handle Profile Update ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $address   = trim($_POST['address']   ?? '');
    $city      = trim($_POST['city']      ?? '');
    $state     = trim($_POST['state']     ?? '');
    $pincode   = trim($_POST['pincode']   ?? '');

    if (strlen($full_name) < 3) $errors['full_name'] = 'Name must be at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Invalid email address.';
    if (empty($address)) $errors['address'] = 'Address is required.';
    if (empty($city))    $errors['city']    = 'City is required.';
    if (empty($pincode)) $errors['pincode'] = 'Pincode is required.';

    // Check email uniqueness (excluding self)
    if (empty($errors['email'])) {
        $check = $db->prepare("SELECT customer_id FROM customers WHERE email = ? AND customer_id != ?");
        $check->execute([$email, $customerId]);
        if ($check->fetch()) $errors['email'] = 'This email is already used by another account.';
    }

    if (empty($errors)) {
        $db->prepare("
            UPDATE customers SET full_name=?, email=?, phone=?, address=?, city=?, state=?, pincode=?
            WHERE customer_id=?
        ")->execute([$full_name, $email, $phone, $address, $city, $state, $pincode, $customerId]);

        // Update session name
        $_SESSION['customer_name'] = $full_name;
        setFlash('success', '✓ Profile updated successfully!');
        redirect(SITE_URL . '/customer/profile.php?tab=profile');
    }
    $tab = 'profile';
}

// ── Handle Password Change ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current  = $_POST['current_password'] ?? '';
    $new      = $_POST['new_password']     ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $customer['password_hash'])) $pwErrors['current'] = 'Current password is incorrect.';
    if (strlen($new) < 6)             $pwErrors['new']     = 'New password must be at least 6 characters.';
    if ($new !== $confirm)            $pwErrors['confirm'] = 'Passwords do not match.';

    if (empty($pwErrors)) {
        $hash = password_hash($new, PASSWORD_BCRYPT);
        $db->prepare("UPDATE customers SET password_hash=? WHERE customer_id=?")->execute([$hash, $customerId]);
        setFlash('success', '✓ Password changed successfully!');
        redirect(SITE_URL . '/customer/profile.php?tab=password');
    }
    $tab = 'password';
}

// Order stats
$stats = $db->prepare("
    SELECT
        COUNT(*) AS total_orders,
        SUM(CASE WHEN order_status='delivered' THEN 1 ELSE 0 END) AS delivered,
        SUM(total_amount) AS total_spent
    FROM orders WHERE customer_id=?
");
$stats->execute([$customerId]);
$stats = $stats->fetch();

$pageTitle = 'My Account';
include '../includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container-md">
    <h1 style="margin-bottom:6px;">My Account</h1>
    <p style="color:var(--muted);margin-bottom:24px;">Welcome back, <strong><?= clean($customer['full_name']) ?></strong></p>

    <!-- Account Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:30px;">
      <div class="stat-card">
        <div class="stat-icon">📦</div>
        <div class="stat-label">Total Orders</div>
        <div class="stat-value"><?= $stats['total_orders'] ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">✅</div>
        <div class="stat-label">Delivered</div>
        <div class="stat-value"><?= $stats['delivered'] ?></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💰</div>
        <div class="stat-label">Total Spent</div>
        <div class="stat-value" style="font-size:1.3rem;"><?= formatCurrency((float)$stats['total_spent']) ?></div>
      </div>
    </div>

    <!-- Tabs -->
    <div style="display:flex;gap:4px;margin-bottom:24px;border-bottom:2px solid var(--border);padding-bottom:0;">
      <?php foreach (['profile'=>'👤 Profile','password'=>'🔒 Change Password','orders'=>'📦 My Orders'] as $t=>$label): ?>
        <a href="?tab=<?= $t ?>" style="padding:10px 20px;border-radius:8px 8px 0 0;font-size:.9rem;font-weight:600;
           <?= $tab===$t ? 'background:var(--primary);color:#fff;' : 'color:var(--muted);' ?>">
          <?= $label ?>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- ── Profile Tab ────────────────────────────────── -->
    <?php if ($tab === 'profile'): ?>
    <div class="card">
      <div class="card-header"><h3>Edit Profile</h3></div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="update_profile" value="1">
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Full Name *</label>
              <input type="text" name="full_name" class="form-control"
                     value="<?= clean($customer['full_name']) ?>" required>
              <?php if (!empty($errors['full_name'])): ?><div class="form-error"><?= $errors['full_name'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Username</label>
              <input type="text" class="form-control" value="<?= clean($customer['username']) ?>" disabled
                     style="background:var(--bg2);cursor:not-allowed;">
              <div class="form-hint">Username cannot be changed.</div>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Email *</label>
              <input type="email" name="email" class="form-control" value="<?= clean($customer['email']) ?>" required>
              <?php if (!empty($errors['email'])): ?><div class="form-error"><?= $errors['email'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">Phone</label>
              <input type="text" name="phone" class="form-control" value="<?= clean($customer['phone'] ?? '') ?>">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Address *</label>
            <textarea name="address" class="form-control" rows="2" required><?= clean($customer['address'] ?? '') ?></textarea>
            <?php if (!empty($errors['address'])): ?><div class="form-error"><?= $errors['address'] ?></div><?php endif; ?>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">City *</label>
              <input type="text" name="city" class="form-control" value="<?= clean($customer['city'] ?? '') ?>" required>
              <?php if (!empty($errors['city'])): ?><div class="form-error"><?= $errors['city'] ?></div><?php endif; ?>
            </div>
            <div class="form-group">
              <label class="form-label">State</label>
              <input type="text" name="state" class="form-control" value="<?= clean($customer['state'] ?? '') ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Pincode *</label>
              <input type="text" name="pincode" class="form-control" value="<?= clean($customer['pincode'] ?? '') ?>" required>
              <?php if (!empty($errors['pincode'])): ?><div class="form-error"><?= $errors['pincode'] ?></div><?php endif; ?>
            </div>
            <div></div>
          </div>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
      </div>
    </div>

    <!-- ── Password Tab ───────────────────────────────── -->
    <?php elseif ($tab === 'password'): ?>
    <div class="card">
      <div class="card-header"><h3>Change Password</h3></div>
      <div class="card-body" style="max-width:480px;">
        <form method="POST">
          <input type="hidden" name="change_password" value="1">
          <div class="form-group">
            <label class="form-label">Current Password *</label>
            <input type="password" name="current_password" class="form-control" required>
            <?php if (!empty($pwErrors['current'])): ?><div class="form-error"><?= $pwErrors['current'] ?></div><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">New Password *</label>
            <input type="password" name="new_password" class="form-control" placeholder="Minimum 6 characters" required>
            <?php if (!empty($pwErrors['new'])): ?><div class="form-error"><?= $pwErrors['new'] ?></div><?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm New Password *</label>
            <input type="password" name="confirm_password" class="form-control" required>
            <?php if (!empty($pwErrors['confirm'])): ?><div class="form-error"><?= $pwErrors['confirm'] ?></div><?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary">Update Password</button>
        </form>
      </div>
    </div>

    <!-- ── Orders Quick View Tab ──────────────────────── -->
    <?php elseif ($tab === 'orders'): ?>
    <?php
    $orders = $db->prepare("
        SELECT o.*, (SELECT COUNT(*) FROM order_items WHERE order_id=o.order_id) AS item_count
        FROM orders o WHERE o.customer_id=? ORDER BY o.placed_at DESC LIMIT 10
    ");
    $orders->execute([$customerId]);
    $orders = $orders->fetchAll();
    ?>
    <div class="card">
      <div class="card-header flex justify-between">
        <h3>Recent Orders</h3>
        <a href="my-orders.php" class="btn btn-outline btn-sm">View All Orders</a>
      </div>
      <?php if (empty($orders)): ?>
        <div class="empty-state"><div class="icon">📦</div><p>No orders placed yet.</p></div>
      <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Order #</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              <?php foreach ($orders as $o): ?>
              <tr>
                <td><span class="order-num"><?= $o['order_number'] ?></span></td>
                <td><?= date('d M Y', strtotime($o['placed_at'])) ?></td>
                <td><?= $o['item_count'] ?> item(s)</td>
                <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
                <td><?= statusBadge($o['order_status']) ?></td>
                <td><a href="order-detail.php?id=<?= $o['order_id'] ?>" class="btn btn-outline btn-sm">View</a></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

  </div>
</div>

<?php include '../includes/footer.php'; ?>
