<?php
/**
 * Return / Replace Request Page
 * Business Rule: Request must be placed within 7 days of delivery
 * Customer can request 'return' (refund) or 'replace' (new product not sent — re-check)
 */
require_once '../config/config.php';
requireCustomer();

$db         = getDB();
$customerId = (int)$_SESSION['customer_id'];
$orderId    = (int)($_GET['order_id'] ?? 0);

if (!$orderId) redirect(SITE_URL . '/customer/my-orders.php');

// Fetch order — must belong to this customer and be 'delivered'
$order = $db->prepare("
    SELECT o.*, dr.delivered_at
    FROM orders o
    LEFT JOIN delivery_reports dr ON dr.order_id = o.order_id
    WHERE o.order_id = ? AND o.customer_id = ? AND o.order_status = 'delivered'
");
$order->execute([$orderId, $customerId]);
$order = $order->fetch();

if (!$order) {
    setFlash('error', 'Order not found or not eligible for return/replace.');
    redirect(SITE_URL . '/customer/my-orders.php');
}

// Check if within 7-day window
$deliveredAt = $order['delivered_at'] ?? $order['placed_at'];
$daysSince   = (int)((time() - strtotime($deliveredAt)) / 86400);
$withinWindow = $daysSince <= 7;

// Check if request already exists
$existing = $db->prepare("SELECT * FROM return_requests WHERE order_id = ? AND customer_id = ?");
$existing->execute([$orderId, $customerId]);
$existing = $existing->fetch();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $withinWindow && !$existing) {
    $type   = $_POST['request_type'] ?? '';
    $reason = trim($_POST['reason']  ?? '');

    if (!in_array($type, ['return', 'replace'])) $errors[] = 'Please select a valid request type.';
    if (strlen($reason) < 10) $errors[] = 'Please provide a reason (at least 10 characters).';

    if (empty($errors)) {
        $db->prepare("
            INSERT INTO return_requests (order_id, customer_id, request_type, reason)
            VALUES (?,?,?,?)
        ")->execute([$orderId, $customerId, $type, $reason]);

        // Update order status
        $db->prepare("UPDATE orders SET order_status='return_requested' WHERE order_id=?")->execute([$orderId]);

        setFlash('success', '✓ Your ' . $type . ' request has been submitted. We will process it within 2 business days.');
        redirect(SITE_URL . '/customer/order-detail.php?id=' . $orderId);
    }
}

// Fetch order items
$items = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$items->execute([$orderId]);
$items = $items->fetchAll();

$pageTitle = 'Return / Replace Request';
include '../includes/header.php';
?>

<div style="padding:30px 0 60px;">
  <div class="container-md">
    <!-- Breadcrumb -->
    <div style="font-size:.85rem;color:var(--muted);margin-bottom:24px;">
      <a href="../index.php">Home</a> › <a href="my-orders.php">My Orders</a> ›
      <a href="order-detail.php?id=<?= $orderId ?>">Order #<?= $order['order_number'] ?></a> › Return/Replace
    </div>

    <h1 style="margin-bottom:24px;">Return / Replace Request</h1>

    <!-- Order Summary Card -->
    <div class="card" style="margin-bottom:24px;">
      <div class="card-header flex justify-between">
        <span>Order: <span class="order-num"><?= $order['order_number'] ?></span></span>
        <span>Delivered: <?= $deliveredAt ? date('d M Y', strtotime($deliveredAt)) : 'N/A' ?></span>
      </div>
      <div class="card-body" style="padding:16px 24px;">
        <?php foreach ($items as $item): ?>
          <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border);">
            <span><?= clean($item['product_name']) ?> × <?= $item['quantity'] ?></span>
            <span><?= formatCurrency($item['subtotal']) ?></span>
          </div>
        <?php endforeach; ?>
        <div style="display:flex;justify-content:space-between;padding-top:10px;font-weight:700;">
          <span>Total Paid:</span>
          <span><?= formatCurrency($order['total_amount']) ?></span>
        </div>
      </div>
    </div>

    <?php if ($existing): ?>
      <!-- Request Already Submitted -->
      <div class="alert alert-info">
        <div>
          <strong>Request Already Submitted</strong><br>
          You have already submitted a <strong><?= $existing['request_type'] ?></strong> request on
          <?= date('d M Y', strtotime($existing['requested_at'])) ?>.
          Current status: <?= statusBadge($existing['request_status']) ?>
          <?php if ($existing['admin_remarks']): ?>
            <br>Admin remarks: <?= clean($existing['admin_remarks']) ?>
          <?php endif; ?>
        </div>
      </div>
      <a href="order-detail.php?id=<?= $orderId ?>" class="btn btn-outline">← Back to Order</a>

    <?php elseif (!$withinWindow): ?>
      <!-- Outside 7-day window -->
      <div class="alert alert-error">
        <div>
          <strong>Return Window Expired</strong><br>
          The 7-day return/replace window has passed. Your order was delivered <?= $daysSince ?> days ago.
          Returns and replacements are only accepted within 7 days of delivery.
        </div>
      </div>
      <a href="order-detail.php?id=<?= $orderId ?>" class="btn btn-outline">← Back to Order</a>

    <?php else: ?>
      <!-- Return/Replace Form -->
      <div class="card">
        <div class="card-header">
          <h3>Submit Request</h3>
          <p style="font-size:.85rem;color:var(--muted);margin-top:4px;">
            ⏰ You have <strong><?= 7 - $daysSince ?> day(s)</strong> remaining in the return window.
          </p>
        </div>
        <div class="card-body">
          <?php foreach ($errors as $e): ?>
            <div class="alert alert-error"><?= clean($e) ?></div>
          <?php endforeach; ?>

          <form method="POST">
            <div class="form-group">
              <label class="form-label">Request Type *</label>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:8px;">

                <label style="cursor:pointer;">
                  <input type="radio" name="request_type" value="return" style="display:none;" id="type-return">
                  <div class="return-option" onclick="selectType('return')" style="border:2px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center;transition:.2s;">
                    <div style="font-size:2rem;margin-bottom:8px;">↩️</div>
                    <strong>Return & Refund</strong>
                    <p style="font-size:.82rem;color:var(--muted);margin-top:6px;">Return the product and get your money back</p>
                  </div>
                </label>

                <label style="cursor:pointer;">
                  <input type="radio" name="request_type" value="replace" style="display:none;" id="type-replace">
                  <div class="return-option" onclick="selectType('replace')" style="border:2px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center;transition:.2s;">
                    <div style="font-size:2rem;margin-bottom:8px;">🔄</div>
                    <strong>Replace Product</strong>
                    <p style="font-size:.82rem;color:var(--muted);margin-top:6px;">Return and get a replacement (same product)</p>
                  </div>
                </label>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Reason for Return/Replace *</label>
              <textarea name="reason" class="form-control" rows="4" placeholder="Please describe why you want to return or replace this product..." required><?= clean($_POST['reason'] ?? '') ?></textarea>
              <div class="form-hint">Minimum 10 characters. Be as descriptive as possible.</div>
            </div>

            <div class="alert alert-warning">
              ⚠️ <strong>Please Note:</strong> The product must be returned in its original condition and packaging.
              For replacements, a new product will <strong>not</strong> be sent — the same product will be inspected and returned.
            </div>

            <div style="display:flex;gap:12px;">
              <button type="submit" class="btn btn-primary" id="submit-btn" disabled>Submit Request</button>
              <a href="order-detail.php?id=<?= $orderId ?>" class="btn btn-outline">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
var selected = null;
function selectType(type) {
    selected = type;
    document.querySelectorAll('.return-option').forEach(function(el) {
        el.style.borderColor = 'var(--border)';
        el.style.background  = 'transparent';
    });
    var el = event.currentTarget;
    el.style.borderColor = 'var(--primary)';
    el.style.background  = 'rgba(192,113,75,.08)';
    document.getElementById('type-' + type).checked = true;
    document.getElementById('submit-btn').disabled = false;
}
</script>

<?php include '../includes/footer.php'; ?>
