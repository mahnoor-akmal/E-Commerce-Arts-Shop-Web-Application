<?php
require_once '../config/config.php';
session_destroy();
setFlash('success', 'You have been logged out successfully.');
redirect(SITE_URL . '/customer/login.php');
