<?php
/**
 * Employee Order Management
 * Employee can view orders and update dispatch/delivery details
 * Employee CANNOT change payment status or cancel orders
 */
require_once '../config/config.php';
requireEmployee();

$db  = getDB();
$eid = (int)$_SESSION['employee_id'];

// ── Handle POST (dispatch / mark delivered) ───────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action']   ?? '';
    $orderId = (int)$_POST['order_id'];

    if ($action === 'dispatch' && $orderId) {
        $tracking  = trim($_POST['tracking_number']    ?? '');
        $courier   = trim($_POST['courier_name']       ?? '');
        $estDate   = $_POST['estimated_delivery']      ?? null;
        $notes     = trim($_POST['delivery_notes']     ?? '');

        $db->prepare("UPDATE orders SET order_status='dispatched' WHERE order_id=? AND order_status IN ('payment_cleared','placed')")->execute([$orderId]);

        $existing = $db->prepare("SELECT delivery_id FROM delivery_reports WHERE order_id=?");
        $existing->execute([$orderId]);
        if ($existing->fetch()) {
            $db->prepare("UPDATE delivery_reports SET dispatched_at=NOW(), delivery_status='dispatched', tracking_number=?, courier_name=?, estimated_delivery=?, delivery_notes=?, employee_id=? WHERE order_id=?")
               ->execute([$tracking, $courier, $estDate ?: null, $notes, $eid, $orderId]);
        } else {
            $db->prepare("INSERT INTO delivery_reports (order_id, employee_id, dispatched_at, delivery_status, tracking_number, courier_name, estimated_delivery, delivery_notes) VALUES (?,?,NOW(),'dispatched',?,?,?,?)")
               ->execute([$orderId, $eid, $tracking, $courier, $estDate ?: null, $notes]);
        }
        setFlash('success', "Order #$orderId dispatched successfully.");
        redirect(SITE_URL . '/employee/orders.php');
    }

    if ($action === 'update_delivery' && $orderId) {
        $delivStatus = $_POST['delivery_status']    ?? '';
        $notes       = trim($_POST['delivery_notes'] ?? '');
        $deliveredAt = ($delivStatus === 'delivered') ? 'NOW()' : 'NULL';

        if ($delivStatus === 'delivered') {
            $db->prepare("UPDATE orders SET order_status='delivered' WHERE order_id=?")->execute([$orderId]);
            $db->prepare("UPDATE delivery_reports SET delivery_status=?, delivery_notes=?, delivered_at=NOW() WHERE order_id=?")->execute([$delivStatus, $notes, $orderId]);
        } else {
            $db->prepare("UPDATE delivery_reports SET delivery_status=?, delivery_notes=? WHERE order_id=?")->execute([$delivStatus, $notes, $orderId]);
        }
        setFlash('success', "Delivery status updated.");
        redirect(SITE_URL . '/employee/orders.php');
    }
}

// ── Filters ───────────────────────────────────────────────
$statusFilter = $_GET['status'] ?? '';
$search       = trim($_GET['search'] ?? '');
$viewId       = (int)($_GET['view'] ?? 0);

$where  = ['1=1'];
$params = [];
if ($statusFilter) { $where[] = "o.order_status=?"; $params[] = $statusFilter; }
if ($search)       { $where[] = "(o.order_number LIKE ? OR cu.full_name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$orders = $db->prepare("
    SELECT o.*, cu.full_name AS customer_name, cu.phone AS customer_phone,
           cu.email AS customer_email,
           dr.delivery_status, dr.tracking_number, dr.dispatched_at
    FROM orders o
    JOIN customers cu ON o.customer_id=cu.customer_id
    LEFT JOIN delivery_reports dr ON dr.order_id=o.order_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY o.placed_at DESC
");
$orders->execute($params);
$orders = $orders->fetchAll();

// Fetch single order for detail view
$viewOrder = null;
if ($viewId) {
    $vo = $db->prepare("SELECT o.*, cu.full_name, cu.phone, cu.email, cu.address, cu.city, cu.state, cu.pincode FROM orders o JOIN customers cu ON o.customer_id=cu.customer_id WHERE o.order_id=?");
    $vo->execute([$viewId]);
    $viewOrder = $vo->fetch();

    $voItems = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
    $voItems->execute([$viewId]);
    $voItems = $voItems->fetchAll();

    $voDr = $db->prepare("SELECT * FROM delivery_reports WHERE order_id=?");
    $voDr->execute([$viewId]);
    $voDr = $voDr->fetch();
}

$pageTitle = 'Order Management';
include 'emp-header.php';
?>

<!-- ── Order Detail Panel (when view=ID) ──────────────────── -->
<?php if ($viewOrder): ?>
<div class="card" style="margin-bottom:24px;border-left:4px solid var(--primary);">
  <div class="card-header flex justify-between">
    <h3>Order: <span class="order-num"><?= $viewOrder['order_number'] ?></span></h3>
    <a href="orders.php" class="btn btn-outline btn-sm">← Back to List</a>
  </div>
  <div class="card-body">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:20px;">
      <div>
        <h4 style="font-size:.9rem;color:var(--muted);margin-bottom:10px;">CUSTOMER</h4>
        <p><strong><?= clean($viewOrder['full_name']) ?></strong></p>
        <p><?= clean($viewOrder['phone'] ?? '') ?></p>
        <p><?= clean($viewOrder['email']) ?></p>
      </div>
      <div>
        <h4 style="font-size:.9rem;color:var(--muted);margin-bottom:10px;">SHIPPING TO</h4>
        <p><?= nl2br(clean($viewOrder['shipping_address'])) ?></p>
        <p><?= clean($viewOrder['shipping_city'] ?? '') ?> <?= clean($viewOrder['shipping_state'] ?? '') ?> — <?= clean($viewOrder['shipping_pincode'] ?? '') ?></p>
        <p style="margin-top:6px;font-weight:600;">🚚 <?= getDeliveryLabel($viewOrder['delivery_type']) ?></p>
      </div>
    </div>

    <!-- Items -->
    <h4 style="font-size:.9rem;color:var(--muted);margin-bottom:10px;">ORDER ITEMS</h4>
    <div style="background:var(--bg2);border-radius:var(--radius);padding:16px;margin-bottom:20px;">
      <?php foreach ($voItems as $item): ?>
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border);">
          <span><?= clean($item['product_name']) ?> <span style="color:var(--muted);font-size:.82rem;">× <?= $item['quantity'] ?></span></span>
          <span><?= formatCurrency($item['subtotal']) ?></span>
        </div>
      <?php endforeach; ?>
      <div style="display:flex;justify-content:space-between;padding-top:10px;font-weight:700;">
        <span>Total:</span><span style="color:var(--primary);"><?= formatCurrency($viewOrder['total_amount']) ?></span>
      </div>
    </div>

    <!-- Dispatch Action -->
    <?php if (in_array($viewOrder['order_status'], ['payment_cleared']) || ($viewOrder['order_status'] === 'placed' && $viewOrder['payment_type'] === 'vpp')): ?>
    <div style="background:#e8f5e9;border:1.5px solid #a5d6a7;border-radius:var(--radius);padding:20px;margin-bottom:20px;">
      <h4 style="margin-bottom:14px;color:#2e7d32;">📦 Ready to Dispatch — Fill Dispatch Details</h4>
      <form method="POST">
        <input type="hidden" name="action" value="dispatch">
        <input type="hidden" name="order_id" value="<?= $viewOrder['order_id'] ?>">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Courier / Shipping Partner</label>
            <input type="text" name="courier_name" class="form-control" placeholder="e.g. India Post, BlueDart">
          </div>
          <div class="form-group">
            <label class="form-label">Tracking Number</label>
            <input type="text" name="tracking_number" class="form-control" placeholder="AWB / Tracking ID">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Estimated Delivery Date</label>
            <input type="date" name="estimated_delivery" class="form-control" min="<?= date('Y-m-d') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <input type="text" name="delivery_notes" class="form-control" placeholder="Any special notes">
          </div>
        </div>
        <button type="submit" class="btn btn-success">Confirm Dispatch →</button>
      </form>
    </div>
    <?php elseif ($viewOrder['order_status'] === 'dispatched' && $voDr): ?>
    <div style="background:#e3f2fd;border:1.5px solid #90caf9;border-radius:var(--radius);padding:20px;">
      <h4 style="margin-bottom:14px;color:#1565c0;">🚚 Update Delivery Status</h4>
      <div style="margin-bottom:14px;font-size:.9rem;display:grid;gap:6px;">
        <?php if ($voDr['courier_name']): ?><div><strong>Courier:</strong> <?= clean($voDr['courier_name']) ?></div><?php endif; ?>
        <?php if ($voDr['tracking_number']): ?><div><strong>Tracking #:</strong> <span style="font-family:monospace;"><?= clean($voDr['tracking_number']) ?></span></div><?php endif; ?>
        <?php if ($voDr['estimated_delivery']): ?><div><strong>Est. Delivery:</strong> <?= date('d M Y', strtotime($voDr['estimated_delivery'])) ?></div><?php endif; ?>
      </div>
      <form method="POST">
        <input type="hidden" name="action"   value="update_delivery">
        <input type="hidden" name="order_id" value="<?= $viewOrder['order_id'] ?>">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Update Status</label>
            <select name="delivery_status" class="form-control">
              <option value="dispatched"  <?= $voDr['delivery_status']==='dispatched'?'selected':''  ?>>Dispatched</option>
              <option value="in_transit"  <?= $voDr['delivery_status']==='in_transit'?'selected':''  ?>>In Transit</option>
              <option value="delivered"   <?= $voDr['delivery_status']==='delivered'?'selected':''   ?>>Delivered ✓</option>
              <option value="failed"      <?= $voDr['delivery_status']==='failed'?'selected':''      ?>>Delivery Failed</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <input type="text" name="delivery_notes" class="form-control" value="<?= clean($voDr['delivery_notes'] ?? '') ?>" placeholder="Update notes">
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Update Status</button>
      </form>
    </div>
    <?php else: ?>
      <div class="alert alert-info">Current order status: <?= statusBadge($viewOrder['order_status']) ?></div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<!-- ── Filters + Table ─────────────────────────────────────── -->
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:12px;">
  <h3 style="font-size:1rem;">All Orders</h3>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <?php foreach ([''=> 'All','placed'=>'Placed','payment_cleared'=>'Ready','dispatched'=>'Dispatched','delivered'=>'Delivered'] as $k=>$label): ?>
      <a href="?status=<?= $k ?>" class="btn btn-sm <?= $statusFilter===$k?'btn-dark':'btn-outline' ?>"><?= $label ?></a>
    <?php endforeach; ?>
  </div>
</div>

<form method="GET" style="display:flex;gap:12px;margin-bottom:16px;">
  <input type="text" name="search" class="form-control" placeholder="Search order # or customer..." value="<?= clean($search) ?>" style="flex:1;">
  <?php if ($statusFilter): ?><input type="hidden" name="status" value="<?= $statusFilter ?>"><?php endif; ?>
  <button type="submit" class="btn btn-dark">Search</button>
</form>

<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th>Delivery</th><th>Payment</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php if (empty($orders)): ?>
          <tr><td colspan="8" style="text-align:center;padding:30px;color:var(--muted);">No orders found.</td></tr>
        <?php endif; ?>
        <?php foreach ($orders as $o): ?>
        <tr>
          <td><span class="order-num" style="font-size:.8rem;"><?= $o['order_number'] ?></span></td>
          <td style="font-size:.88rem;"><?= clean($o['customer_name']) ?></td>
          <td style="font-size:.82rem;"><?= date('d M Y', strtotime($o['placed_at'])) ?></td>
          <td style="font-size:.8rem;"><?= getDeliveryLabel($o['delivery_type']) ?></td>
          <td style="font-size:.82rem;"><?= ucfirst(str_replace('_',' ',$o['payment_type'])) ?></td>
          <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
          <td><?= statusBadge($o['order_status']) ?></td>
          <td><a href="?view=<?= $o['order_id'] ?>" class="btn btn-outline btn-sm">View</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'emp-footer.php'; ?>
