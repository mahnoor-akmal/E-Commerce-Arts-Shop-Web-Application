<?php
/**
 * Employee Change Password
 * Business Rule: Employee can ONLY change their own password — nothing else
 */
require_once '../config/config.php';
requireEmployee();

$db     = getDB();
$eid    = (int)$_SESSION['employee_id'];
$errors = [];

// Fetch current employee
$emp = $db->prepare("SELECT * FROM employees WHERE employee_id=?");
$emp->execute([$eid]);
$emp = $emp->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password']     ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $emp['password_hash'])) $errors['current'] = 'Current password is incorrect.';
    if (strlen($new) < 6)       $errors['new']     = 'New password must be at least 6 characters.';
    if ($new !== $confirm)       $errors['confirm'] = 'Passwords do not match.';

    if (empty($errors)) {
        $db->prepare("UPDATE employees SET password_hash=? WHERE employee_id=?")->execute([password_hash($new, PASSWORD_BCRYPT), $eid]);
        setFlash('success', '✓ Password changed successfully. Please use the new password on your next login.');
        redirect(SITE_URL . '/employee/change-password.php');
    }
}

$pageTitle = 'Change Password';
include 'emp-header.php';
?>

<div style="max-width:480px;">
  <div class="card">
    <div class="card-header">
      <h3>🔒 Change Your Password</h3>
      <p style="font-size:.85rem;color:var(--muted);margin-top:4px;">Logged in as: <strong><?= clean($emp['username']) ?></strong> — <?= clean($emp['designation'] ?? 'Employee') ?></p>
    </div>
    <div class="card-body">
      <form method="POST">
        <div class="form-group">
          <label class="form-label">Current Password *</label>
          <input type="password" name="current_password" class="form-control" required placeholder="Enter your current password">
          <?php if (!empty($errors['current'])): ?><div class="form-error"><?= $errors['current'] ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">New Password *</label>
          <input type="password" name="new_password" class="form-control" required placeholder="Minimum 6 characters">
          <?php if (!empty($errors['new'])): ?><div class="form-error"><?= $errors['new'] ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password *</label>
          <input type="password" name="confirm_password" class="form-control" required placeholder="Repeat new password">
          <?php if (!empty($errors['confirm'])): ?><div class="form-error"><?= $errors['confirm'] ?></div><?php endif; ?>
        </div>
        <div class="alert alert-info" style="font-size:.85rem;">
          ℹ️ Your password must be at least 6 characters. After changing, you will need to use the new password at next login.
        </div>
        <button type="submit" class="btn btn-primary btn-block">Change Password</button>
      </form>
    </div>
  </div>
</div>

<?php include 'emp-footer.php'; ?>
