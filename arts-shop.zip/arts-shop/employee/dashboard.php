<?php
/**
 * Employee Dashboard
 * Shows: pending dispatches, today's delivered orders, summary stats
 */
require_once '../config/config.php';
requireEmployee();

$db  = getDB();
$eid = (int)$_SESSION['employee_id'];

// Stats
$readyToDispatch = $db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('payment_cleared','placed') AND payment_type='vpp' OR order_status='payment_cleared'")->fetchColumn();
$dispatchedToday = $db->query("SELECT COUNT(*) FROM delivery_reports WHERE DATE(dispatched_at)=CURDATE()")->fetchColumn();
$deliveredToday  = $db->query("SELECT COUNT(*) FROM delivery_reports WHERE DATE(delivered_at)=CURDATE()")->fetchColumn();
$inTransit       = $db->query("SELECT COUNT(*) FROM delivery_reports WHERE delivery_status='dispatched' OR delivery_status='in_transit'")->fetchColumn();

// Orders needing attention
$pendingOrders = $db->query("
    SELECT o.*, cu.full_name AS customer_name
    FROM orders o JOIN customers cu ON o.customer_id=cu.customer_id
    WHERE o.order_status IN ('payment_cleared','placed') AND (o.payment_type='vpp' OR o.order_status='payment_cleared')
    ORDER BY o.placed_at ASC LIMIT 10
")->fetchAll();

$pageTitle = 'Dashboard';
include 'emp-header.php';
?>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
  <div class="stat-card" style="border-top:4px solid var(--warning);">
    <div class="stat-icon">⏳</div>
    <div class="stat-label">Ready to Dispatch</div>
    <div class="stat-value"><?= $readyToDispatch ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--primary);">
    <div class="stat-icon">📦</div>
    <div class="stat-label">Dispatched Today</div>
    <div class="stat-value"><?= $dispatchedToday ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--info);">
    <div class="stat-icon">🚚</div>
    <div class="stat-label">In Transit</div>
    <div class="stat-value"><?= $inTransit ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--success);">
    <div class="stat-icon">✅</div>
    <div class="stat-label">Delivered Today</div>
    <div class="stat-value"><?= $deliveredToday ?></div>
  </div>
</div>

<div class="card">
  <div class="card-header flex justify-between">
    <h3 style="font-size:1rem;">⏳ Orders Ready to Dispatch</h3>
    <a href="orders.php" class="btn btn-outline btn-sm">View All Orders</a>
  </div>
  <?php if (empty($pendingOrders)): ?>
    <div style="padding:40px;text-align:center;color:var(--success);">✓ No orders pending dispatch right now.</div>
  <?php else: ?>
    <div class="table-wrap" style="border:none;border-radius:0;">
      <table>
        <thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th>Delivery</th><th>Payment</th><th>Total</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach ($pendingOrders as $o): ?>
          <tr>
            <td><span class="order-num"><?= $o['order_number'] ?></span></td>
            <td><?= clean($o['customer_name']) ?></td>
            <td style="font-size:.85rem;"><?= date('d M Y', strtotime($o['placed_at'])) ?></td>
            <td style="font-size:.82rem;"><?= getDeliveryLabel($o['delivery_type']) ?></td>
            <td><?= statusBadge($o['payment_status']) ?></td>
            <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
            <td><a href="orders.php?view=<?= $o['order_id'] ?>" class="btn btn-primary btn-sm">Process</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php include 'emp-footer.php'; ?>
