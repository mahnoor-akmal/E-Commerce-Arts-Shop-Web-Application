<?php
/**
 * Employee Panel Header
 */
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? clean($pageTitle).' — ' : '' ?>Employee Panel | Arts Shop</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
  <?php if (isset($extraCSS)) echo $extraCSS; ?>
</head>
<body>
<div class="admin-layout">
  <aside class="admin-sidebar" style="background:#1e3a5f;">
    <div class="sidebar-logo" style="color:#7ec8e3;">Employee Panel <span>Arts Shop</span></div>
    <ul class="sidebar-menu">
      <?php
      function empNav($href,$icon,$label,$cur) {
          $a = basename($href)===$cur?'active':'';
          return "<li><a href='$href' class='$a'><span class='icon'>$icon</span> $label</a></li>";
      }
      ?>
      <?= empNav(SITE_URL.'/employee/dashboard.php','📊','Dashboard',$currentPage) ?>
      <?= empNav(SITE_URL.'/employee/orders.php','📋','Order Management',$currentPage) ?>
      <?= empNav(SITE_URL.'/employee/delivery.php','🚚','Delivery Reports',$currentPage) ?>
      <?= empNav(SITE_URL.'/employee/change-password.php','🔒','Change Password',$currentPage) ?>
      <li><a href="<?= SITE_URL ?>/index.php" target="_blank"><span class="icon">🌐</span> View Website</a></li>
      <li><a href="<?= SITE_URL ?>/employee/logout.php"><span class="icon">🚪</span> Logout</a></li>
    </ul>
  </aside>
  <div class="admin-main">
    <div class="admin-topbar">
      <h1><?= isset($pageTitle) ? clean($pageTitle) : 'Employee Panel' ?></h1>
      <div style="font-size:.88rem;color:var(--muted);">
        👤 <?= clean($_SESSION['employee_name'] ?? '') ?> &nbsp;·&nbsp;
        <a href="<?= SITE_URL ?>/employee/logout.php" style="color:var(--danger);">Logout</a>
      </div>
    </div>
    <div class="admin-content">
    <?php $flash = getFlash(); if ($flash): ?>
      <div class="alert alert-<?= $flash['type']==='error'?'error':($flash['type']==='success'?'success':'info') ?>"><?= clean($flash['message']) ?></div>
    <?php endif; ?>
