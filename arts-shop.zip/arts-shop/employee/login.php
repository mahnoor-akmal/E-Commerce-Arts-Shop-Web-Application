<?php
/**
 * Employee Login Page
 * Credentials are created by Admin only
 */
require_once '../config/config.php';

if (isEmployeeLoggedIn()) redirect(SITE_URL . '/employee/dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM employees WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $emp  = $stmt->fetch();

        if ($emp && password_verify($password, $emp['password_hash'])) {
            $_SESSION['employee_id']   = $emp['employee_id'];
            $_SESSION['employee_name'] = $emp['full_name'];
            $_SESSION['employee_user'] = $emp['username'];
            setFlash('success', 'Welcome, ' . $emp['full_name'] . '!');
            redirect(SITE_URL . '/employee/dashboard.php');
        } else {
            $error = 'Invalid username or password, or account is inactive.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Login — Arts Shop</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body style="background:linear-gradient(135deg,#2c3e50,#3d5a80);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;">
  <div style="width:100%;max-width:420px;">
    <div style="text-align:center;margin-bottom:30px;">
      <div style="font-size:2.5rem;margin-bottom:8px;">👷</div>
      <h1 style="color:#fff;font-size:1.6rem;margin-bottom:4px;">Employee Portal</h1>
      <p style="color:rgba(255,255,255,.6);font-size:.88rem;">Arts Shop — Staff Access</p>
    </div>
    <div class="card">
      <div class="card-body">
        <?php if ($error): ?><div class="alert alert-error"><?= clean($error) ?></div><?php endif; ?>
        <form method="POST">
          <div class="form-group">
            <label class="form-label">Employee Username</label>
            <input type="text" name="username" class="form-control" placeholder="Your username" autofocus required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Your password" required>
          </div>
          <button type="submit" class="btn btn-dark btn-block btn-lg">Login</button>
        </form>
        <div class="divider"></div>
        <div style="text-align:center;font-size:.82rem;">
          <a href="<?= SITE_URL ?>/admin/login.php"    style="color:var(--muted);">Admin Login</a>
          &nbsp;·&nbsp;
          <a href="<?= SITE_URL ?>/customer/login.php" style="color:var(--muted);">Customer Login</a>
        </div>
      </div>
    </div>
    <p style="text-align:center;color:rgba(255,255,255,.4);font-size:.78rem;margin-top:16px;">
      Your account must be created by the Admin.
    </p>
  </div>
</body>
</html>
