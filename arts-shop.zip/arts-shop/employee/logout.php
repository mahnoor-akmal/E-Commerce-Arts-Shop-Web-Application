<?php
require_once '../config/config.php';
session_destroy();
redirect(SITE_URL . '/employee/login.php');
