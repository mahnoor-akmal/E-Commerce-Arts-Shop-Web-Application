<?php
/**
 * Admin Return Requests Management
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $returnId  = (int)$_POST['return_id'];
    $action    = $_POST['return_action'];
    $remarks   = trim($_POST['admin_remarks'] ?? '');
    if (in_array($action, ['approved','rejected','processed'])) {
        $rr = $db->prepare("SELECT * FROM return_requests WHERE return_id=?");
        $rr->execute([$returnId]);
        $rr = $rr->fetch();
        $db->prepare("UPDATE return_requests SET request_status=?, admin_remarks=?, processed_at=NOW() WHERE return_id=?")->execute([$action, $remarks, $returnId]);
        if ($action === 'processed' && $rr) {
            $newStatus = $rr['request_type'] === 'replace' ? 'replaced' : 'returned';
            $db->prepare("UPDATE orders SET order_status=? WHERE order_id=?")->execute([$newStatus, $rr['order_id']]);
        }
        setFlash('success', "Return request $action successfully.");
    }
    redirect(SITE_URL . '/admin/returns.php');
}

$filter = $_GET['filter'] ?? 'requested';
$where  = $filter !== 'all' ? "WHERE rr.request_status=?" : "WHERE 1=1";
$params = $filter !== 'all' ? [$filter] : [];

$stmt = $db->prepare("
    SELECT rr.*, o.order_number, o.total_amount, cu.full_name, cu.email
    FROM return_requests rr
    JOIN orders o ON rr.order_id=o.order_id
    JOIN customers cu ON rr.customer_id=cu.customer_id
    $where ORDER BY rr.requested_at DESC
");
$stmt->execute($params);
$returns = $stmt->fetchAll();

$pageTitle = 'Return Requests';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <h2 style="font-size:1.4rem;">↩️ Return / Replace Requests</h2>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <?php foreach (['all'=>'All','requested'=>'Pending','approved'=>'Approved','processed'=>'Processed','rejected'=>'Rejected'] as $k=>$label): ?>
      <a href="?filter=<?= $k ?>" class="btn btn-sm <?= $filter===$k?'btn-dark':'btn-outline' ?>"><?= $label ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Request ID</th><th>Order #</th><th>Customer</th><th>Type</th><th>Requested</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php if (empty($returns)): ?>
          <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--muted);">No return requests found.</td></tr>
        <?php endif; ?>
        <?php foreach ($returns as $r): ?>
        <tr>
          <td>#<?= $r['return_id'] ?></td>
          <td><a href="order-detail.php?id=<?= $r['order_id'] ?>" class="order-num" style="color:var(--primary);"><?= $r['order_number'] ?></a></td>
          <td>
            <div style="font-weight:600;font-size:.88rem;"><?= clean($r['full_name']) ?></div>
            <div style="font-size:.78rem;color:var(--muted);"><?= clean($r['email']) ?></div>
          </td>
          <td>
            <span class="badge <?= $r['request_type']==='return'?'badge-cancelled':'badge-replaced' ?>">
              <?= ucfirst($r['request_type']) ?>
            </span>
          </td>
          <td style="font-size:.82rem;"><?= date('d M Y', strtotime($r['requested_at'])) ?></td>
          <td><?= statusBadge($r['request_status']) ?></td>
          <td>
            <?php if ($r['request_status'] === 'requested'): ?>
              <button class="btn btn-sm btn-primary" onclick="openModal(<?= $r['return_id'] ?>, '<?= $r['request_type'] ?>')">Review</button>
            <?php else: ?>
              <a href="order-detail.php?id=<?= $r['order_id'] ?>" class="btn btn-outline btn-sm">View Order</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Review Modal -->
<div id="return-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:460px;margin:20px;">
    <div class="card-header flex justify-between">
      <h3>Review Return Request</h3>
      <button onclick="document.getElementById('return-modal').style.display='none'" style="background:none;border:none;font-size:1.4rem;cursor:pointer;">×</button>
    </div>
    <div class="card-body">
      <form method="POST">
        <input type="hidden" name="return_id" id="modal-return-id">
        <div class="form-group">
          <label class="form-label">Admin Remarks (optional)</label>
          <textarea name="admin_remarks" class="form-control" rows="3" placeholder="Notes for customer..."></textarea>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button name="return_action" value="approved"  class="btn btn-success btn-sm" onclick="return confirm('Approve this request?')">✓ Approve</button>
          <button name="return_action" value="processed" class="btn btn-primary btn-sm" onclick="return confirm('Mark as Processed?')">Mark Processed</button>
          <button name="return_action" value="rejected"  class="btn btn-danger btn-sm"  onclick="return confirm('Reject this request?')">✗ Reject</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
function openModal(id) {
    document.getElementById('modal-return-id').value = id;
    document.getElementById('return-modal').style.display = 'flex';
}
</script>
<?php include 'admin-footer.php'; ?>
