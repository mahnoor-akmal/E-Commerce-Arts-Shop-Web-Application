<?php
/**
 * Admin Sidebar Navigation Include
 * Used in all admin panel pages
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

function adminNavLink(string $href, string $icon, string $label, string $currentPage): string {
    $file    = basename($href);
    $active  = ($currentPage === $file) ? 'active' : '';
    return "<li><a href=\"$href\" class=\"$active\"><span class=\"icon\">$icon</span> $label</a></li>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? clean($pageTitle) . ' — ' : '' ?>Admin Panel | Arts Shop</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
  <?php if (isset($extraCSS)) echo $extraCSS; ?>
</head>
<body>
<div class="admin-layout">

  <!-- ─── Sidebar ─────────────────────────── -->
  <aside class="admin-sidebar">
    <div class="sidebar-logo">
      Arts Shop <span>Admin Panel</span>
    </div>
    <ul class="sidebar-menu">
      <li class="sidebar-section">Dashboard</li>
      <?= adminNavLink(SITE_URL.'/admin/dashboard.php', '📊', 'Dashboard', $currentPage) ?>

      <li class="sidebar-section">Catalogue</li>
      <?= adminNavLink(SITE_URL.'/admin/products.php', '🛍️', 'Products', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/categories.php', '🏷️', 'Categories', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/stock.php', '📦', 'Stock Management', $currentPage) ?>

      <li class="sidebar-section">Orders</li>
      <?= adminNavLink(SITE_URL.'/admin/orders.php', '📋', 'All Orders', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/returns.php', '↩️', 'Return Requests', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/delivery.php', '🚚', 'Delivery Reports', $currentPage) ?>

      <li class="sidebar-section">Users</li>
      <?= adminNavLink(SITE_URL.'/admin/employees.php', '👤', 'Employees', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/customers.php', '👥', 'Customers', $currentPage) ?>

      <li class="sidebar-section">Content</li>
      <?= adminNavLink(SITE_URL.'/admin/feedbacks.php', '💬', 'Feedbacks', $currentPage) ?>
      <?= adminNavLink(SITE_URL.'/admin/faqs.php', '❓', 'FAQs', $currentPage) ?>

      <li class="sidebar-section">Account</li>
      <li><a href="<?= SITE_URL ?>/index.php" target="_blank"><span class="icon">🌐</span> View Website</a></li>
      <li><a href="<?= SITE_URL ?>/admin/logout.php"><span class="icon">🚪</span> Logout</a></li>
    </ul>
  </aside>

  <!-- ─── Main Content Wrapper ─────────────── -->
  <div class="admin-main">
    <div class="admin-topbar">
      <h1><?= isset($pageTitle) ? clean($pageTitle) : 'Admin Panel' ?></h1>
      <div style="font-size:.88rem;color:var(--muted);">
        👤 <?= clean($_SESSION['admin_name'] ?? 'Admin') ?> &nbsp;·&nbsp;
        <a href="<?= SITE_URL ?>/admin/logout.php" style="color:var(--danger);">Logout</a>
      </div>
    </div>

    <div class="admin-content">
    <?php
    $flash = getFlash();
    if ($flash): ?>
      <div class="alert alert-<?= $flash['type']==='error'?'error':($flash['type']==='success'?'success':($flash['type']==='warning'?'warning':'info')) ?>">
        <?= clean($flash['message']) ?>
      </div>
    <?php endif;
