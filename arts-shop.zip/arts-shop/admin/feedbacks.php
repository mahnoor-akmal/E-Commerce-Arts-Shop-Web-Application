<?php
/**
 * Admin Feedbacks Management
 * View, mark as read/unread, delete feedback submissions
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $fid    = (int)($_POST['feedback_id'] ?? 0);
    if ($action === 'mark_read')   $db->prepare("UPDATE feedbacks SET is_read=1 WHERE feedback_id=?")->execute([$fid]);
    if ($action === 'mark_unread') $db->prepare("UPDATE feedbacks SET is_read=0 WHERE feedback_id=?")->execute([$fid]);
    if ($action === 'delete' && $fid) { $db->prepare("DELETE FROM feedbacks WHERE feedback_id=?")->execute([$fid]); setFlash('success','Feedback deleted.'); }
    redirect(SITE_URL . '/admin/feedbacks.php');
}

// Mark all as read if requested
if (isset($_GET['mark_all_read'])) {
    $db->exec("UPDATE feedbacks SET is_read=1");
    setFlash('success','All feedbacks marked as read.');
    redirect(SITE_URL . '/admin/feedbacks.php');
}

$filter = $_GET['filter'] ?? 'all';
$where  = $filter === 'unread' ? "WHERE is_read=0" : "";

$feedbacks = $db->query("SELECT * FROM feedbacks $where ORDER BY submitted_at DESC")->fetchAll();
$unreadCount = $db->query("SELECT COUNT(*) FROM feedbacks WHERE is_read=0")->fetchColumn();

$pageTitle = 'Feedbacks';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:1.4rem;">💬 Customer Feedbacks</h2>
    <?php if ($unreadCount): ?><span class="badge badge-placed"><?= $unreadCount ?> unread</span><?php endif; ?>
  </div>
  <div style="display:flex;gap:8px;">
    <?php if ($unreadCount): ?><a href="?mark_all_read=1" class="btn btn-outline btn-sm" onclick="return confirm('Mark all as read?')">Mark All Read</a><?php endif; ?>
    <a href="?filter=all"    class="btn btn-sm <?= $filter==='all'?'btn-dark':'btn-outline' ?>">All</a>
    <a href="?filter=unread" class="btn btn-sm <?= $filter==='unread'?'btn-dark':'btn-outline' ?>">Unread</a>
  </div>
</div>

<?php if (empty($feedbacks)): ?>
  <div class="empty-state"><div class="icon">💬</div><p>No feedbacks yet.</p></div>
<?php else: ?>
  <div style="display:grid;gap:16px;">
    <?php foreach ($feedbacks as $f): ?>
      <div class="card" style="<?= !$f['is_read'] ? 'border-left:4px solid var(--primary);' : '' ?>">
        <div class="card-body">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
            <div style="flex:1;">
              <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px;">
                <strong><?= clean($f['name']) ?></strong>
                <span style="color:var(--muted);font-size:.85rem;"><?= clean($f['email']) ?></span>
                <?php if (!$f['is_read']): ?><span class="badge badge-placed" style="font-size:.72rem;">New</span><?php endif; ?>
                <!-- Star rating display -->
                <?php if ($f['rating']): ?>
                  <span style="color:#f59e0b;font-size:.9rem;"><?= str_repeat('★',$f['rating']) . str_repeat('☆',5-$f['rating']) ?></span>
                <?php endif; ?>
                <span style="color:var(--muted);font-size:.78rem;"><?= date('d M Y, h:i A', strtotime($f['submitted_at'])) ?></span>
              </div>
              <?php if ($f['subject']): ?><div style="font-weight:600;margin-bottom:6px;"><?= clean($f['subject']) ?></div><?php endif; ?>
              <p style="color:var(--muted);font-size:.9rem;line-height:1.6;"><?= nl2br(clean($f['message'])) ?></p>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end;">
              <form method="POST" style="display:inline;">
                <input type="hidden" name="feedback_id" value="<?= $f['feedback_id'] ?>">
                <button name="action" value="<?= $f['is_read'] ? 'mark_unread' : 'mark_read' ?>" class="btn btn-outline btn-sm">
                  <?= $f['is_read'] ? 'Mark Unread' : '✓ Mark Read' ?>
                </button>
              </form>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="feedback_id" value="<?= $f['feedback_id'] ?>">
                <button name="action" value="delete" class="btn btn-danger btn-sm" onclick="return confirm('Delete this feedback?')">Delete</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php include 'admin-footer.php'; ?>
