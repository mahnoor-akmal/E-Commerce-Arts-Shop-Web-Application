<?php
/**
 * Admin Stock Management
 * View current stock levels, restock products, view stock log
 */
require_once '../config/config.php';
requireAdmin();

$db = getDB();

// ── Handle Restock ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['restock'])) {
    $productId = (int)$_POST['product_id'];
    $qty       = (int)$_POST['quantity'];
    $remarks   = trim($_POST['remarks'] ?? 'Manual restock by admin');

    if ($productId && $qty > 0) {
        $db->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id=?")->execute([$qty, $productId]);
        $db->prepare("INSERT INTO stock_log (product_id, change_type, quantity, remarks, logged_by) VALUES (?,?,?,?,?)")
           ->execute([$productId, 'restock', $qty, $remarks, 'admin']);
        setFlash('success', "Stock updated: +$qty units added.");
    } else {
        setFlash('error', 'Invalid product or quantity.');
    }
    redirect(SITE_URL . '/admin/stock.php');
}

// ── Filters ───────────────────────────────────────────────
$filter   = $_GET['filter'] ?? 'all';  // all, low, out
$catId    = (int)($_GET['category'] ?? 0);
$search   = trim($_GET['search'] ?? '');

$where  = ["p.is_active = 1"];
$params = [];
if ($filter === 'low') { $where[] = "p.stock_quantity > 0 AND p.stock_quantity <= 10"; }
if ($filter === 'out') { $where[] = "p.stock_quantity = 0"; }
if ($catId)  { $where[] = "p.category_id = ?"; $params[] = $catId; }
if ($search) { $where[] = "(p.product_name LIKE ? OR p.product_code LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$products = $db->prepare("
    SELECT p.*, c.category_name, c.category_code
    FROM products p JOIN product_categories c ON p.category_id=c.category_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY p.stock_quantity ASC
");
$products->execute($params);
$products = $products->fetchAll();

// Stock log (recent 30 entries)
$stockLog = $db->query("
    SELECT sl.*, p.product_name, p.product_code
    FROM stock_log sl JOIN products p ON sl.product_id=p.product_id
    ORDER BY sl.logged_at DESC LIMIT 30
")->fetchAll();

$categories = $db->query("SELECT * FROM product_categories WHERE is_active=1 ORDER BY category_name")->fetchAll();

// Summary counts
$outCount = $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity=0 AND is_active=1")->fetchColumn();
$lowCount = $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity > 0 AND stock_quantity <= 10 AND is_active=1")->fetchColumn();
$okCount  = $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity > 10 AND is_active=1")->fetchColumn();

$pageTitle = 'Stock Management';
include 'admin-header.php';
?>

<h2 style="font-size:1.4rem;margin-bottom:20px;">📦 Stock Management</h2>

<!-- ── Stock Summary ──────────────────────────────────────── -->
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:24px;">
  <div class="stat-card" style="border-top:4px solid var(--danger);">
    <div class="stat-icon">🔴</div>
    <div class="stat-label">Out of Stock</div>
    <div class="stat-value"><?= $outCount ?></div>
    <a href="?filter=out" style="font-size:.8rem;color:var(--danger);">View →</a>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--warning);">
    <div class="stat-icon">🟡</div>
    <div class="stat-label">Low Stock (≤10)</div>
    <div class="stat-value"><?= $lowCount ?></div>
    <a href="?filter=low" style="font-size:.8rem;color:var(--warning);">View →</a>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--success);">
    <div class="stat-icon">🟢</div>
    <div class="stat-label">Well Stocked</div>
    <div class="stat-value"><?= $okCount ?></div>
    <a href="?filter=all" style="font-size:.8rem;color:var(--success);">View All →</a>
  </div>
</div>

<!-- ── Filters ────────────────────────────────────────────── -->
<form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px;align-items:flex-end;">
  <div style="flex:1;min-width:160px;">
    <input type="text" name="search" class="form-control" placeholder="Search product..." value="<?= clean($search) ?>">
  </div>
  <select name="category" class="form-control" style="min-width:160px;">
    <option value="0">All Categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['category_id'] ?>" <?= $catId==$c['category_id']?'selected':'' ?>><?= clean($c['category_name']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="filter" class="form-control" style="min-width:130px;">
    <option value="all" <?= $filter==='all'?'selected':'' ?>>All Stock</option>
    <option value="low" <?= $filter==='low'?'selected':'' ?>>Low Stock</option>
    <option value="out" <?= $filter==='out'?'selected':'' ?>>Out of Stock</option>
  </select>
  <button type="submit" class="btn btn-dark">Filter</button>
  <a href="stock.php" class="btn btn-outline">Clear</a>
</form>

<!-- ── Products Stock Table ───────────────────────────────── -->
<div class="card" style="margin-bottom:30px;">
  <div class="card-header"><h3 style="font-size:1rem;">Product Stock Levels (<?= count($products) ?> products)</h3></div>
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Code</th><th>Product Name</th><th>Category</th><th>Current Stock</th><th>Status</th><th>Quick Restock</th></tr></thead>
      <tbody>
        <?php if (empty($products)): ?>
          <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--muted);">No products found.</td></tr>
        <?php endif; ?>
        <?php foreach ($products as $p): ?>
        <tr>
          <td><span style="font-family:monospace;font-size:.85rem;"><?= $p['product_code'] ?></span></td>
          <td><strong style="font-size:.9rem;"><?= clean($p['product_name']) ?></strong></td>
          <td style="font-size:.85rem;"><?= clean($p['category_name']) ?></td>
          <td style="font-size:1.1rem;font-weight:700;color:<?= $p['stock_quantity']==0?'var(--danger)':($p['stock_quantity']<=10?'var(--warning)':'var(--success)') ?>;">
            <?= $p['stock_quantity'] ?>
          </td>
          <td>
            <?php if ($p['stock_quantity'] == 0): ?>
              <span class="badge badge-cancelled">Out of Stock</span>
            <?php elseif ($p['stock_quantity'] <= 5): ?>
              <span class="badge badge-return">Critical Low</span>
            <?php elseif ($p['stock_quantity'] <= 10): ?>
              <span class="badge badge-pending">Low Stock</span>
            <?php else: ?>
              <span class="badge badge-delivered">OK</span>
            <?php endif; ?>
          </td>
          <td>
            <form method="POST" style="display:flex;gap:8px;align-items:center;">
              <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
              <input type="number" name="quantity" class="form-control" min="1" max="9999" placeholder="Qty" style="width:80px;padding:6px 10px;">
              <input type="text"   name="remarks"  class="form-control" placeholder="Remarks" style="width:130px;padding:6px 10px;">
              <button type="submit" name="restock" class="btn btn-success btn-sm">+ Add</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── Stock Activity Log ─────────────────────────────────── -->
<div class="card">
  <div class="card-header"><h3 style="font-size:1rem;">📋 Recent Stock Activity</h3></div>
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Date/Time</th><th>Product</th><th>Change Type</th><th>Quantity</th><th>Remarks</th><th>By</th></tr></thead>
      <tbody>
        <?php foreach ($stockLog as $log): ?>
        <tr>
          <td style="font-size:.82rem;white-space:nowrap;"><?= date('d M Y H:i', strtotime($log['logged_at'])) ?></td>
          <td style="font-size:.85rem;">
            <?= clean($log['product_name']) ?><br>
            <span style="font-family:monospace;font-size:.76rem;color:var(--muted);"><?= $log['product_code'] ?></span>
          </td>
          <td>
            <span class="badge <?= $log['change_type']==='restock'?'badge-delivered':($log['change_type']==='sale'?'badge-dispatched':'badge-return') ?>">
              <?= ucfirst($log['change_type']) ?>
            </span>
          </td>
          <td style="font-weight:700;color:<?= $log['quantity']>0?'var(--success)':'var(--danger)' ?>;">
            <?= $log['quantity'] > 0 ? '+' : '' ?><?= $log['quantity'] ?>
          </td>
          <td style="font-size:.85rem;"><?= clean($log['remarks'] ?? '—') ?></td>
          <td style="font-size:.82rem;"><?= clean($log['logged_by'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
