<?php
/**
 * Admin Order Detail Page
 * Full breakdown: items, payment, delivery, return requests
 */
require_once '../config/config.php';
requireAdmin();

$db      = getDB();
$orderId = (int)($_GET['id'] ?? 0);
if (!$orderId) redirect(SITE_URL . '/admin/orders.php');

$order = $db->prepare("
    SELECT o.*, cu.full_name, cu.email, cu.phone, cu.username
    FROM orders o JOIN customers cu ON o.customer_id = cu.customer_id
    WHERE o.order_id = ?
");
$order->execute([$orderId]);
$order = $order->fetch();
if (!$order) { setFlash('error','Order not found.'); redirect(SITE_URL.'/admin/orders.php'); }

$items   = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
$items->execute([$orderId]);
$items = $items->fetchAll();

$payment = $db->prepare("SELECT * FROM payment_details WHERE order_id=?");
$payment->execute([$orderId]);
$payment = $payment->fetch();

$delivery = $db->prepare("SELECT dr.*, e.full_name AS emp_name FROM delivery_reports dr LEFT JOIN employees e ON dr.employee_id=e.employee_id WHERE dr.order_id=?");
$delivery->execute([$orderId]);
$delivery = $delivery->fetch();

$returnReq = $db->prepare("SELECT * FROM return_requests WHERE order_id=? ORDER BY requested_at DESC LIMIT 1");
$returnReq->execute([$orderId]);
$returnReq = $returnReq->fetch();

// Handle return action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_action'])) {
    $returnId = (int)$_POST['return_id'];
    $action   = $_POST['return_action'];
    $remarks  = trim($_POST['admin_remarks'] ?? '');
    if (in_array($action, ['approved','rejected','processed'])) {
        $newOrderStatus = $action === 'processed' ? ($returnReq['request_type'] === 'replace' ? 'replaced' : 'returned') : $order['order_status'];
        $db->prepare("UPDATE return_requests SET request_status=?, admin_remarks=?, processed_at=NOW() WHERE return_id=?")->execute([$action, $remarks, $returnId]);
        if ($action === 'processed') $db->prepare("UPDATE orders SET order_status=? WHERE order_id=?")->execute([$newOrderStatus, $orderId]);
        setFlash('success', 'Return request updated.');
        redirect(SITE_URL . '/admin/order-detail.php?id=' . $orderId);
    }
}

$pageTitle = 'Order Detail';
include 'admin-header.php';
?>

<div style="margin-bottom:16px;">
  <a href="orders.php" style="color:var(--muted);font-size:.88rem;">← Back to Orders</a>
</div>

<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:16px;margin-bottom:24px;">
  <div>
    <h2 style="font-size:1.3rem;margin-bottom:4px;">Order: <span class="order-num"><?= $order['order_number'] ?></span></h2>
    <p style="color:var(--muted);font-size:.85rem;">Placed on <?= formatDate($order['placed_at']) ?></p>
  </div>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <?= statusBadge($order['order_status']) ?>
    <?= statusBadge($order['payment_status']) ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">

  <!-- LEFT COLUMN -->
  <div style="display:flex;flex-direction:column;gap:20px;">

    <!-- Customer Info -->
    <div class="card">
      <div class="card-header"><h3 style="font-size:1rem;">👤 Customer Details</h3></div>
      <div class="card-body" style="font-size:.9rem;display:grid;gap:8px;">
        <div><strong><?= clean($order['full_name']) ?></strong> (@<?= clean($order['username']) ?>)</div>
        <div>📧 <?= clean($order['email']) ?></div>
        <div>📞 <?= clean($order['phone'] ?? 'N/A') ?></div>
        <a href="<?= SITE_URL ?>/admin/customers.php?search=<?= $order['customer_id'] ?>" class="btn btn-outline btn-sm" style="width:fit-content;">View Customer Profile</a>
      </div>
    </div>

    <!-- Shipping Address -->
    <div class="card">
      <div class="card-header"><h3 style="font-size:1rem;">📍 Shipping Address</h3></div>
      <div class="card-body" style="font-size:.9rem;">
        <p><?= nl2br(clean($order['shipping_address'])) ?></p>
        <p><?= clean($order['shipping_city'] ?? '') ?><?= $order['shipping_state'] ? ', '.clean($order['shipping_state']) : '' ?> — <?= clean($order['shipping_pincode'] ?? '') ?></p>
        <p style="margin-top:8px;">🚚 <strong>Delivery Type:</strong> <?= getDeliveryLabel($order['delivery_type']) ?></p>
      </div>
    </div>

    <!-- Payment Details -->
    <div class="card">
      <div class="card-header flex justify-between">
        <h3 style="font-size:1rem;">💳 Payment Details</h3>
        <?php if ($order['payment_status'] === 'pending' && in_array($order['payment_type'], ['credit_card','cheque'])): ?>
          <form method="POST" action="orders.php">
            <input type="hidden" name="action" value="clear_payment">
            <input type="hidden" name="order_id" value="<?= $orderId ?>">
            <button class="btn btn-success btn-sm" onclick="return confirm('Confirm payment clearance?')">✓ Clear Payment</button>
          </form>
        <?php endif; ?>
      </div>
      <div class="card-body" style="font-size:.9rem;display:grid;gap:8px;">
        <div><strong>Method:</strong> <?= ucfirst(str_replace('_',' ',$order['payment_type'])) ?></div>
        <div><strong>Status:</strong> <?= statusBadge($order['payment_status']) ?></div>
        <?php if ($payment): ?>
          <?php if ($payment['payment_type'] === 'credit_card' && $payment['card_holder_name']): ?>
            <div><strong>Cardholder:</strong> <?= clean($payment['card_holder_name']) ?></div>
            <div><strong>Card (last 4):</strong> **** **** **** <?= $payment['card_number_last4'] ?></div>
            <div><strong>Expiry:</strong> <?= $payment['card_expiry'] ?></div>
          <?php elseif ($payment['payment_type'] === 'cheque' && $payment['cheque_number']): ?>
            <div><strong>Cheque #:</strong> <?= clean($payment['cheque_number']) ?></div>
            <div><strong>Bank:</strong> <?= clean($payment['bank_name'] ?? '') ?></div>
            <div><strong>Cheque Date:</strong> <?= $payment['cheque_date'] ? date('d M Y', strtotime($payment['cheque_date'])) : '—' ?></div>
          <?php elseif ($payment['payment_type'] === 'vpp'): ?>
            <div style="color:var(--muted);">VPP — Customer pays on delivery.</div>
          <?php endif; ?>
          <?php if ($payment['cleared_at']): ?>
            <div style="color:var(--success);"><strong>Cleared at:</strong> <?= formatDate($payment['cleared_at']) ?></div>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- RIGHT COLUMN -->
  <div style="display:flex;flex-direction:column;gap:20px;">

    <!-- Order Items -->
    <div class="card">
      <div class="card-header"><h3 style="font-size:1rem;">📦 Order Items</h3></div>
      <div style="padding:0;">
        <?php foreach ($items as $item): ?>
          <div style="display:grid;grid-template-columns:1fr auto;gap:12px;padding:14px 20px;border-bottom:1px solid var(--border);">
            <div>
              <div style="font-weight:600;font-size:.9rem;"><?= clean($item['product_name']) ?></div>
              <div style="font-size:.78rem;color:var(--muted);font-family:monospace;"><?= $item['product_code'] ?></div>
              <div style="font-size:.85rem;color:var(--muted);">Qty: <?= $item['quantity'] ?> × <?= formatCurrency($item['unit_price']) ?></div>
            </div>
            <div style="font-weight:700;text-align:right;"><?= formatCurrency($item['subtotal']) ?></div>
          </div>
        <?php endforeach; ?>
        <div style="padding:14px 20px;background:var(--bg2);">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:.9rem;"><span>Subtotal:</span><span><?= formatCurrency($order['subtotal']) ?></span></div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:.9rem;"><span>Shipping:</span><span><?= formatCurrency($order['shipping_charge']) ?></span></div>
          <div style="display:flex;justify-content:space-between;font-weight:700;font-size:1.05rem;"><span>Total:</span><span style="color:var(--primary);"><?= formatCurrency($order['total_amount']) ?></span></div>
        </div>
      </div>
    </div>

    <!-- Delivery / Dispatch -->
    <div class="card">
      <div class="card-header flex justify-between">
        <h3 style="font-size:1rem;">🚚 Delivery Status</h3>
      </div>
      <div class="card-body" style="font-size:.9rem;">
        <?php if ($delivery): ?>
          <div style="display:grid;gap:8px;">
            <div><strong>Status:</strong> <?= statusBadge($delivery['delivery_status']) ?></div>
            <?php if ($delivery['courier_name']): ?><div><strong>Courier:</strong> <?= clean($delivery['courier_name']) ?></div><?php endif; ?>
            <?php if ($delivery['tracking_number']): ?><div><strong>Tracking #:</strong> <span style="font-family:monospace;"><?= clean($delivery['tracking_number']) ?></span></div><?php endif; ?>
            <?php if ($delivery['dispatched_at']): ?><div><strong>Dispatched:</strong> <?= formatDate($delivery['dispatched_at']) ?></div><?php endif; ?>
            <?php if ($delivery['estimated_delivery']): ?><div><strong>Est. Delivery:</strong> <?= date('d M Y', strtotime($delivery['estimated_delivery'])) ?></div><?php endif; ?>
            <?php if ($delivery['delivered_at']): ?><div style="color:var(--success);"><strong>Delivered:</strong> <?= formatDate($delivery['delivered_at']) ?></div><?php endif; ?>
          </div>
        <?php else: ?>
          <p style="color:var(--muted);">Delivery not yet initiated.</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Return Request -->
    <?php if ($returnReq): ?>
    <div class="card" style="border-left:4px solid var(--warning);">
      <div class="card-header"><h3 style="font-size:1rem;">↩️ Return/Replace Request</h3></div>
      <div class="card-body" style="font-size:.9rem;">
        <div style="display:grid;gap:8px;margin-bottom:16px;">
          <div><strong>Type:</strong> <span style="text-transform:capitalize;"><?= $returnReq['request_type'] ?></span></div>
          <div><strong>Status:</strong> <?= statusBadge($returnReq['request_status']) ?></div>
          <div><strong>Requested:</strong> <?= date('d M Y', strtotime($returnReq['requested_at'])) ?></div>
          <div><strong>Reason:</strong> <?= nl2br(clean($returnReq['reason'])) ?></div>
          <?php if ($returnReq['admin_remarks']): ?><div><strong>Admin Remarks:</strong> <?= clean($returnReq['admin_remarks']) ?></div><?php endif; ?>
        </div>
        <?php if ($returnReq['request_status'] === 'requested'): ?>
          <form method="POST">
            <input type="hidden" name="return_id" value="<?= $returnReq['return_id'] ?>">
            <div class="form-group">
              <label class="form-label">Admin Remarks</label>
              <textarea name="admin_remarks" class="form-control" rows="2" placeholder="Optional remarks to customer"></textarea>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <button name="return_action" value="approved"  class="btn btn-success btn-sm" onclick="return confirm('Approve this request?')">✓ Approve</button>
              <button name="return_action" value="processed" class="btn btn-primary btn-sm" onclick="return confirm('Mark as processed? Order status will update.')">Mark Processed</button>
              <button name="return_action" value="rejected"  class="btn btn-danger btn-sm"  onclick="return confirm('Reject this request?')">✗ Reject</button>
            </div>
          </form>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
</div>

<?php include 'admin-footer.php'; ?>
