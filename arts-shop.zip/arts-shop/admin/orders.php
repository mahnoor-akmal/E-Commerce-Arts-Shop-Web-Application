<?php
/**
 * Admin Orders Management
 * View all orders, filter by status/date/delivery type
 * Clear payments, update order status
 */
require_once '../config/config.php';
requireAdmin();

$db = getDB();

// ── Handle POST actions ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action']   ?? '';
    $orderId = (int)($_POST['order_id'] ?? 0);

    // Clear payment (for credit_card or cheque orders)
    if ($action === 'clear_payment' && $orderId) {
        $db->prepare("UPDATE orders SET payment_status='cleared', order_status='payment_cleared' WHERE order_id=? AND payment_status='pending'")->execute([$orderId]);
        $db->prepare("UPDATE payment_details SET cleared_at=NOW() WHERE order_id=?")->execute([$orderId]);
        setFlash('success', "Payment cleared for Order #$orderId. Order is now ready for dispatch.");
        redirect(SITE_URL . '/admin/orders.php');
    }

    // Mark as dispatched
    if ($action === 'dispatch' && $orderId) {
        $tracking = trim($_POST['tracking_number'] ?? '');
        $courier  = trim($_POST['courier_name']    ?? '');
        $estDate  = $_POST['estimated_delivery']   ?? null;

        $db->prepare("UPDATE orders SET order_status='dispatched' WHERE order_id=?")->execute([$orderId]);
        // Update or insert delivery report
        $dr = $db->prepare("SELECT delivery_id FROM delivery_reports WHERE order_id=?");
        $dr->execute([$orderId]);
        if ($dr->fetch()) {
            $db->prepare("UPDATE delivery_reports SET dispatched_at=NOW(), delivery_status='dispatched', tracking_number=?, courier_name=?, estimated_delivery=?, employee_id=NULL WHERE order_id=?")
               ->execute([$tracking, $courier, $estDate ?: null, $orderId]);
        } else {
            $db->prepare("INSERT INTO delivery_reports (order_id, dispatched_at, delivery_status, tracking_number, courier_name, estimated_delivery) VALUES (?,NOW(),'dispatched',?,?,?)")
               ->execute([$orderId, $tracking, $courier, $estDate ?: null]);
        }
        setFlash('success', "Order #$orderId marked as Dispatched.");
        redirect(SITE_URL . '/admin/orders.php');
    }

    // Mark as delivered
    if ($action === 'mark_delivered' && $orderId) {
        $db->prepare("UPDATE orders SET order_status='delivered' WHERE order_id=?")->execute([$orderId]);
        $db->prepare("UPDATE delivery_reports SET delivered_at=NOW(), delivery_status='delivered' WHERE order_id=?")->execute([$orderId]);
        setFlash('success', "Order #$orderId marked as Delivered.");
        redirect(SITE_URL . '/admin/orders.php');
    }

    // Cancel order
    if ($action === 'cancel' && $orderId) {
        // Restore stock for cancelled order items
        $items = $db->prepare("SELECT product_id, quantity FROM order_items WHERE order_id=?");
        $items->execute([$orderId]);
        foreach ($items->fetchAll() as $item) {
            $db->prepare("UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id=?")->execute([$item['quantity'], $item['product_id']]);
            $db->prepare("INSERT INTO stock_log (product_id, change_type, quantity, reference_id, remarks, logged_by) VALUES (?,'return',?,?,'Order cancelled - stock restored','admin')")->execute([$item['product_id'], $item['quantity'], $orderId]);
        }
        $db->prepare("UPDATE orders SET order_status='cancelled' WHERE order_id=?")->execute([$orderId]);
        setFlash('success', "Order #$orderId cancelled and stock restored.");
        redirect(SITE_URL . '/admin/orders.php');
    }
}

// ── Filters ───────────────────────────────────────────────
$statusFilter   = $_GET['status']        ?? '';
$dateFrom       = $_GET['date_from']     ?? '';
$dateTo         = $_GET['date_to']       ?? '';
$deliveryFilter = $_GET['delivery_type'] ?? '';
$search         = trim($_GET['search']   ?? '');

$where  = ['1=1'];
$params = [];

// Special filter aliases from dashboard links
if ($statusFilter === 'pending_payment') { $where[] = "o.payment_status='pending' AND o.payment_type IN ('credit_card','cheque')"; }
elseif ($statusFilter === 'ready_dispatch') { $where[] = "(o.order_status='payment_cleared' OR (o.order_status='placed' AND o.payment_type='vpp'))"; }
elseif ($statusFilter && $statusFilter !== 'all') { $where[] = "o.order_status=?"; $params[] = $statusFilter; }

if ($dateFrom) { $where[] = "DATE(o.placed_at) >= ?"; $params[] = $dateFrom; }
if ($dateTo)   { $where[] = "DATE(o.placed_at) <= ?"; $params[] = $dateTo; }
if ($deliveryFilter) { $where[] = "o.delivery_type=?"; $params[] = $deliveryFilter; }
if ($search)   { $where[] = "(o.order_number LIKE ? OR cu.full_name LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$stmt = $db->prepare("
    SELECT o.*, cu.full_name AS customer_name, cu.email AS customer_email,
           dr.delivery_status, dr.dispatched_at, dr.delivered_at
    FROM orders o
    JOIN customers cu ON o.customer_id = cu.customer_id
    LEFT JOIN delivery_reports dr ON dr.order_id = o.order_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY o.placed_at DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

$pageTitle = 'Orders';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:1.4rem;">Order Management</h2>
    <p style="color:var(--muted);font-size:.85rem;"><?= count($orders) ?> orders found</p>
  </div>
</div>

<!-- ── Filter Bar ─────────────────────────────────────────── -->
<div class="card" style="margin-bottom:24px;">
  <div class="card-body" style="padding:16px 20px;">
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;">
      <div style="flex:1;min-width:180px;">
        <label class="form-label" style="font-size:.8rem;">Search Order/Customer</label>
        <input type="text" name="search" class="form-control" value="<?= clean($search) ?>" placeholder="Order# or customer name">
      </div>
      <div style="min-width:160px;">
        <label class="form-label" style="font-size:.8rem;">Order Status</label>
        <select name="status" class="form-control">
          <option value="">All Statuses</option>
          <option value="placed"           <?= $statusFilter==='placed'?'selected':'' ?>>Placed</option>
          <option value="payment_cleared"  <?= $statusFilter==='payment_cleared'?'selected':'' ?>>Payment Cleared</option>
          <option value="dispatched"       <?= $statusFilter==='dispatched'?'selected':'' ?>>Dispatched</option>
          <option value="delivered"        <?= $statusFilter==='delivered'?'selected':'' ?>>Delivered</option>
          <option value="cancelled"        <?= $statusFilter==='cancelled'?'selected':'' ?>>Cancelled</option>
          <option value="return_requested" <?= $statusFilter==='return_requested'?'selected':'' ?>>Return Requested</option>
        </select>
      </div>
      <div style="min-width:140px;">
        <label class="form-label" style="font-size:.8rem;">Delivery Type</label>
        <select name="delivery_type" class="form-control">
          <option value="">All Types</option>
          <option value="1" <?= $deliveryFilter==='1'?'selected':'' ?>>Standard Post</option>
          <option value="2" <?= $deliveryFilter==='2'?'selected':'' ?>>Express</option>
          <option value="3" <?= $deliveryFilter==='3'?'selected':'' ?>>VPP</option>
        </select>
      </div>
      <div style="min-width:130px;">
        <label class="form-label" style="font-size:.8rem;">From Date</label>
        <input type="date" name="date_from" class="form-control" value="<?= $dateFrom ?>">
      </div>
      <div style="min-width:130px;">
        <label class="form-label" style="font-size:.8rem;">To Date</label>
        <input type="date" name="date_to" class="form-control" value="<?= $dateTo ?>">
      </div>
      <div style="display:flex;gap:8px;align-items:flex-end;">
        <button type="submit" class="btn btn-dark">Filter</button>
        <a href="orders.php" class="btn btn-outline">Clear</a>
      </div>
    </form>
  </div>
</div>

<!-- ── Orders Table ───────────────────────────────────────── -->
<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead>
        <tr>
          <th>Order Number</th>
          <th>Customer</th>
          <th>Date</th>
          <th>Delivery</th>
          <th>Payment</th>
          <th>Total</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
          <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--muted);">No orders found matching your filters.</td></tr>
        <?php endif; ?>
        <?php foreach ($orders as $o): ?>
        <tr>
          <td>
            <a href="order-detail.php?id=<?= $o['order_id'] ?>" class="order-num" style="color:var(--primary);">
              <?= $o['order_number'] ?>
            </a>
          </td>
          <td>
            <div style="font-weight:600;font-size:.9rem;"><?= clean($o['customer_name']) ?></div>
            <div style="font-size:.78rem;color:var(--muted);"><?= clean($o['customer_email']) ?></div>
          </td>
          <td style="font-size:.85rem;white-space:nowrap;"><?= date('d M Y', strtotime($o['placed_at'])) ?><br><span style="color:var(--muted);font-size:.78rem;"><?= date('h:i A', strtotime($o['placed_at'])) ?></span></td>
          <td style="font-size:.83rem;"><?= getDeliveryLabel($o['delivery_type']) ?></td>
          <td>
            <span style="font-size:.83rem;"><?= ucfirst(str_replace('_',' ',$o['payment_type'])) ?></span><br>
            <?= statusBadge($o['payment_status']) ?>
          </td>
          <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
          <td><?= statusBadge($o['order_status']) ?></td>
          <td>
            <div class="td-actions" style="flex-wrap:wrap;">
              <a href="order-detail.php?id=<?= $o['order_id'] ?>" class="btn btn-outline btn-sm">View</a>

              <?php if ($o['payment_status'] === 'pending' && in_array($o['payment_type'], ['credit_card','cheque'])): ?>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="action" value="clear_payment">
                  <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                  <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Confirm payment clearance?')">✓ Clear Payment</button>
                </form>
              <?php endif; ?>

              <?php if (in_array($o['order_status'], ['placed','payment_cleared'])): ?>
                <button class="btn btn-primary btn-sm" onclick="openDispatch(<?= $o['order_id'] ?>)">Dispatch</button>
              <?php endif; ?>

              <?php if ($o['order_status'] === 'dispatched'): ?>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="action" value="mark_delivered">
                  <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                  <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Mark this order as delivered?')">✓ Delivered</button>
                </form>
              <?php endif; ?>

              <?php if (!in_array($o['order_status'], ['dispatched','delivered','cancelled'])): ?>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="action" value="cancel">
                  <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Cancel this order? Stock will be restored.')">Cancel</button>
                </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── Dispatch Modal ─────────────────────────────────────── -->
<div id="dispatch-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:480px;margin:20px;">
    <div class="card-header flex justify-between">
      <h3>Dispatch Order</h3>
      <button onclick="closeDispatch()" style="background:none;border:none;font-size:1.4rem;cursor:pointer;">×</button>
    </div>
    <div class="card-body">
      <form method="POST" id="dispatch-form">
        <input type="hidden" name="action" value="dispatch">
        <input type="hidden" name="order_id" id="dispatch-order-id">
        <div class="form-group">
          <label class="form-label">Courier / Shipping Partner</label>
          <input type="text" name="courier_name" class="form-control" placeholder="e.g. India Post, BlueDart, DTDC">
        </div>
        <div class="form-group">
          <label class="form-label">Tracking Number</label>
          <input type="text" name="tracking_number" class="form-control" placeholder="Tracking / AWB number (if any)">
        </div>
        <div class="form-group">
          <label class="form-label">Estimated Delivery Date</label>
          <input type="date" name="estimated_delivery" class="form-control" min="<?= date('Y-m-d') ?>">
        </div>
        <div style="display:flex;gap:12px;">
          <button type="submit" class="btn btn-primary">Confirm Dispatch</button>
          <button type="button" onclick="closeDispatch()" class="btn btn-outline">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openDispatch(orderId) {
    document.getElementById('dispatch-order-id').value = orderId;
    document.getElementById('dispatch-modal').style.display = 'flex';
}
function closeDispatch() {
    document.getElementById('dispatch-modal').style.display = 'none';
}
</script>

<?php include 'admin-footer.php'; ?>
