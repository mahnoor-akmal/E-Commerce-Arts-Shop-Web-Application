<?php
/**
 * Admin Delivery Reports Overview
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

$status = $_GET['status'] ?? '';
$where  = $status ? "WHERE dr.delivery_status=?" : "";
$params = $status ? [$status] : [];

$stmt = $db->prepare("
    SELECT dr.*, o.order_number, o.total_amount, o.delivery_type,
           cu.full_name AS customer_name, e.full_name AS employee_name
    FROM delivery_reports dr
    JOIN orders o ON dr.order_id=o.order_id
    JOIN customers cu ON o.customer_id=cu.customer_id
    LEFT JOIN employees e ON dr.employee_id=e.employee_id
    $where ORDER BY dr.updated_at DESC
");
$stmt->execute($params);
$deliveries = $stmt->fetchAll();

$pageTitle = 'Delivery Reports';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <h2 style="font-size:1.4rem;">🚚 Delivery Reports</h2>
  <div style="display:flex;gap:8px;flex-wrap:wrap;">
    <?php foreach ([''=> 'All','pending'=>'Pending','dispatched'=>'Dispatched','in_transit'=>'In Transit','delivered'=>'Delivered','failed'=>'Failed'] as $k=>$label): ?>
      <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-dark':'btn-outline' ?>"><?= $label ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Order #</th><th>Customer</th><th>Delivery Type</th><th>Courier</th><th>Tracking #</th><th>Dispatched</th><th>Est. Delivery</th><th>Delivered</th><th>Status</th></tr></thead>
      <tbody>
        <?php if (empty($deliveries)): ?>
          <tr><td colspan="9" style="text-align:center;padding:40px;color:var(--muted);">No delivery records found.</td></tr>
        <?php endif; ?>
        <?php foreach ($deliveries as $d): ?>
        <tr>
          <td><a href="order-detail.php?id=<?= $d['order_id'] ?>" class="order-num" style="color:var(--primary);"><?= substr($d['order_number'],0,10).'...' ?></a></td>
          <td style="font-size:.88rem;"><?= clean($d['customer_name']) ?></td>
          <td style="font-size:.82rem;"><?= getDeliveryLabel($d['delivery_type']) ?></td>
          <td style="font-size:.85rem;"><?= clean($d['courier_name'] ?? '—') ?></td>
          <td style="font-family:monospace;font-size:.82rem;"><?= clean($d['tracking_number'] ?? '—') ?></td>
          <td style="font-size:.82rem;"><?= $d['dispatched_at'] ? date('d M Y', strtotime($d['dispatched_at'])) : '—' ?></td>
          <td style="font-size:.82rem;"><?= $d['estimated_delivery'] ? date('d M Y', strtotime($d['estimated_delivery'])) : '—' ?></td>
          <td style="font-size:.82rem;color:var(--success);"><?= $d['delivered_at'] ? date('d M Y', strtotime($d['delivered_at'])) : '—' ?></td>
          <td><?= statusBadge($d['delivery_status']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
