<?php
/**
 * Admin FAQ Management - Full CRUD
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (in_array($action, ['add','edit'])) {
        $faqId    = (int)($_POST['faq_id']   ?? 0);
        $question = trim($_POST['question']  ?? '');
        $answer   = trim($_POST['answer']    ?? '');
        $category = trim($_POST['category']  ?? 'General');
        $sort     = (int)($_POST['sort_order'] ?? 0);
        $active   = isset($_POST['is_active']) ? 1 : 0;

        if ($question && $answer) {
            if ($action === 'add') {
                $db->prepare("INSERT INTO faqs (question, answer, category, sort_order, is_active) VALUES (?,?,?,?,?)")->execute([$question, $answer, $category, $sort, 1]);
                setFlash('success', 'FAQ added.');
            } else {
                $db->prepare("UPDATE faqs SET question=?, answer=?, category=?, sort_order=?, is_active=? WHERE faq_id=?")->execute([$question, $answer, $category, $sort, $active, $faqId]);
                setFlash('success', 'FAQ updated.');
            }
        } else {
            setFlash('error', 'Question and Answer are required.');
        }
        redirect(SITE_URL . '/admin/faqs.php');
    }

    if ($action === 'delete') {
        $db->prepare("DELETE FROM faqs WHERE faq_id=?")->execute([(int)$_POST['faq_id']]);
        setFlash('success', 'FAQ deleted.');
        redirect(SITE_URL . '/admin/faqs.php');
    }
}

$editId  = (int)($_GET['edit'] ?? 0);
$editFaq = null;
if ($editId) {
    $s = $db->prepare("SELECT * FROM faqs WHERE faq_id=?");
    $s->execute([$editId]);
    $editFaq = $s->fetch();
}

$faqs = $db->query("SELECT * FROM faqs ORDER BY category, sort_order, faq_id")->fetchAll();
$categories = array_unique(array_column($faqs, 'category'));

$pageTitle = 'FAQs';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
  <h2 style="font-size:1.4rem;">❓ FAQ Management</h2>
  <a href="?add=1" class="btn btn-primary">+ Add FAQ</a>
</div>

<!-- Add/Edit Form -->
<?php if (isset($_GET['add']) || $editFaq): ?>
<div class="card" style="margin-bottom:24px;">
  <div class="card-header"><h3><?= $editFaq ? 'Edit FAQ' : 'Add New FAQ' ?></h3></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="action" value="<?= $editFaq ? 'edit' : 'add' ?>">
      <?php if ($editFaq): ?><input type="hidden" name="faq_id" value="<?= $editFaq['faq_id'] ?>"><?php endif; ?>
      <div class="form-group">
        <label class="form-label">Question *</label>
        <input type="text" name="question" class="form-control" required value="<?= clean($editFaq['question'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Answer *</label>
        <textarea name="answer" class="form-control" rows="4" required><?= clean($editFaq['answer'] ?? '') ?></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Category</label>
          <input type="text" name="category" class="form-control" list="cat-list" value="<?= clean($editFaq['category'] ?? 'General') ?>">
          <datalist id="cat-list">
            <?php foreach ($categories as $c): ?><option value="<?= clean($c) ?>"><?php endforeach; ?>
            <option value="Orders"><option value="Payments"><option value="Shipping"><option value="Returns"><option value="Products">
          </datalist>
        </div>
        <div class="form-group">
          <label class="form-label">Sort Order</label>
          <input type="number" name="sort_order" class="form-control" value="<?= $editFaq['sort_order'] ?? 0 ?>" min="0">
        </div>
      </div>
      <?php if ($editFaq): ?>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:600;">
            <input type="checkbox" name="is_active" <?= $editFaq['is_active'] ? 'checked' : '' ?>>
            Active (visible to public)
          </label>
        </div>
      <?php endif; ?>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn btn-primary"><?= $editFaq ? 'Update' : 'Add FAQ' ?></button>
        <a href="faqs.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- FAQs List -->
<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>#</th><th>Question</th><th>Category</th><th>Sort</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php if (empty($faqs)): ?>
          <tr><td colspan="6" style="text-align:center;padding:30px;color:var(--muted);">No FAQs yet.</td></tr>
        <?php endif; ?>
        <?php foreach ($faqs as $f): ?>
        <tr>
          <td><?= $f['faq_id'] ?></td>
          <td style="max-width:400px;">
            <div style="font-weight:600;font-size:.9rem;"><?= clean(mb_substr($f['question'],0,80)) ?><?= mb_strlen($f['question'])>80?'…':'' ?></div>
            <div style="font-size:.8rem;color:var(--muted);margin-top:3px;"><?= clean(mb_substr($f['answer'],0,80)) ?>…</div>
          </td>
          <td><span class="badge badge-default"><?= clean($f['category']) ?></span></td>
          <td><?= $f['sort_order'] ?></td>
          <td><?= $f['is_active'] ? '<span style="color:var(--success);font-weight:600;">Active</span>' : '<span style="color:var(--danger);">Hidden</span>' ?></td>
          <td>
            <div class="td-actions">
              <a href="?edit=<?= $f['faq_id'] ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="faq_id" value="<?= $f['faq_id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete this FAQ?')">Delete</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
