    </div><!-- /.admin-content -->
  </div><!-- /.admin-main -->
</div><!-- /.admin-layout -->
<?php if (isset($extraJS)) echo $extraJS; ?>
</body>
</html>
