<?php
/**
 * Admin Login Page
 * Only the dealer/admin can log in here
 */
require_once '../config/config.php';

if (isAdminLoggedIn()) redirect(SITE_URL . '/admin/dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_id']   = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['admin_user'] = $admin['username'];
            setFlash('success', 'Welcome, ' . $admin['full_name'] . '!');
            redirect(SITE_URL . '/admin/dashboard.php');
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please enter both username and password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login — Arts Shop</title>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body style="background:var(--dark);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;">
  <div style="width:100%;max-width:420px;">
    <div style="text-align:center;margin-bottom:30px;">
      <div style="font-size:2.5rem;margin-bottom:8px;">🛡️</div>
      <h1 style="color:var(--accent);font-size:1.6rem;margin-bottom:4px;">Admin Panel</h1>
      <p style="color:rgba(255,255,255,.5);font-size:.88rem;">Arts Shop — Dealer Access Only</p>
    </div>
    <div class="card">
      <div class="card-body">
        <?php if ($error): ?>
          <div class="alert alert-error"><?= clean($error) ?></div>
        <?php endif; ?>
        <form method="POST">
          <div class="form-group">
            <label class="form-label">Admin Username</label>
            <input type="text" name="username" class="form-control" placeholder="Enter admin username" autofocus required>
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter password" required>
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg">Login to Admin Panel</button>
        </form>
        <div class="divider"></div>
        <div style="text-align:center;font-size:.82rem;">
          <a href="<?= SITE_URL ?>/customer/login.php" style="color:var(--muted);">Customer Login</a>
          &nbsp;·&nbsp;
          <a href="<?= SITE_URL ?>/employee/login.php" style="color:var(--muted);">Employee Login</a>
        </div>
      </div>
    </div>
    <p style="text-align:center;color:rgba(255,255,255,.3);font-size:.78rem;margin-top:16px;">
      Default: admin / admin123 (change after first login)
    </p>
  </div>
</body>
</html>
