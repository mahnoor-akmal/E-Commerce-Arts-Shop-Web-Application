<?php
/**
 * Admin Category Management
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if (in_array($action, ['add','edit'])) {
        $catId   = (int)($_POST['category_id'] ?? 0);
        $code    = strtoupper(trim($_POST['category_code'] ?? ''));
        $name    = trim($_POST['category_name'] ?? '');
        $desc    = trim($_POST['description']   ?? '');
        $active  = isset($_POST['is_active']) ? 1 : 0;
        if (!preg_match('/^[A-Z]{2}$/', $code)) { setFlash('error','Category code must be exactly 2 uppercase letters.'); redirect(SITE_URL.'/admin/categories.php'); }
        if (strlen($name) < 2) { setFlash('error','Category name is required.'); redirect(SITE_URL.'/admin/categories.php'); }
        if ($action === 'add') {
            try {
                $db->prepare("INSERT INTO product_categories (category_code, category_name, description, is_active) VALUES (?,?,?,1)")->execute([$code,$name,$desc]);
                setFlash('success',"Category [$code] $name added.");
            } catch (PDOException $e) { setFlash('error','Category code already exists.'); }
        } else {
            $db->prepare("UPDATE product_categories SET category_name=?, description=?, is_active=? WHERE category_id=?")->execute([$name,$desc,$active,$catId]);
            setFlash('success','Category updated.');
        }
    }
    redirect(SITE_URL . '/admin/categories.php');
}

$editId  = (int)($_GET['edit'] ?? 0);
$editCat = null;
if ($editId) { $s=$db->prepare("SELECT * FROM product_categories WHERE category_id=?"); $s->execute([$editId]); $editCat=$s->fetch(); }

$categories = $db->query("SELECT c.*, COUNT(p.product_id) AS product_count FROM product_categories c LEFT JOIN products p ON p.category_id=c.category_id AND p.is_active=1 GROUP BY c.category_id ORDER BY c.category_code")->fetchAll();

$pageTitle = 'Categories';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
  <h2 style="font-size:1.4rem;">🏷️ Product Categories</h2>
  <a href="?add=1" class="btn btn-primary">+ Add Category</a>
</div>

<?php if (isset($_GET['add']) || $editCat): ?>
<div class="card" style="margin-bottom:24px;">
  <div class="card-header"><h3><?= $editCat ? 'Edit Category' : 'Add Category' ?></h3></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="action" value="<?= $editCat ? 'edit' : 'add' ?>">
      <?php if ($editCat): ?><input type="hidden" name="category_id" value="<?= $editCat['category_id'] ?>"><?php endif; ?>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">2-Letter Category Code *</label>
          <input type="text" name="category_code" class="form-control" maxlength="2" placeholder="e.g. GA, GC" required
                 value="<?= clean($editCat['category_code'] ?? '') ?>" <?= $editCat ? 'readonly style="background:var(--bg2);cursor:not-allowed;"' : '' ?>>
          <div class="form-hint">Used in 7-digit Product ID. Cannot be changed after creation.</div>
        </div>
        <div class="form-group">
          <label class="form-label">Category Name *</label>
          <input type="text" name="category_name" class="form-control" required value="<?= clean($editCat['category_name'] ?? '') ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="2"><?= clean($editCat['description'] ?? '') ?></textarea>
      </div>
      <?php if ($editCat): ?>
        <div class="form-group"><label style="display:flex;align-items:center;gap:8px;cursor:pointer;"><input type="checkbox" name="is_active" <?= $editCat['is_active']?'checked':'' ?>> Active</label></div>
      <?php endif; ?>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn btn-primary"><?= $editCat ? 'Update' : 'Add Category' ?></button>
        <a href="categories.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>Code</th><th>Name</th><th>Description</th><th>Products</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($categories as $c): ?>
        <tr>
          <td><strong style="font-family:monospace;font-size:1rem;"><?= $c['category_code'] ?></strong></td>
          <td><strong><?= clean($c['category_name']) ?></strong></td>
          <td style="font-size:.85rem;color:var(--muted);"><?= clean(mb_substr($c['description']??'',0,60)) ?></td>
          <td><a href="products.php?category=<?= $c['category_id'] ?>"><?= $c['product_count'] ?> products</a></td>
          <td><?= $c['is_active'] ? '<span style="color:var(--success);font-weight:600;">Active</span>' : '<span style="color:var(--danger);">Inactive</span>' ?></td>
          <td><a href="?edit=<?= $c['category_id'] ?>" class="btn btn-outline btn-sm">Edit</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
