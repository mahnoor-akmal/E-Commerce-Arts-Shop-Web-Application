<?php
require_once '../config/config.php';
session_destroy();
redirect(SITE_URL . '/admin/login.php');
