<?php
/**
 * Admin Customer Listing — View Only (Admin cannot edit customer accounts)
 */
require_once '../config/config.php';
requireAdmin();
$db = getDB();

$search = trim($_GET['search'] ?? '');
$where  = $search ? "WHERE (full_name LIKE ? OR email LIKE ? OR username LIKE ? OR customer_id = ?)" : "";
$params = $search ? ["%$search%","%$search%","%$search%",(int)$search] : [];

$stmt = $db->prepare("
    SELECT c.*, COUNT(o.order_id) AS order_count, COALESCE(SUM(o.total_amount),0) AS total_spent
    FROM customers c
    LEFT JOIN orders o ON o.customer_id=c.customer_id AND o.order_status != 'cancelled'
    $where GROUP BY c.customer_id ORDER BY c.created_at DESC
");
$stmt->execute($params);
$customers = $stmt->fetchAll();

$pageTitle = 'Customers';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:1.4rem;">👥 Customer Accounts</h2>
    <p style="color:var(--muted);font-size:.85rem;"><?= count($customers) ?> customers registered</p>
  </div>
</div>

<form method="GET" style="display:flex;gap:12px;margin-bottom:20px;">
  <input type="text" name="search" class="form-control" placeholder="Search by name, email, username, or ID..." value="<?= clean($search) ?>" style="flex:1;">
  <button type="submit" class="btn btn-dark">Search</button>
  <a href="customers.php" class="btn btn-outline">Clear</a>
</form>

<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>City</th><th>Orders</th><th>Total Spent</th><th>Status</th><th>Joined</th></tr></thead>
      <tbody>
        <?php if (empty($customers)): ?>
          <tr><td colspan="10" style="text-align:center;padding:40px;color:var(--muted);">No customers found.</td></tr>
        <?php endif; ?>
        <?php foreach ($customers as $c): ?>
        <tr>
          <td style="font-family:monospace;">#<?= $c['customer_id'] ?></td>
          <td><strong><?= clean($c['full_name']) ?></strong></td>
          <td style="font-family:monospace;font-size:.85rem;">@<?= clean($c['username']) ?></td>
          <td style="font-size:.85rem;"><?= clean($c['email']) ?></td>
          <td style="font-size:.85rem;"><?= clean($c['phone'] ?? '—') ?></td>
          <td style="font-size:.85rem;"><?= clean($c['city'] ?? '—') ?></td>
          <td><a href="orders.php?search=<?= clean($c['full_name']) ?>"><?= $c['order_count'] ?></a></td>
          <td><strong><?= formatCurrency((float)$c['total_spent']) ?></strong></td>
          <td><?= $c['is_active'] ? '<span style="color:var(--success);font-weight:600;">Active</span>' : '<span style="color:var(--danger);">Inactive</span>' ?></td>
          <td style="font-size:.82rem;"><?= date('d M Y', strtotime($c['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
