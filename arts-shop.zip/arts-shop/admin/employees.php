<?php
/**
 * Admin Employee Management
 * Only admin can create employee accounts (username + password)
 * Admin can also edit, activate/deactivate employees
 */
require_once '../config/config.php';
requireAdmin();

$db      = getDB();
$adminId = (int)$_SESSION['admin_id'];
$errors  = [];

// ── Handle POST ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if (in_array($action, ['add', 'edit'])) {
        $empId       = (int)($_POST['employee_id'] ?? 0);
        $username    = trim($_POST['username']    ?? '');
        $fullName    = trim($_POST['full_name']   ?? '');
        $email       = trim($_POST['email']       ?? '');
        $phone       = trim($_POST['phone']       ?? '');
        $address     = trim($_POST['address']     ?? '');
        $designation = trim($_POST['designation'] ?? '');
        $password    = $_POST['password']         ?? '';
        $isActive    = isset($_POST['is_active']) ? 1 : 0;

        // Validate
        if (!preg_match('/^[a-zA-Z0-9_]{4,30}$/', $username)) $errors[] = 'Username: 4–30 chars, letters/numbers/underscore only.';
        if (strlen($fullName) < 3)   $errors[] = 'Full name must be at least 3 characters.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if ($action === 'add' && strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';

        // Unique username/email check
        if (empty($errors)) {
            $check = $db->prepare("SELECT employee_id FROM employees WHERE username=? AND employee_id != ?");
            $check->execute([$username, $empId]);
            if ($check->fetch()) $errors[] = "Username '$username' is already taken.";
        }

        if (empty($errors)) {
            if ($action === 'add') {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $db->prepare("
                    INSERT INTO employees (username, password_hash, full_name, email, phone, address, designation, is_active, created_by)
                    VALUES (?,?,?,?,?,?,?,?,?)
                ")->execute([$username, $hash, $fullName, $email, $phone, $address, $designation, 1, $adminId]);
                setFlash('success', "Employee account '$username' created successfully.");
            } else {
                $update = "UPDATE employees SET username=?, full_name=?, email=?, phone=?, address=?, designation=?, is_active=?";
                $params = [$username, $fullName, $email, $phone, $address, $designation, $isActive];
                if (!empty($password)) {
                    $update .= ", password_hash=?";
                    $params[] = password_hash($password, PASSWORD_BCRYPT);
                }
                $update .= " WHERE employee_id=?";
                $params[] = $empId;
                $db->prepare($update)->execute($params);
                setFlash('success', "Employee '$username' updated successfully.");
            }
            redirect(SITE_URL . '/admin/employees.php');
        }
    }

    if ($_POST['action'] === 'toggle') {
        $eid = (int)$_POST['employee_id'];
        $db->prepare("UPDATE employees SET is_active = 1 - is_active WHERE employee_id=?")->execute([$eid]);
        setFlash('success', 'Employee status updated.');
        redirect(SITE_URL . '/admin/employees.php');
    }
}

$editId      = (int)($_GET['edit'] ?? 0);
$showForm    = isset($_GET['add']) || $editId;
$editEmployee = null;

if ($editId) {
    $s = $db->prepare("SELECT * FROM employees WHERE employee_id=?");
    $s->execute([$editId]);
    $editEmployee = $s->fetch();
}

$employees = $db->query("
    SELECT e.*, a.username AS created_by_name
    FROM employees e
    LEFT JOIN admins a ON e.created_by = a.admin_id
    ORDER BY e.created_at DESC
")->fetchAll();

$pageTitle = 'Employees';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:1.4rem;">Employee Management</h2>
    <p style="color:var(--muted);font-size:.85rem;">Only Admin can create employee accounts</p>
  </div>
  <a href="?add=1" class="btn btn-primary">+ Add Employee</a>
</div>

<!-- ── Add/Edit Form ──────────────────────────────────────── -->
<?php if ($showForm): ?>
<div class="card" style="margin-bottom:24px;">
  <div class="card-header">
    <h3><?= $editEmployee ? 'Edit Employee: '.clean($editEmployee['full_name']) : 'Add New Employee' ?></h3>
  </div>
  <div class="card-body">
    <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= clean($e) ?></div><?php endforeach; ?>
    <form method="POST">
      <input type="hidden" name="action" value="<?= $editEmployee ? 'edit' : 'add' ?>">
      <?php if ($editEmployee): ?><input type="hidden" name="employee_id" value="<?= $editEmployee['employee_id'] ?>"><?php endif; ?>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Full Name *</label>
          <input type="text" name="full_name" class="form-control" required value="<?= clean($editEmployee['full_name'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Username (Login ID) *</label>
          <input type="text" name="username" class="form-control" required value="<?= clean($editEmployee['username'] ?? '') ?>">
          <div class="form-hint">Employee will use this to log in.</div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Email *</label>
          <input type="email" name="email" class="form-control" required value="<?= clean($editEmployee['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" value="<?= clean($editEmployee['phone'] ?? '') ?>">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Designation</label>
          <input type="text" name="designation" class="form-control" value="<?= clean($editEmployee['designation'] ?? '') ?>" placeholder="e.g. Warehouse Staff, Delivery Coordinator">
        </div>
        <div class="form-group">
          <label class="form-label">Password <?= $editEmployee ? '(leave blank to keep current)' : '*' ?></label>
          <input type="password" name="password" class="form-control" <?= $editEmployee ? '' : 'required' ?> placeholder="<?= $editEmployee ? 'New password (optional)' : 'Minimum 6 characters' ?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Address</label>
        <textarea name="address" class="form-control" rows="2"><?= clean($editEmployee['address'] ?? '') ?></textarea>
      </div>
      <?php if ($editEmployee): ?>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:600;">
            <input type="checkbox" name="is_active" <?= $editEmployee['is_active'] ? 'checked' : '' ?>>
            Account Active
          </label>
        </div>
      <?php endif; ?>
      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn btn-primary"><?= $editEmployee ? 'Update Employee' : 'Create Employee Account' ?></button>
        <a href="employees.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ── Employees Table ────────────────────────────────────── -->
<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead>
        <tr><th>Username</th><th>Full Name</th><th>Email</th><th>Phone</th><th>Designation</th><th>Status</th><th>Created</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php if (empty($employees)): ?>
          <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--muted);">No employees yet. Click "Add Employee" to create the first account.</td></tr>
        <?php endif; ?>
        <?php foreach ($employees as $e): ?>
        <tr>
          <td><strong style="font-family:monospace;"><?= clean($e['username']) ?></strong></td>
          <td><?= clean($e['full_name']) ?></td>
          <td style="font-size:.85rem;"><?= clean($e['email']) ?></td>
          <td style="font-size:.85rem;"><?= clean($e['phone'] ?? '—') ?></td>
          <td style="font-size:.85rem;"><?= clean($e['designation'] ?? '—') ?></td>
          <td><?= $e['is_active'] ? '<span style="color:var(--success);font-weight:600;">Active</span>' : '<span style="color:var(--danger);">Inactive</span>' ?></td>
          <td style="font-size:.82rem;"><?= date('d M Y', strtotime($e['created_at'])) ?></td>
          <td>
            <div class="td-actions">
              <a href="?edit=<?= $e['employee_id'] ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="employee_id" value="<?= $e['employee_id'] ?>">
                <button type="submit" class="btn btn-sm" style="background:<?= $e['is_active']?'var(--warning)':'var(--success)' ?>;color:#fff;"
                        onclick="return confirm('Toggle employee status?')">
                  <?= $e['is_active'] ? 'Deactivate' : 'Activate' ?>
                </button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
