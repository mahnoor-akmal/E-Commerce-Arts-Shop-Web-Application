<?php
/**
 * Admin Dashboard
 * Overview: sales stats, recent orders, low stock alerts, pending actions
 */
require_once '../config/config.php';
requireAdmin();

$db = getDB();

// ── Key Statistics ─────────────────────────────────────────

// Orders today
$todayOrders = $db->query("SELECT COUNT(*) FROM orders WHERE DATE(placed_at) = CURDATE()")->fetchColumn();
$todayRevenue= $db->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE DATE(placed_at) = CURDATE() AND order_status != 'cancelled'")->fetchColumn();

// Total statistics
$totalOrders    = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalRevenue   = $db->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE order_status != 'cancelled'")->fetchColumn();
$totalCustomers = $db->query("SELECT COUNT(*) FROM customers WHERE is_active=1")->fetchColumn();
$totalProducts  = $db->query("SELECT COUNT(*) FROM products WHERE is_active=1")->fetchColumn();

// Pending actions
$pendingPayments  = $db->query("SELECT COUNT(*) FROM orders WHERE payment_status='pending' AND payment_type IN ('credit_card','cheque')")->fetchColumn();
$pendingDispatch  = $db->query("SELECT COUNT(*) FROM orders WHERE order_status='payment_cleared' OR (order_status='placed' AND payment_type='vpp')")->fetchColumn();
$pendingReturns   = $db->query("SELECT COUNT(*) FROM return_requests WHERE request_status='requested'")->fetchColumn();
$unreadFeedbacks  = $db->query("SELECT COUNT(*) FROM feedbacks WHERE is_read=0")->fetchColumn();

// Low stock products (qty <= 5)
$lowStock = $db->query("
    SELECT p.product_code, p.product_name, p.stock_quantity, c.category_name
    FROM products p JOIN product_categories c ON p.category_id=c.category_id
    WHERE p.stock_quantity <= 5 AND p.is_active=1
    ORDER BY p.stock_quantity ASC LIMIT 8
")->fetchAll();

// Recent orders (last 10)
$recentOrders = $db->query("
    SELECT o.*, cu.full_name AS customer_name
    FROM orders o JOIN customers cu ON o.customer_id=cu.customer_id
    ORDER BY o.placed_at DESC LIMIT 10
")->fetchAll();

// Monthly revenue chart (last 6 months)
$monthlyRevenue = $db->query("
    SELECT DATE_FORMAT(placed_at,'%b %Y') AS month,
           COALESCE(SUM(total_amount),0) AS revenue,
           COUNT(*) AS order_count
    FROM orders
    WHERE placed_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) AND order_status != 'cancelled'
    GROUP BY YEAR(placed_at), MONTH(placed_at)
    ORDER BY placed_at ASC
")->fetchAll();

// Order status distribution
$statusDist = $db->query("
    SELECT order_status, COUNT(*) AS cnt FROM orders GROUP BY order_status
")->fetchAll();

$pageTitle = 'Dashboard';
include 'admin-header.php';
?>

<!-- ─── Key Stats ─────────────────────────────────────────── -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
  <div class="stat-card" style="border-top:4px solid var(--primary);">
    <div class="stat-icon">📦</div>
    <div class="stat-label">Total Orders</div>
    <div class="stat-value"><?= number_format($totalOrders) ?></div>
    <div style="font-size:.78rem;color:var(--muted);margin-top:4px;">Today: <?= $todayOrders ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--accent);">
    <div class="stat-icon">💰</div>
    <div class="stat-label">Total Revenue</div>
    <div class="stat-value" style="font-size:1.4rem;"><?= formatCurrency((float)$totalRevenue) ?></div>
    <div style="font-size:.78rem;color:var(--muted);margin-top:4px;">Today: <?= formatCurrency((float)$todayRevenue) ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--success);">
    <div class="stat-icon">👥</div>
    <div class="stat-label">Customers</div>
    <div class="stat-value"><?= number_format($totalCustomers) ?></div>
  </div>
  <div class="stat-card" style="border-top:4px solid var(--info);">
    <div class="stat-icon">🛍️</div>
    <div class="stat-label">Active Products</div>
    <div class="stat-value"><?= number_format($totalProducts) ?></div>
  </div>
</div>

<!-- ─── Pending Actions ───────────────────────────────────── -->
<?php if ($pendingPayments || $pendingDispatch || $pendingReturns || $unreadFeedbacks): ?>
<div style="margin-bottom:24px;">
  <h3 style="font-size:1rem;margin-bottom:12px;color:var(--danger);">⚠️ Pending Actions</h3>
  <div style="display:flex;gap:12px;flex-wrap:wrap;">
    <?php if ($pendingPayments): ?>
      <a href="orders.php?status=pending_payment" style="background:#fff3e0;border:1.5px solid #ffcc80;border-radius:var(--radius);padding:12px 20px;display:flex;align-items:center;gap:10px;color:var(--dark);">
        💳 <span><strong><?= $pendingPayments ?></strong> payments awaiting clearance</span>
      </a>
    <?php endif; ?>
    <?php if ($pendingDispatch): ?>
      <a href="orders.php?status=ready_dispatch" style="background:#e8f5e9;border:1.5px solid #a5d6a7;border-radius:var(--radius);padding:12px 20px;display:flex;align-items:center;gap:10px;color:var(--dark);">
        📦 <span><strong><?= $pendingDispatch ?></strong> orders ready to dispatch</span>
      </a>
    <?php endif; ?>
    <?php if ($pendingReturns): ?>
      <a href="returns.php" style="background:#fce4ec;border:1.5px solid #f48fb1;border-radius:var(--radius);padding:12px 20px;display:flex;align-items:center;gap:10px;color:var(--dark);">
        ↩️ <span><strong><?= $pendingReturns ?></strong> return requests pending</span>
      </a>
    <?php endif; ?>
    <?php if ($unreadFeedbacks): ?>
      <a href="feedbacks.php" style="background:#e3f2fd;border:1.5px solid #90caf9;border-radius:var(--radius);padding:12px 20px;display:flex;align-items:center;gap:10px;color:var(--dark);">
        💬 <span><strong><?= $unreadFeedbacks ?></strong> unread feedbacks</span>
      </a>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px;">

  <!-- ─── Recent Orders ─────────────────────────────────── -->
  <div class="card">
    <div class="card-header flex justify-between">
      <h3 style="font-size:1rem;">Recent Orders</h3>
      <a href="orders.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="table-wrap" style="border:none;border-radius:0;">
      <table>
        <thead><tr><th>Order #</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td><a href="order-detail.php?id=<?= $o['order_id'] ?>" class="order-num" style="color:var(--primary);"><?= substr($o['order_number'],0,8).'...' ?></a></td>
            <td style="font-size:.88rem;"><?= clean($o['customer_name']) ?></td>
            <td><strong><?= formatCurrency($o['total_amount']) ?></strong></td>
            <td><?= statusBadge($o['order_status']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- ─── Low Stock Alert ───────────────────────────────── -->
  <div class="card">
    <div class="card-header flex justify-between">
      <h3 style="font-size:1rem;">⚠️ Low Stock Alert</h3>
      <a href="stock.php" class="btn btn-outline btn-sm">Manage Stock</a>
    </div>
    <?php if (empty($lowStock)): ?>
      <div style="padding:30px;text-align:center;color:var(--success);">✓ All products have sufficient stock</div>
    <?php else: ?>
      <div class="table-wrap" style="border:none;border-radius:0;">
        <table>
          <thead><tr><th>Product</th><th>Category</th><th>Stock</th></tr></thead>
          <tbody>
            <?php foreach ($lowStock as $p): ?>
            <tr>
              <td>
                <a href="products.php?edit=<?= $p['product_code'] ?>" style="font-size:.88rem;"><?= clean(mb_substr($p['product_name'],0,28)) ?>...</a><br>
                <span style="font-family:monospace;font-size:.76rem;color:var(--muted);"><?= $p['product_code'] ?></span>
              </td>
              <td style="font-size:.85rem;"><?= clean($p['category_name']) ?></td>
              <td>
                <span style="font-weight:700;color:<?= $p['stock_quantity']==0?'var(--danger)':'var(--warning)' ?>;">
                  <?= $p['stock_quantity'] == 0 ? 'OUT' : $p['stock_quantity'] ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- ─── Order Status Distribution ────────────────────────── -->
<div class="card">
  <div class="card-header"><h3 style="font-size:1rem;">Order Status Distribution</h3></div>
  <div class="card-body" style="display:flex;gap:16px;flex-wrap:wrap;">
    <?php foreach ($statusDist as $s): ?>
      <div style="text-align:center;min-width:100px;">
        <?= statusBadge($s['order_status']) ?>
        <div style="font-size:1.4rem;font-weight:700;margin-top:6px;"><?= $s['cnt'] ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
