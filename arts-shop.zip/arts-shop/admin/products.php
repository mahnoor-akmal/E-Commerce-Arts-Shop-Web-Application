<?php
/**
 * Admin Product Management
 * Full CRUD: Add, Edit, Delete products with image upload
 * Product Code = CategoryCode(2) + Auto 5-digit number = 7 chars
 */
require_once '../config/config.php';
requireAdmin();

$db = getDB();

// ── Handle POST actions ──────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── Add / Edit Product ──
    if (in_array($action, ['add', 'edit'])) {
        $productId   = (int)($_POST['product_id'] ?? 0);
        $categoryId  = (int)$_POST['category_id'];
        $productName = trim($_POST['product_name']);
        $description = trim($_POST['description'] ?? '');
        $price       = (float)$_POST['price'];
        $stock       = (int)$_POST['stock_quantity'];
        $hasWarranty = isset($_POST['has_warranty']) ? 1 : 0;
        $warrantyMo  = (int)($_POST['warranty_months'] ?? 0);
        $isActive    = isset($_POST['is_active']) ? 1 : 0;

        // Validate
        $errors = [];
        if (!$categoryId)              $errors[] = 'Category is required.';
        if (strlen($productName) < 2)  $errors[] = 'Product name is required.';
        if ($price <= 0)               $errors[] = 'Price must be greater than 0.';
        if ($stock < 0)                $errors[] = 'Stock cannot be negative.';

        if (empty($errors)) {
            // Handle image upload
            $imagePath = $_POST['existing_image'] ?? null;
            if (!empty($_FILES['image']['name'])) {
                $ext       = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed   = ['jpg','jpeg','png','gif','webp'];
                if (in_array($ext, $allowed) && $_FILES['image']['size'] < 2097152) {
                    $filename  = uniqid('prod_') . '.' . $ext;
                    $dest      = UPLOADS_PATH . $filename;
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                        $imagePath = $filename;
                    }
                } else {
                    $errors[] = 'Invalid image. Use JPG/PNG/GIF/WEBP under 2MB.';
                }
            }
        }

        if (empty($errors)) {
            if ($action === 'add') {
                // Generate product code: CategoryCode + next 5-digit number
                $cat = $db->prepare("SELECT category_code FROM product_categories WHERE category_id=?");
                $cat->execute([$categoryId]);
                $catCode = $cat->fetchColumn();

                // Find next available 5-digit number for this category
                $last = $db->prepare("SELECT product_code FROM products WHERE product_code LIKE ? ORDER BY product_code DESC LIMIT 1");
                $last->execute([$catCode . '%']);
                $lastCode = $last->fetchColumn();
                $nextNum  = $lastCode ? ((int)substr($lastCode, 2) + 1) : 1;
                $productCode = $catCode . str_pad($nextNum, 5, '0', STR_PAD_LEFT);

                $db->prepare("
                    INSERT INTO products (product_code, category_id, product_name, description, price, stock_quantity, has_warranty, warranty_months, image_path, is_active)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                ")->execute([$productCode, $categoryId, $productName, $description, $price, $stock, $hasWarranty, $warrantyMo, $imagePath, $isActive]);

                // Log initial stock
                $newId = $db->lastInsertId();
                $db->prepare("INSERT INTO stock_log (product_id, change_type, quantity, remarks, logged_by) VALUES (?,?,?,?,?)")
                   ->execute([$newId, 'restock', $stock, 'Initial stock on product creation', 'admin']);

                setFlash('success', "Product '$productCode — $productName' added successfully.");
            } else {
                $old = $db->prepare("SELECT stock_quantity FROM products WHERE product_id=?");
                $old->execute([$productId]);
                $oldStock = (int)$old->fetchColumn();

                $db->prepare("
                    UPDATE products SET category_id=?, product_name=?, description=?, price=?, stock_quantity=?, has_warranty=?, warranty_months=?, image_path=?, is_active=?
                    WHERE product_id=?
                ")->execute([$categoryId, $productName, $description, $price, $stock, $hasWarranty, $warrantyMo, $imagePath, $isActive, $productId]);

                // Log stock change if different
                if ($stock !== $oldStock) {
                    $diff = $stock - $oldStock;
                    $db->prepare("INSERT INTO stock_log (product_id, change_type, quantity, remarks, logged_by) VALUES (?,?,?,?,?)")
                       ->execute([$productId, $diff > 0 ? 'restock' : 'adjustment', $diff, 'Admin manual adjustment', 'admin']);
                }
                setFlash('success', "Product updated successfully.");
            }
            redirect(SITE_URL . '/admin/products.php');
        } else {
            setFlash('error', implode(' ', $errors));
        }
    }

    // ── Delete Product ──
    if ($action === 'delete') {
        $pid  = (int)$_POST['product_id'];
        // Fetch image path before deleting
        $imgStmt = $db->prepare("SELECT image_path FROM products WHERE product_id = ?");
        $imgStmt->execute([$pid]);
        $imgRow = $imgStmt->fetch();
        // Delete from DB
        $db->prepare("DELETE FROM products WHERE product_id = ?")->execute([$pid]);
        // Delete image file from disk if it exists
        if (!empty($imgRow['image_path'])) {
            $imgFile = UPLOADS_PATH . $imgRow['image_path'];
            if (file_exists($imgFile)) unlink($imgFile);
        }
        setFlash('success', 'Product deleted successfully.');
        redirect(SITE_URL . '/admin/products.php');
    }

    // ── Remove Image Only ──
    if ($action === 'remove_image') {
        $pid  = (int)$_POST['product_id'];
        $imgStmt = $db->prepare("SELECT image_path FROM products WHERE product_id = ?");
        $imgStmt->execute([$pid]);
        $imgRow = $imgStmt->fetch();
        if (!empty($imgRow['image_path'])) {
            $imgFile = UPLOADS_PATH . $imgRow['image_path'];
            if (file_exists($imgFile)) unlink($imgFile);
            $db->prepare("UPDATE products SET image_path = NULL WHERE product_id = ?")->execute([$pid]);
        }
        setFlash('success', 'Product image removed.');
        redirect(SITE_URL . '/admin/products.php');
    }

    // ── Toggle Active ──
    if ($action === 'toggle') {
        $pid = (int)$_POST['product_id'];
        $db->prepare("UPDATE products SET is_active = 1 - is_active WHERE product_id=?")->execute([$pid]);
        setFlash('success', 'Product status toggled.');
        redirect(SITE_URL . '/admin/products.php');
    }
}

// ── Fetch for listing ────────────────────────────────────────
$search     = trim($_GET['search']   ?? '');
$catFilter  = (int)($_GET['category'] ?? 0);
$editId     = (int)($_GET['edit']    ?? 0);
$showForm   = isset($_GET['add']) || $editId;

$where  = ['1=1'];
$params = [];
if ($search) {
    $where[]  = "(p.product_name LIKE ? OR p.product_code LIKE ? OR c.category_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catFilter) { $where[] = "p.category_id = ?"; $params[] = $catFilter; }

$stmt = $db->prepare("
    SELECT p.*, c.category_name, c.category_code
    FROM products p JOIN product_categories c ON p.category_id=c.category_id
    WHERE " . implode(' AND ', $where) . "
    ORDER BY p.product_code
");
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $db->query("SELECT * FROM product_categories WHERE is_active=1 ORDER BY category_name")->fetchAll();

// Fetch product to edit
$editProduct = null;
if ($editId) {
    $s = $db->prepare("SELECT * FROM products WHERE product_id=?");
    $s->execute([$editId]);
    $editProduct = $s->fetch();
}

$pageTitle = 'Products';
include 'admin-header.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
  <div>
    <h2 style="font-size:1.4rem;">Product Management</h2>
    <p style="color:var(--muted);font-size:.85rem;"><?= count($products) ?> products found</p>
  </div>
  <a href="?add=1" class="btn btn-primary">+ Add New Product</a>
</div>

<!-- ── Add/Edit Form ──────────────────────────────────────── -->
<?php if ($showForm): ?>
<div class="card" style="margin-bottom:24px;">
  <div class="card-header">
    <h3><?= $editProduct ? 'Edit Product: ' . clean($editProduct['product_code']) : 'Add New Product' ?></h3>
  </div>
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="<?= $editProduct ? 'edit' : 'add' ?>">
      <?php if ($editProduct): ?>
        <input type="hidden" name="product_id" value="<?= $editProduct['product_id'] ?>">
        <input type="hidden" name="existing_image" value="<?= $editProduct['image_path'] ?>">
      <?php endif; ?>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Category *</label>
          <select name="category_id" class="form-control" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= $c['category_id'] ?>" <?= ($editProduct && $editProduct['category_id']==$c['category_id']) ? 'selected' : '' ?>>
                [<?= $c['category_code'] ?>] <?= clean($c['category_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
          <?php if (!$editProduct): ?><div class="form-hint">Product ID will be auto-generated as: CategoryCode + 5-digit number</div><?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">Product Name *</label>
          <input type="text" name="product_name" class="form-control" required value="<?= clean($editProduct['product_name'] ?? '') ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" rows="3"><?= clean($editProduct['description'] ?? '') ?></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Price (Rs.) *</label>
          <input type="number" name="price" class="form-control" step="0.01" min="0.01" required value="<?= $editProduct['price'] ?? '' ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Stock Quantity *</label>
          <input type="number" name="stock_quantity" class="form-control" min="0" required value="<?= $editProduct['stock_quantity'] ?? 0 ?>">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Product Image (JPG/PNG, max 2MB)</label>
          <input type="file" name="image" class="form-control" accept="image/*">
          <?php if ($editProduct && $editProduct['image_path']): ?>
            <div class="form-hint">Current: <?= $editProduct['image_path'] ?>. Upload new to replace.</div>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">Options</label>
          <div style="display:flex;flex-direction:column;gap:10px;margin-top:8px;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
              <input type="checkbox" name="has_warranty" <?= ($editProduct['has_warranty'] ?? 0) ? 'checked' : '' ?> onchange="document.getElementById('warranty-months').style.display=this.checked?'block':'none'">
              Product has warranty
            </label>
            <div id="warranty-months" style="display:<?= ($editProduct['has_warranty'] ?? 0)?'block':'none' ?>;">
              <input type="number" name="warranty_months" class="form-control" min="1" max="120" placeholder="Warranty months" value="<?= $editProduct['warranty_months'] ?? '' ?>">
            </div>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
              <input type="checkbox" name="is_active" <?= ($editProduct['is_active'] ?? 1) ? 'checked' : '' ?>>
              Active (visible to customers)
            </label>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:12px;">
        <button type="submit" class="btn btn-primary"><?= $editProduct ? 'Update Product' : 'Add Product' ?></button>
        <a href="products.php" class="btn btn-outline">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- ── Search & Filter ────────────────────────────────────── -->
<form method="GET" style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
  <input type="text" name="search" class="form-control" placeholder="Search by name or code..." value="<?= clean($search) ?>" style="flex:1;min-width:200px;">
  <select name="category" class="form-control" style="min-width:160px;">
    <option value="0">All Categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['category_id'] ?>" <?= $catFilter==$c['category_id']?'selected':'' ?>><?= clean($c['category_name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-dark">Filter</button>
  <a href="products.php" class="btn btn-outline">Clear</a>
</form>

<!-- ── Products Table ─────────────────────────────────────── -->
<div class="card">
  <div class="table-wrap" style="border:none;border-radius:0;">
    <table>
      <thead>
        <tr>
          <th>Product Code</th>
          <th>Name</th>
          <th>Category</th>
          <th>Price</th>
          <th>Stock</th>
          <th>Warranty</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($products)): ?>
          <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--muted);">No products found.</td></tr>
        <?php endif; ?>
        <?php foreach ($products as $p): ?>
        <tr>
          <td><span style="font-family:monospace;font-weight:700;"><?= $p['product_code'] ?></span></td>
          <td>
            <strong><?= clean($p['product_name']) ?></strong>
            <?php if ($p['image_path']): ?><span style="color:var(--success);font-size:.75rem;"> 📷</span><?php endif; ?>
          </td>
          <td><span style="font-size:.85rem;"><?= clean($p['category_name']) ?></span></td>
          <td><strong><?= formatCurrency($p['price']) ?></strong></td>
          <td>
            <?php if ($p['stock_quantity'] == 0): ?>
              <span style="color:var(--danger);font-weight:700;">Out</span>
            <?php elseif ($p['stock_quantity'] <= 5): ?>
              <span style="color:var(--warning);font-weight:700;"><?= $p['stock_quantity'] ?> ⚠</span>
            <?php else: ?>
              <?= $p['stock_quantity'] ?>
            <?php endif; ?>
          </td>
          <td><?= $p['has_warranty'] ? '<span style="color:var(--success);">✓ '.$p['warranty_months'].'mo</span>' : '—' ?></td>
          <td><?= $p['is_active'] ? '<span style="color:var(--success);font-weight:600;">Active</span>' : '<span style="color:var(--danger);">Inactive</span>' ?></td>
          <td>
            <div class="td-actions">
              <a href="?edit=<?= $p['product_id'] ?>" class="btn btn-outline btn-sm">Edit</a>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                <button type="submit" class="btn btn-sm" style="background:<?= $p['is_active']?'var(--warning)':'var(--success)' ?>;color:#fff;"
                        onclick="return confirm('Toggle product status?')">
                  <?= $p['is_active'] ? 'Deactivate' : 'Activate' ?>
                </button>
              </form>
              <a href="<?= SITE_URL ?>/product.php?id=<?= $p['product_id'] ?>" target="_blank" class="btn btn-sm btn-dark">View</a>
            </div>
            <a href="<?= SITE_URL ?>/product.php?id=<?= $p['product_id'] ?>" target="_blank" class="btn btn-sm btn-dark">View</a>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm"
                        onclick="return confirm('DELETE product \'<?= addslashes($p['product_name']) ?>\'?\nThis cannot be undone.')">
                  Delete
                </button>
              </form>
              <?php if ($p['image_path']): ?>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="remove_image">
                <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                <button type="submit" class="btn btn-sm" style="background:var(--warning);color:#fff;"
                        onclick="return confirm('Remove image for this product?')">
                  Remove Img
                </button>
              </form>
              <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include 'admin-footer.php'; ?>
