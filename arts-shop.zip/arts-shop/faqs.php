<?php
/**
 * FAQs Page - Publicly visible, managed by Admin
 */
require_once 'config/config.php';

$db = getDB();

// Fetch all active FAQs grouped by category
$faqs = $db->query("
    SELECT * FROM faqs WHERE is_active = 1 ORDER BY category, sort_order, faq_id
")->fetchAll();

// Group by category
$grouped = [];
foreach ($faqs as $faq) {
    $grouped[$faq['category']][] = $faq;
}

$pageTitle = 'FAQs';
include 'includes/header.php';
?>

<div style="padding:50px 0 80px;">
  <div class="container-md">

    <!-- Hero -->
    <div style="text-align:center;margin-bottom:50px;">
      <div style="font-size:3rem;margin-bottom:12px;">❓</div>
      <h1 style="font-size:2.2rem;margin-bottom:10px;">Frequently Asked Questions</h1>
      <p style="color:var(--muted);max-width:500px;margin:0 auto;">
        Find answers to common questions about ordering, payments, delivery and returns.
      </p>
    </div>

    <?php if (empty($faqs)): ?>
      <div class="empty-state"><p>No FAQs available at the moment.</p></div>
    <?php else: ?>

      <!-- Category Navigation -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-bottom:40px;">
        <?php foreach (array_keys($grouped) as $cat): ?>
          <a href="#<?= strtolower(str_replace(' ', '-', $cat)) ?>"
             style="padding:8px 20px;border-radius:50px;border:1.5px solid var(--border);
                    font-size:.88rem;font-weight:600;color:var(--text);transition:.2s;"
             onmouseover="this.style.borderColor='var(--primary)';this.style.color='var(--primary)'"
             onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text)'">
            <?= clean($cat) ?>
          </a>
        <?php endforeach; ?>
      </div>

      <!-- FAQ Accordion by Category -->
      <?php foreach ($grouped as $category => $items): ?>
        <div id="<?= strtolower(str_replace(' ', '-', $category)) ?>" style="margin-bottom:40px;">
          <h2 style="font-size:1.2rem;color:var(--primary);margin-bottom:16px;
                     padding-bottom:10px;border-bottom:2px solid var(--border);">
            <?= clean($category) ?>
          </h2>
          <?php foreach ($items as $i => $faq): ?>
            <div class="card" style="margin-bottom:10px;border-radius:var(--radius);">
              <button onclick="toggleFaq('faq-<?= $faq['faq_id'] ?>')"
                      style="width:100%;text-align:left;background:none;border:none;padding:18px 20px;
                             cursor:pointer;font-family:'DM Sans',sans-serif;font-size:.95rem;
                             font-weight:600;color:var(--dark);display:flex;justify-content:space-between;align-items:center;">
                <span><?= clean($faq['question']) ?></span>
                <span id="icon-<?= $faq['faq_id'] ?>" style="font-size:1.2rem;transition:.3s;">+</span>
              </button>
              <div id="faq-<?= $faq['faq_id'] ?>" style="display:none;padding:0 20px 18px;color:var(--muted);line-height:1.7;">
                <?= nl2br(clean($faq['answer'])) ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>

    <?php endif; ?>

    <!-- Contact CTA -->
    <div style="background:var(--dark);border-radius:var(--radius);padding:40px;text-align:center;color:var(--white);margin-top:40px;">
      <h3 style="color:var(--accent);margin-bottom:10px;">Still have questions?</h3>
      <p style="opacity:.8;margin-bottom:20px;">Send us your feedback or query and we'll get back to you.</p>
      <a href="feedback.php" class="btn btn-accent">Send us a Message</a>
    </div>
  </div>
</div>

<script>
function toggleFaq(id) {
    var el   = document.getElementById(id);
    var icon = document.getElementById('icon-' + id.replace('faq-', ''));
    var open = el.style.display === 'block';
    el.style.display = open ? 'none' : 'block';
    icon.textContent = open ? '+' : '−';
    icon.style.transform = open ? 'rotate(0deg)' : 'rotate(180deg)';
}
</script>

<?php include 'includes/footer.php'; ?>
